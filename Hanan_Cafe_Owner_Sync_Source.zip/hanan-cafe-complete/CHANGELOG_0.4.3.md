# Hanan Cafe 0.4.3

- Two selectable palettes matching the supplied references: Navy / AI Green and Orange / Porcelain.
- Compact horizontal Menu Studio cards with individual delete controls. Deleting hides the product while retaining historical order snapshots and seed identity.
- Dashboard and Orders show quantity and product-size summaries. Orders start at the top. Cashiers can mark ready and delivered directly; actions use distinct blue and green colours.
- Order cancellation records a reason, actor and refund-review amount. It never sends a refund. Optional stock return is restricted to owner/manager and can happen only once.
- One hidden print document and one print invocation, without a new tab. Selecting both includes separate customer and kitchen pages. Physical printer settings and output still need checking on the owner's printer.
- Larger Confirm order text, visible checkout borders, responsive cart footer.
- Custom date financial reports and PDFs use Pakistan business dates. PDF orange headers have explicitly dark text.
- Customer contact directory, normalized phone matching and explicit marketing preference. Existing valid order contacts import without marketing consent. No messages are sent.
- ZTechx developer panel and copyright Zocxorian Technology. The supplied logo remains exact; screen blending conceals black on the developer panel. The source logo is not a native transparent PNG.
- Existing pizza sizes, duplication, image history, backup/import and owner reset retained.
