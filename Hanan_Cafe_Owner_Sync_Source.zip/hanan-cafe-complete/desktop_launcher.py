import threading,webbrowser,time
import uvicorn
if __name__=='__main__':
    threading.Thread(target=lambda:(time.sleep(2),webbrowser.open('http://127.0.0.1:8765')),daemon=True).start()
    uvicorn.run('app:app',host='127.0.0.1',port=8765)
