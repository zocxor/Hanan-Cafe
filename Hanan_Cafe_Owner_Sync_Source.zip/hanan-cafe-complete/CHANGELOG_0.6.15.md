 # Changelog 0.6.15 — finance side-by-side + sign-in card border

## Finance page

- The page is now split horizontally: compact summary cards on the left,
  income statement on the right (stacked on smaller screens).
- Cards are smaller: tighter padding, calmer numbers, still 2x2.
- Mobile pass: split collapses to one column, period buttons wrap, tables
  scroll sideways, export stacks — everything reachable on a phone.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=0614`; hard-refresh once (Cmd+Shift+R).

## Also in this build

- Sign-in card: elegant highlighted border — a soft accent-tinted border
  with a faint glow ring, in both colour schemes. Nothing else changed.
