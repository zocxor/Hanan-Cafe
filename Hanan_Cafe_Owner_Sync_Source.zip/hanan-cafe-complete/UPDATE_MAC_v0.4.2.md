# Update the existing Mac installation to v0.4.2

This update preserves your existing data and login. Do not run setup.py again for an initialized database. Use the same data directory/HANAN_DATA_DIR setting as before.

1. Generate a backup from the current app. Stop its server with Ctrl+C.
2. Save Hanan_Cafe_v0.4.2_Premium_Pizza_Update.zip in Downloads.
3. The following commands overlay the updated source into the folder used in this conversation. They leave `.venv`, any existing `data` directory and `~/.hanan-cafe` untouched:

```bash
unzip -o "$HOME/Downloads/Hanan_Cafe_v0.4.2_Premium_Pizza_Update.zip" -d "$HOME/Downloads/Hanan_Cafe_v040"
cd "$HOME/Downloads/Hanan_Cafe_v040/hanan-cafe-complete"
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m uvicorn app:app --host 127.0.0.1 --port 8765
```

Open http://127.0.0.1:8765 and press Command+Shift+R once. Keep Terminal open. If your existing app lives elsewhere, change both directory paths to its actual parent/project folder. Never point the update at an unrelated app directory.

If there is no `.venv` in that folder, use your installed Python 3 with scrypt support:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

For a genuinely new installation only, run `python setup.py` once to create your own owner login before starting the server. No default account is shipped. The app has been tested on Python 3.12; your Python 3.15 has scrypt, but dependency installation must still succeed before continuing.

## After updating

- Menu → Edit dish → Sizes & prices: configure Small, Medium, Large and XL for each pizza. All four start at the pre-existing item price, so no unprovided price differences are invented. Existing individual size edits persist.
- Menu → Duplicate: enter a different unused name. The image, description, category, availability and pizza prices are copied. Stock is untracked/zero; the original is unchanged.
- Kitchen and Orders: Mark ready, then Mark delivered. Ready is a single deliberate staff action recording all items as prepared. Payment remains separate.
- Known untouched starter stock photos update to transparent cutouts once. Custom uploads are retained; previous images remain in Image Studio history. Restoring a previous image is respected on later starts.
- Existing catalogues remain intact. If starter dishes have not been added, owner → Backup → Add missing starter dishes.
