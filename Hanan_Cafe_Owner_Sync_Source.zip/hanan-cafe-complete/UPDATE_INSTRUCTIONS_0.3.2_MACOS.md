# Hanan Cafe 0.3.2 update (macOS)

This update changes only the kitchen layout stylesheet. It does not change the database or Python application.

1. Stop the server with Ctrl+C.
2. Copy `static/style.css` from this package into your existing project's `static/style.css`.
3. Restart with your existing virtual environment and force-refresh the browser (Command+Shift+R).

If your old project path does not exist, locate the actual folder first with:

```bash
find "$HOME/Downloads" -maxdepth 5 -path '*/hanan-cafe-complete/static/style.css' -print
```

Use the path returned by that command as the destination project's root. Do not run setup.py or delete the data folder.
