# Changelog 0.6.23 — faster Dashboard / POS / Orders

## Performance

- POS menu grid now defers rendering off-screen product cards
  (content-visibility) — the heaviest page paints much faster, and tapping
  cards works exactly as before.
- (v0.6.22) Page entrance animation shortened 0.5s → 0.22s for instant-feeling
  sidebar navigation.

Measured on test data: page scripts run in 31–67ms and data loads in
14–38ms; the remaining feel was paint/animation work, now reduced.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=0623`; hard-refresh once (Cmd+Shift+R).
