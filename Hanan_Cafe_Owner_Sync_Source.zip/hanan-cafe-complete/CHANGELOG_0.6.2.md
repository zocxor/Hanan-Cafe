# Changelog 0.6.2 — sidebar footer + scrollbar

## Sidebar

- Removed the ZTechX logo box from the sidebar footer. It now shows two
  simple lines: "Powered by ZTechX" and "© <year>".
- The sidebar scrollbar is hidden (scroll still works silently on short
  screens so no navigation item is ever unreachable).

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=062`; hard-refresh once (Cmd+Shift+R).
