"""Additive starter catalogue, retained images and verified local recovery."""
import asyncio, base64, hashlib, io, json, re, secrets, shutil, sqlite3, tempfile, uuid, zipfile
from datetime import datetime, timezone
from pathlib import Path
from fastapi import Request, HTTPException
from fastapi.responses import HTMLResponse

def install(g):
    app=g['app']; DATA=g['DATA']; MEDIA=g['MEDIA']; BASE=g['BASE']; DB=g['DB']
    auth=g['auth']; tx=g['tx']; connect=g['connect']; audit=g['audit']; now=g['now']; payload=g['payload']; rows=g['rows']
    lock=asyncio.Lock()
    @app.middleware('http')
    async def serialize_mutations(request, call_next):
        if request.method not in ('GET','HEAD','OPTIONS'):
            async with lock:return await call_next(request)
        return await call_next(request)

    def catalogue():return json.loads((BASE/'starter/catalogue.json').read_text())
    def seed(actor=None):
        added=0
        with tx() as c:
            for item in catalogue():
                key=item['key']
                if c.execute('SELECT 1 FROM starter_registry WHERE key=?',(key,)).fetchone():continue
                existing=c.execute('SELECT id FROM products WHERE lower(trim(name))=lower(?)',(item['name'],)).fetchone()
                if existing:
                    c.execute('INSERT INTO starter_registry VALUES(?,?)',(key,existing['id']));continue
                category=c.execute('SELECT id FROM categories WHERE lower(name)=lower(?)',(item['category'],)).fetchone()
                cid=category['id'] if category else uuid.uuid5(uuid.NAMESPACE_URL,'hanan-category:'+item['category']).hex
                if not category:c.execute('INSERT INTO categories(id,name,active) VALUES(?,?,1)',(cid,item['category']))
                source=BASE/'starter/images'/item['image']
                if not source.is_file():raise RuntimeError('Starter image missing: '+item['image'])
                target=MEDIA/item['image']
                if not target.exists():shutil.copy2(source,target)
                pid=uuid.uuid5(uuid.NAMESPACE_URL,'hanan-starter:'+key).hex
                c.execute('INSERT INTO products(id,name,category_id,price_paisa,created_at,image_path,description,starter_key) VALUES(?,?,?,?,?,?,?,?)',(pid,item['name'],cid,item['price']*100,now(),item['image'],item['description'],key))
                c.execute('INSERT INTO starter_registry VALUES(?,?)',(key,pid));added+=1
            audit(c,actor,'starter_catalogue_added',{'added':added})
        return added
    # New installations are populated automatically. Existing catalogues require an explicit owner action.
    if g['NEW_DATABASE'] and not rows('SELECT id FROM products LIMIT 1') and not rows('SELECT key FROM starter_registry LIMIT 1') and (BASE/'starter/catalogue.json').exists():seed()

    # One-time visual asset migration: only untouched shipped starter images.
    # Owner uploads, changed images, prices and descriptions are never overwritten.
    cutout_manifest=BASE/'starter/cutout-migration.json'
    if cutout_manifest.exists():
        replacements=json.loads(cutout_manifest.read_text())
        with tx() as c:
            migrated=c.execute("SELECT value FROM settings WHERE key='cutout_assets_042'").fetchone()
            if not migrated:
                changed=0
                for image in replacements:
                    for product in c.execute('SELECT id,image_path FROM products WHERE starter_key=? AND image_path=?',(image['key'],image['previous_image'])).fetchall():
                        source=BASE/'starter/images'/image['image']
                        if not source.is_file():raise RuntimeError('Cutout asset missing')
                        target=MEDIA/image['image']
                        if not target.exists():shutil.copy2(source,target)
                        c.execute('INSERT INTO product_images VALUES(?,?,?,?)',(uuid.uuid4().hex,product['id'],product['image_path'],now()))
                        c.execute('UPDATE products SET image_path=? WHERE id=?',(image['image'],product['id']));changed+=1
                c.execute("INSERT INTO settings(key,value) VALUES('cutout_assets_042','done')")
                if changed:audit(c,None,'starter_cutout_images_updated',{'count':changed,'version':'0.4.7'})

    @app.post('/api/categories/reorder')
    async def reorder_categories(request:Request):
        u=auth(request,['owner','manager']);p=await payload(request);ids=p.get('ids')
        with tx() as c:
            actual={r['id'] for r in c.execute('SELECT id FROM categories WHERE active=1')}
            if not isinstance(ids,list) or len(ids)!=len(actual) or set(ids)!=actual:raise HTTPException(400,'Provide each active category once')
            for index,cid in enumerate(ids):c.execute('UPDATE categories SET sort_order=? WHERE id=?',(index,cid))
            audit(c,u['id'],'categories_reordered',{'ids':ids})
        return {'ok':True}

    @app.post('/api/catalogue/seed')
    def seed_route(request:Request):
        u=auth(request,['owner']);return {'added':seed(u['id'])}

    @app.get('/api/products/{pid}/image-history')
    def image_history(pid:str,request:Request):
        auth(request,['owner','manager']);return rows('SELECT * FROM product_images WHERE product_id=? ORDER BY created_at DESC,rowid DESC',(pid,))

    @app.post('/api/products/{pid}/image-restore')
    async def image_restore(pid:str,request:Request):
        u=auth(request,['owner','manager']);p=await payload(request)
        with tx() as c:
            old=c.execute('SELECT image_path FROM products WHERE id=?',(pid,)).fetchone()
            image=c.execute('SELECT image_path FROM product_images WHERE id=? AND product_id=?',(p.get('history_id'),pid)).fetchone()
            if not old or not image or not (MEDIA/Path(image['image_path']).name).is_file():raise HTTPException(404,'Retained image unavailable')
            if old['image_path']:c.execute('INSERT INTO product_images VALUES(?,?,?,?)',(uuid.uuid4().hex,pid,old['image_path'],now()))
            c.execute('UPDATE products SET image_path=? WHERE id=?',(image['image_path'],pid));audit(c,u['id'],'image_restored',{'product_id':pid})
        return {'ok':True}

    @app.post('/api/orders/{oid}/tasks/{item_id}')
    async def kitchen_task(oid:str,item_id:str,request:Request):
        u=auth(request,['owner','manager','kitchen']);p=await payload(request)
        with tx() as c:
            item=c.execute('SELECT i.id,o.status FROM order_items i JOIN orders o ON o.id=i.order_id WHERE i.id=? AND i.order_id=?',(item_id,oid)).fetchone()
            if not item or item['status'] not in ('RECEIVED','CONFIRMED','PREPARING'):raise HTTPException(409,'Order is not in preparation')
            done=int(bool(p.get('done')))
            c.execute('INSERT INTO kitchen_tasks VALUES(?,?,?,?) ON CONFLICT(item_id) DO UPDATE SET done=excluded.done,actor=excluded.actor,updated_at=excluded.updated_at',(item_id,done,u['id'],now()))
            audit(c,u['id'],'kitchen_item_changed',{'order_id':oid,'item_id':item_id,'done':done})
        return {'ok':True}

    def current_password(u,password):
        with connect() as c:r=c.execute('SELECT * FROM users WHERE id=?',(u['id'],)).fetchone()
        import hmac
        if not hmac.compare_digest(g['password_hash'](str(password),r['salt']),r['password_hash']):raise HTTPException(403,'Current owner password is incorrect')

    def recovery(reason):
        folder=DATA/'recovery';folder.mkdir(exist_ok=True)
        name=reason+'-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(4)+'.zip'
        target=folder/name
        with tempfile.TemporaryDirectory(dir=DATA) as temp:
            snap=Path(temp)/'hanan.sqlite3'
            with connect() as src:
                dst=sqlite3.connect(snap);src.backup(dst);dst.close()
            manifest={'version':'0.4.7','created_at':now(),'database_sha256':hashlib.sha256(snap.read_bytes()).hexdigest(),'media':[]}
            with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
                z.write(snap,'hanan.sqlite3')
                for f in MEDIA.iterdir():
                    if f.is_file() and re.fullmatch(r'[a-f0-9]{32}\.(jpg|png|webp)',f.name):
                        z.write(f,'media/'+f.name);manifest['media'].append({'file':'media/'+f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
                z.writestr('manifest.json',json.dumps(manifest))
        return name

    @app.get('/api/backup/recovery')
    def recovery_list(request:Request):
        auth(request,['owner']);folder=DATA/'recovery'
        return [{'name':f.name,'bytes':f.stat().st_size} for f in sorted(folder.glob('*.zip'),reverse=True)] if folder.exists() else []

    @app.get('/api/backup/recovery/{name}')
    def recovery_download(name:str,request:Request):
        auth(request,['owner'])
        if not re.fullmatch(r'(pre-restore|pre-reset)-[0-9-]+-[a-f0-9]{8}\.zip',name):raise HTTPException(404)
        from fastapi.responses import FileResponse
        f=DATA/'recovery'/name
        if not f.exists():raise HTTPException(404)
        return FileResponse(f,filename=name)

    stages={}
    @app.post('/api/backup/preview')
    async def restore_preview(request:Request):
        u=auth(request,['owner'])
        for key,value in list(stages.items()):
            if value['expires']<datetime.now().timestamp():shutil.rmtree(value['dir'],ignore_errors=True);del stages[key]
        raw=await request.body()
        if len(raw)>100*1024*1024:raise HTTPException(413,'Backup must be under 100 MB')
        folder=Path(tempfile.mkdtemp(prefix='restore-',dir=DATA));token=secrets.token_urlsafe(32)
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as z:
                names=z.namelist()
                # Ignore OS metadata cruft (re-zipped on macOS/Windows adds these).
                pruned=[]
                for n in names:
                    if n.endswith('/'):continue
                    low=n.lower()
                    if low=='__macosx' or low.startswith('__macosx/'):continue
                    if n.rsplit('/',1)[-1].lower() in ('.ds_store','thumbs.db','desktop.ini'):continue
                    pruned.append(n)
                # Accept a single top-level folder wrapper, e.g. Backup/hanan.sqlite3.
                firsts={n.split('/',1)[0] for n in pruned}
                prefix=''
                if pruned and all('/' in n for n in pruned) and len(firsts)==1:
                    candidate=next(iter(firsts))+'/'
                    stripped=[n[len(candidate):] for n in pruned]
                    if 'manifest.json' in stripped and 'hanan.sqlite3' in stripped:prefix=candidate
                actual={n[len(prefix):] if prefix else n:n for n in pruned}
                names=list(actual.keys())
                if 'manifest.json' not in names:raise ValueError("manifest.json is missing — this is not a Hanan Cafe backup ZIP. Use Backup → Generate & download ZIP.")
                if len(names)!=len(set(names)) or len(names)>5000 or sum(i.file_size for i in z.infolist())>250*1024*1024:raise ValueError('Duplicate entries or archive too large')
                if any(n not in ('manifest.json','hanan.sqlite3') and not re.fullmatch(r'media/[a-f0-9]{32}\.(jpg|png|webp)',n) for n in names):raise ValueError('This is not a supported backup ZIP. Use Backup → Generate & download ZIP; application update ZIPs cannot be imported.')
                manifest=json.loads(z.read(actual['manifest.json']));db=z.read(actual['hanan.sqlite3'])
                if hashlib.sha256(db).hexdigest()!=manifest['database_sha256']:raise ValueError('Database checksum failed')
                (folder/'hanan.sqlite3').write_bytes(db);(folder/'media').mkdir()
                listed=set()
                for f in manifest.get('media',[]):
                    name=f['file']
                    if not re.fullmatch(r'media/[a-f0-9]{32}\.(jpg|png|webp)',name):raise ValueError('Invalid media path')
                    data=z.read(actual[name])
                    if hashlib.sha256(data).hexdigest()!=f['sha256']:raise ValueError('Media checksum failed')
                    (folder/name).write_bytes(data);listed.add(name)
                c=sqlite3.connect(folder/'hanan.sqlite3')
                try:
                    if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or c.execute('PRAGMA foreign_key_check').fetchall():raise ValueError('Database integrity check failed')
                    if c.execute("SELECT 1 FROM sqlite_master WHERE type IN ('trigger','view')").fetchone():raise ValueError('Unsupported database objects')
                    with connect() as live:
                        for table in ['users','sessions','settings','categories','products','orders','order_items','order_events','inventory_movements','expenses','print_jobs','audit']:
                            required={r[1] for r in live.execute('PRAGMA table_info('+table+')')} - {'description','starter_key','sort_order','is_deleted','permissions','image_path'}
                            present={r[1] for r in c.execute('PRAGMA table_info('+table+')')}
                            if not required<=present:raise ValueError('Incompatible table: '+table)
                    if not c.execute("SELECT 1 FROM users WHERE role='owner' AND active=1").fetchone():raise ValueError('No active owner in backup')
                    for table in ['products','users']+(['product_images'] if c.execute("SELECT 1 FROM sqlite_master WHERE name='product_images'").fetchone() else []):
                        if 'image_path' not in {r[1] for r in c.execute('PRAGMA table_info('+table+')')}:continue
                        for (path,) in c.execute('SELECT image_path FROM '+table+' WHERE image_path IS NOT NULL AND trim(image_path)!=\'\''):
                            if 'media/'+str(path) not in listed:raise ValueError('Backup is missing a referenced image')
                    counts={t:c.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in ['products','orders','users','expenses']}
                finally:c.close()
            for key,value in list(stages.items()):
                if value['owner']==u['id']:shutil.rmtree(value['dir'],ignore_errors=True);del stages[key]
            stages[token]={'dir':str(folder),'owner':u['id'],'expires':datetime.now().timestamp()+900}
            return {'token':token,'counts':counts,'created_at':manifest.get('created_at'),'note':'Full replacement, not a merge. Backup owner credentials will be required after restore.'}
        except (ValueError,TypeError,KeyError,UnicodeDecodeError,RuntimeError,sqlite3.Error,zipfile.BadZipFile) as e:
            shutil.rmtree(folder,ignore_errors=True);raise HTTPException(400,'Invalid backup: '+str(e))

    @app.post('/api/backup/restore')
    async def restore(request:Request):
        u=auth(request,['owner']);p=await payload(request);current_password(u,p.get('password'))
        stage=stages.get(p.get('token',''))
        if not stage or stage['owner']!=u['id'] or stage['expires']<datetime.now().timestamp():raise HTTPException(400,'Preview expired; import the backup again')
        if p.get('confirmation')!='RESTORE HANAN CAFE':raise HTTPException(400,'Type RESTORE HANAN CAFE to confirm')
        folder=Path(stage['dir']);remapped=0
        # Prepare a private restored copy; never overwrite media needed by live/recovery data.
        staged=sqlite3.connect(folder/'hanan.sqlite3')
        try:
            for f in list((folder/'media').iterdir()):
                destination=MEDIA/f.name
                if destination.exists() and destination.read_bytes()!=f.read_bytes():
                    old=f.name;name=uuid.uuid4().hex+f.suffix
                    while (MEDIA/name).exists() or (folder/'media'/name).exists():name=uuid.uuid4().hex+f.suffix
                    for table in ('products','users','product_images'):
                        columns={r[1] for r in staged.execute('PRAGMA table_info('+table+')')}
                        if 'image_path' in columns:staged.execute('UPDATE '+table+' SET image_path=? WHERE image_path=?',(name,old))
                    staged.commit();f.rename(folder/'media'/name);remapped+=1
        finally:staged.close()
        safe=recovery('pre-restore')
        for f in (folder/'media').iterdir():shutil.copy2(f,MEDIA/f.name)
        src=sqlite3.connect(folder/'hanan.sqlite3');dst=connect()
        try:src.backup(dst)
        finally:src.close();dst.close()
        g['init']()
        with tx() as c:
            c.execute('DELETE FROM sessions')
            actor=u['id'] if c.execute('SELECT 1 FROM users WHERE id=?',(u['id'],)).fetchone() else None
            audit(c,actor,'backup_restored',{'recovery':safe,'restored_by':u['username']})
        try:return {'ok':True,'recovery':safe,'login_required':True,'remapped_media':remapped}
        finally:shutil.rmtree(folder,ignore_errors=True);stages.pop(p['token'],None)

    @app.post('/api/backup/factory-reset')
    async def factory_reset(request:Request):
        u=auth(request,['owner']);p=await payload(request);current_password(u,p.get('password'))
        if p.get('confirmation')!='RESET HANAN CAFE':raise HTTPException(400,'Type RESET HANAN CAFE to confirm')
        safe=recovery('pre-reset')
        with tx() as c:
            for table in ['sessions','print_jobs','inventory_movements','order_events','kitchen_tasks','order_items','order_cancellations','orders','customers','expenses','product_images','starter_registry','product_variants','products','categories','settings','audit']:c.execute('DELETE FROM '+table)
            c.execute('DELETE FROM users WHERE id!=?',(u['id'],));audit(c,u['id'],'factory_reset',{'recovery':safe})
        g['init']()
        return {'ok':True,'recovery':safe,'login_required':True}

    with tx() as c:g['ensure_pizza_sizes'](c)
