# Changelog 0.6.10 — back to the 0.6.7 base, white text only

This build returns the product cards to their original (pre-0.6.8) design and
keeps only the two requested changes below. Everything else from 0.6.7 stays:
redesigned login page, two-column staff page, sky/orange schemes, sidebar
footer, and the instant POS taps (no page reload when adding items).

## Changes (only these two)

1. Today's sales card: deep-white text instead of black, in both colour
   schemes. On the sky scheme the card background was deepened to a richer
   blue so the white text stays readable.
2. "New order" button text: deep white in both schemes on the dashboard.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=0610`; hard-refresh once (Cmd+Shift+R).
