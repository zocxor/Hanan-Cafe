# Changelog 0.6.3 — sky-blue sidebar for the White / Sky Blue scheme

## Sidebar (sky scheme only)

- The sidebar is now a rich sky-blue gradient (#B5DFFB -> #8FCFF8 -> #6FBDF3)
  instead of near-white, as requested.
- Readability verified: nav labels and footer in deep navy (#12395c/#0d2438),
  the HANAN brand keeps its dark-metallic gradient, CAFE deepened to a dark
  bronze for contrast on blue, and the active item is a white pill with dark
  text so it stands out from the blue bar.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=063`; hard-refresh once (Cmd+Shift+R).
