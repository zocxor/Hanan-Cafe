# Changelog 0.6.22 — snappier page navigation

## Performance feel

- Page entrance animation shortened from 0.5s to 0.22s — sidebar
  navigation now feels instant instead of laggy. The subtle fade/slide
  polish is kept, just much quicker.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=0622`; hard-refresh once (Cmd+Shift+R).
