# Changelog 0.6.7 — elegant login page for both schemes

## Login

- The sign-in page is redesigned to match the approved mockup: serif "Hanan"
  wordmark, letterspaced "CAFE" with accent underline, "A legacy of taste"
  tagline, pill-shaped inputs and a full-width pill "Sign in" button, plus
  the "© 2026 Zocxorian Technology · KASHIF BASHIRR RAJPUT" footer.
- The saved colour scheme is now applied immediately on boot, so the login
  page itself renders in Orange/Porcelain or White/Sky Blue (previously it
  always showed the default until after sign-in).

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=068`; hard-refresh once (Cmd+Shift+R).
