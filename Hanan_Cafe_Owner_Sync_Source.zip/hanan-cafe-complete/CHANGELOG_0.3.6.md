# Hanan Cafe v0.3.6 — Thermal print flow

- Added checkout print choice: customer bill, kitchen slip, both, or no print.
- On order confirmation, opens a dedicated thermal-width print page instead of printing the application screen.
- Combined mode lays out customer bill and kitchen slip as separate slips in one print job.
- Uses configured 58 mm / 80 mm paper width and the existing customer/kitchen receipt templates.
- Browser print dialogs and printer destination are still controlled by the browser/OS; silent direct printing to multiple printers requires a local ESC/POS print service.
