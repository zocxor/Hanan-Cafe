# Changelog 0.6.9 — sales-card white text, POS card fixes, footer

## Today's sales card (both schemes)

- All text on the "Today's sales" card is now deep white, as requested.
- In White/Sky Blue the card background is deepened to a richer blue
  (#4AA3DF -> #1E7CC4) so the white text stays clearly readable.

## POS product cards

- Food images now properly fill their photo area (were shrunk with padding).
- Price text reduced to a calmer size; long "From Rs." prices no longer
  dominate the card.
- The +/quantity icon badge is a deeper blue with white glyph in the sky
  scheme (was washed out).
- Photo area uses a neutral highlight instead of the green tint.

## Sidebar footer

- Second line now reads "© 2026 Zocxorian Technology".

## Notes

- The Menu page keeps its existing dish-card design (plus the subtle 3D
  tilt/glare); it was not restyled, per your "do it well or revert" call.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=069`; hard-refresh once (Cmd+Shift+R).
