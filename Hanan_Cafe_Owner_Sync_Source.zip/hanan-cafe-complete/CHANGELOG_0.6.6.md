# Changelog 0.6.6 — Users page two-column layout + icon actions

## Users & permissions

- The page is now two columns on desktop: the "Create staff account" form on
  the left, the staff list on the right (stacks on small screens).
- Each staff row shows details plus three icon buttons: edit (pencil),
  change photo (camera), disable/enable (power), with tooltips. The edit
  dialog still covers username, role, password change and permissions.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=068`; hard-refresh once (Cmd+Shift+R).
