# Update Hanan Cafe to v0.3.5 on macOS

1. Download and extract `Hanan_Cafe_Offline_Category_Update_v0.3.5.zip`.
2. Stop the running server with Ctrl+C.
3. Keep your original `data/` folder and `.venv315` unchanged.
4. Copy `app.py`, `static/app.js`, `static/style.css`, `README.md`, and `CHANGELOG_0.3.5.md` into your existing `~/Downloads/Hanan_Cafe/hanan-cafe-complete` folder.
5. Restart with:

```bash
cd ~/Downloads/Hanan_Cafe/hanan-cafe-complete
source .venv315/bin/activate
python -m uvicorn app:app --host 127.0.0.1 --port 8765
```

The app creates a SQLite recovery snapshot on startup under `data/recovery_snapshots/`. Also download backup ZIPs periodically and store them outside the Mac. Do not run setup.py on an existing database.
