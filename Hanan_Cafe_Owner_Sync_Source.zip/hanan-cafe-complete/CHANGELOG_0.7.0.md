# Changelog 0.7.0 — fast POS taps, calmer cards

## POS performance (the "loading" on tap)

- Tapping a product no longer rebuilds the whole page. Only the product grid
  and the cart panel refresh in place: no entrance-animation replay, no
  scroll jump, and the checkout form keeps everything you typed (customer,
  discount, notes, ...).
- Same for the cart's +/− buttons, Clear, and pizza size selection.

## Product cards

- Price text reduced to a calm readable size (was oversized).
- Food images now show complete and uncropped (contain) with a soft
  drop-shadow highlight on a neutral backdrop.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=070`; hard-refresh once (Cmd+Shift+R).
