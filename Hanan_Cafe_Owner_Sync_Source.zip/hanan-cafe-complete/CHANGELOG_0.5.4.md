# Changelog 0.5.4 — dashboard content upgrade + premium brand

## Brand

- Sidebar brand restyled: metallic gradient "HANAN" / accent-gradient "CAFE",
  wide futuristic letter-spacing, glowing accent underline, letterspaced
  uppercase tagline. Dark metallic variant for the light Sky sidebar.

## Dashboard

- New 5th metric card: **Today's sales** — accent-gradient spotlight card in
  the same row; metric row is now 5 compact cards (3 on tablet, 2+wide on
  mobile).
- Metric cards are more compact; all key numbers are bigger and more readable
  (metric values up to 52px, revenue up to 36px, donut total 38px).
- Activity bars now show each day's **sales value** under the weekday label
  (compact Rs. format), with sales in the hover tooltip; bar counts enlarged.
- Backend `/api/dashboard` now returns per-day `sales` (excludes cancelled).

## Upgrade notes

- Replace the `static/` folder and `app.py`; keep your data directory.
- Static asset versions bumped to `?v=054`; hard-refresh once after updating.
