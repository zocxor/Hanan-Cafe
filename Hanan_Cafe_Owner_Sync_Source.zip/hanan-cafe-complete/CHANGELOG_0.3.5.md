# Hanan Cafe v0.3.5

- Added category rename and archive endpoints with owner/manager authorization.
- Added category management rows with Edit and Delete (archive) actions to Menu.
- Category removal is non-destructive: historical products and orders are preserved.
- Simplified Dashboard's operating overview to a single prominent Start New Order button.
- Added distinct high-contrast blue Ready and green Complete/Delivered kitchen action buttons.
- Added a local SQLite recovery snapshot at application startup, retaining the latest 14 snapshots in `data/recovery_snapshots/`.

## Offline and data safety notes

The local application and its SQLite records operate without an internet connection as long as the Mac and local server are running. This release does not synchronize to a cloud service when internet returns because no secure cloud backend/authentication/sync protocol has been configured. Local startup snapshots are not a substitute for periodically downloading and storing backup ZIPs on another drive or secure location. Keep the `data/` directory when updating or reinstalling.
