# Changelog 0.6.4 — orange action button in the Sky scheme

## Sky scheme

- `.btn.orange` (e.g. "New order") is now a real orange gradient
  (#FB6D0D -> #E04E00) with deep-white text in the White / Sky Blue scheme,
  instead of inheriting the sky-blue accent. Orange scheme untouched.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=064`; hard-refresh once (Cmd+Shift+R).
