# Verified update: 0.4.7

## Dashboard and service layout

Dashboard now includes four daily counts, a seven-day activity chart, a status ring, recent item summaries, ready handoffs and permission-aware shortcuts. Full-database aggregation is tested with 305 isolated orders, exceeding the 300-row recent list. Date-boundary checks confirm Pakistan business time. Cancelled amounts are excluded from order value. This is order value, not payment collection.

Completed/delivered and cancelled records have distinct green/red badges on Dashboard and Orders. Cancelled records remain intact. Empty dashboard states and account permissions were tested.

Menu Studio uses compact cards and accessible edit, image, duplicate and delete icons. Browser tests verify two immediate duplicates without a name dialog. A backend test confirms a deleted copy cannot cause an automatic-name collision. Duplication leaves stock untracked; existing image/size/price copy behavior remains.

Desktop POS product scrolling is independent of the current ticket. Product scroll position is retained when an item is added. Added lines have visible accent borders and tinted backgrounds. Checkout field borders show before focus. Delivery address, expanded notes and Confirm order were verified visible at 1440×950, 1280×720 and 1024×768 without an inner form scrollbar. The cart item list can scroll for long orders; small screens use natural page scrolling.

Dashboard was checked in White/Sky Blue, Orange/Porcelain and Navy/AI Green at desktop, tablet and mobile sizes. POS was checked across five sizes in all three schemes. Receipt controls are aligned and the preview shows both slips when both are selected, and developer information appears in one panel with ZTechx / Zocxorian Technologies branding.

## Preserved functionality

The starter catalogue contains 24 products with 24 distinct transparent WebP food images. Existing products, edits, historical order snapshots, users and transactions are not replaced. No fixture database or fake operating transactions are distributed.

Service and pizza regression suites pass: contact normalization and consent, cancellation audit/refund review/optional stock return, custom-date finance, product deletion with historical snapshots, backup/restore/reset, four pizza sizes, server prices and duplication. Dashboard regression checks pass. Browser checks record zero JavaScript errors.

Customer/kitchen slips use one hidden document and one print invocation, with no extra tab; reprints were checked at 58mm and 80mm. Separate slips is the new default: each ticket starts on a new page. A continuous-roll option remains. PDF verification confirms two pages in separate mode and one in continuous mode for the short fixture. Cutting requires a compatible cutter and a driver configured to cut per page; no hardware cutter commands are sent. Physical printer output remains unverified. Native logo transparency is unchanged: the supplied logo uses screen blending on its dark panel.

Screenshots and print proofs use isolated synthetic test orders only. They are under docs/screenshots-v046. Installation: UPDATE_INSTRUCTIONS_0.4.6_MACOS.md.

## Version 0.4.6 visual checks

Expense totals are explicitly high contrast in all three themes. Navy has a green navigation bar, green total-orders card and mint status panel. New order uses a larger 18px label and 58px desktop button. Browser checks passed for expense visibility, theme colours, settings validation, print separation and responsive layouts. Physical cutting remains unverified.

## Contacts and compact settings

Customer deletion has backend authorization and confirmation UI. Tests verify cancel/keep, removal of only one selected contact, reload persistence, cashier and anonymous denial, and historical order preservation. A contact can be saved again by a new future order.

Cafe profile/receipt settings and My profile now sit side by side on desktop. Compact fields reduce card size; narrow layouts stack the cards. UI preference save/reload and nonzero expense entry were verified. The Rs. 1,250 fixture total meets at least 4.5:1 text contrast in each of the three themes.

## Backup import repair in 0.4.7

Dedicated regression tests restored a valid generated archive with a different owner ID and a media filename collision. Restore completed, the imported image bytes matched the backup, the prior live image bytes were preserved, the safety backup remained downloadable, and login worked after session invalidation. Invalid archives were rejected. Browser testing covered actual backup download, file selection, persistent invalid-file error, valid verification, password/phrase confirmation, sign-out, login, 24 products and the recovery archive. No JavaScript errors were recorded. The existing service backup/restore/reset regression suite was rerun.

These checks cover isolated fixtures; the user's failing backup has not been supplied, so compatibility of that exact file is not yet verified. Retain the original backup file. Installation/import steps: UPDATE_INSTRUCTIONS_0.4.7_MACOS.md.
