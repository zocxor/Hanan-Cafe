# Cloud integration status

Firebase project reference supplied by the owner:
- Project ID: `hanans-cafe`
- Project number: `271178654673`

These identifiers do not authenticate an application and do not by themselves enable a connection. This release intentionally remains local-first and does not write data to Firebase. Before cloud sync is implemented, choose the authoritative cloud database/API, define offline conflict resolution and idempotency, configure least-privilege credentials outside the client bundle, and test data isolation and backups.

Payment methods in this app are recordkeeping labels only. Cash received is entered manually. Bank transfer, wallet, and other methods are not initiated, settled, or verified by this app.
