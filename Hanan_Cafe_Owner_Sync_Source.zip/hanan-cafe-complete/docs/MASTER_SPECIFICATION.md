# HANAN CAFE — ULTIMATE MASTER DEVELOPMENT PROMPT
## Complete Restaurant Operating System, POS, Customer Ordering, Kitchen Display, Parcel & Delivery, Inventory, Accounting, Owner Dashboard, Windows Application, Backup & Disaster Recovery

**Project name:** Hanan Cafe  
**Company name:** Ztech  
**Developer name:** KASHIIF BASHIRR RAJPUT  
**Contact number:** +92 300 1814159  
**Copyright:** © 2026 Ztech. All rights reserved.  
**Initial business model:** Single restaurant, architected for future multi-branch expansion.  
**Primary target:** Windows desktop POS with local-first operation, customer ordering through a responsive website/PWA, and secure remote management through an Android-compatible owner dashboard.  
**Technology objective:** Modern, maintainable, secure, professionally designed software built primarily with free and open-source tools, avoiding unnecessary recurring subscriptions.

---

# PART A — MANDATORY PROJECT EXECUTION INSTRUCTIONS

## 1. Act as the complete engineering team

Act as a senior software architect, full-stack engineer, desktop application engineer, database architect, cybersecurity engineer, UI/UX designer, QA automation engineer, DevOps engineer and restaurant operations consultant.

Your responsibility is to implement a working restaurant management system, not merely create a design, architecture document, demonstration, prototype or collection of static screens.

The final system must be practical for actual restaurant staff using it during busy service periods.

### Mandatory development behaviour

1. Inspect the current project before changing it.
2. Identify the existing framework, application entry points, dependencies, database, authentication, storage, build tools, deployment configuration and current functionality.
3. Preserve working features and valuable data.
4. Identify defects, missing modules, security problems, duplicate implementations and architectural inconsistencies.
5. Reuse existing working components where appropriate.
6. Avoid unnecessary rewrites and incompatible dependency upgrades.
7. Create an implementation checklist and track progress.
8. Implement features in coherent, testable increments.
9. Run tests after meaningful changes and resolve regressions.
10. Never report success simply because a button, screen or endpoint exists.
11. Never use a fake successful response as a substitute for a real database operation, payment, print job, backup, restore or synchronization.
12. Never silently remove functionality that already works.
13. Never invent the restaurant's actual menu, product prices, stock quantities, supplier balances, tax rates or financial records.
14. Use clearly labelled test data only in a development environment.
15. Keep production and test environments separate.
16. Document all necessary external accounts, credentials, devices and services.
17. Use reasonable technical defaults when requirements are incomplete.
18. Ask for clarification only when a missing fact materially affects a business rule, irreversible operation, hardware integration or deployment decision.
19. Do not stop after planning or generating the first screen.
20. Continue through implementation, testing, packaging and documentation to the extent the available environment permits.

### First task

Inspect the repository and report:

- Existing application structure.
- Existing framework and versions.
- Current working features.
- Current database and storage.
- Existing authentication and authorization.
- Current build and deployment process.
- Current desktop packaging, if any.
- Existing product-image handling.
- Existing backup functionality.
- Existing tests.
- Missing requirements.
- Critical risks.
- Recommended implementation order.

Then start implementing the actual project. Do not wait for approval for routine, reversible engineering decisions.

---

# PART B — PRODUCT VISION AND APPLICATION ARCHITECTURE

## 2. Build one integrated Hanan Cafe ecosystem

Create a coherent restaurant operating system with shared business rules, consistent permissions and a reliable source of truth.

The system consists of the following interfaces.

### 2.1 Customer ordering application

A responsive customer website and installable Progressive Web App.

Customers can:

- Browse the actual Hanan Cafe menu.
- Search products.
- View categories and product images.
- Select variants and add-ons.
- Add products to a cart.
- Add item-specific instructions.
- Select parcel pickup or home delivery.
- Enter the required contact and fulfilment details.
- See applicable discounts, delivery fees, taxes and the final total.
- Select an available payment method.
- Place an order.
- Receive an order reference.
- Track available order-status updates.
- Review order history when customer accounts are enabled.
- Reorder previous purchases where products remain available.

### 2.2 Windows POS and administration

Build a professional Windows application that can be packaged as an installer or `.exe` distribution.

It includes:

- POS.
- Order management.
- Product and category management.
- Product-image editing.
- Kitchen operations.
- Parcel management.
- Delivery management.
- Rider assignment.
- Receipt printing.
- Kitchen-ticket printing.
- Inventory and recipes.
- Suppliers and purchasing.
- Expenses.
- Payments and refunds.
- Cash shifts.
- Financial reports.
- User and permission management.
- Backup and restoration.
- System settings.
- Audit history.

### 2.3 Owner dashboard

Create a responsive owner interface that works on Android phones, tablets and desktop browsers.

It provides authorized access to:

- Live order monitoring.
- Sales summaries.
- Parcel and delivery status.
- Kitchen backlog.
- Rider assignments.
- Stock alerts.
- Product availability.
- Expense summaries.
- Cash reconciliation.
- Staff activity.
- Printer status where available.
- Backup status.
- Reports and approvals.
- Important system warnings.

### 2.4 Kitchen display

Provide a separate kitchen interface optimized for a dedicated monitor or tablet.

It must emphasize large text, visible order age, special instructions, preparation stations and fast status changes.

### 2.5 Future expansion

Start with one cafe but structure the system to support additional branches later.

Future branch support should include:

- Branch-specific settings.
- Branch-level inventory.
- Branch-specific printers and kitchen stations.
- Branch-level orders and expenses.
- Consolidated reporting.
- Controlled cross-branch permissions.
- Data isolation.

Do not implement complex multi-branch functionality unnecessarily in the first release, but avoid architectural decisions that make expansion prohibitively expensive.

---

# PART C — DESIGN SYSTEM AND BRANDING

## 3. Hanan Cafe visual identity

Create a distinctive, polished restaurant-management interface. Avoid generic admin dashboards and excessive decorative effects.

### 3.1 Exact brand colours

Use these colour tokens consistently.

| Token | Hex |
|---|---|
| Forest Green | `#163C2B` |
| Warm Cream | `#F7F2E8` |
| Tangerine Orange | `#F47B35` |
| Charcoal | `#282C29` |
| Secondary Text | `#646B65` |
| White | `#FFFFFF` |
| Success | `#18794E` |
| Warning | `#A65D00` |
| Error | `#B42318` |
| Light Border | `#E6E0D5` |

Define reusable CSS variables or equivalent theme tokens. Avoid scattered, inconsistent hardcoded colours.

### 3.2 Visual composition

Use the intended balance:

- Approximately 70% clean functional UI.
- Approximately 20% selective Liquid Glass.
- Approximately 10% selective Claymorphism.

Use Liquid Glass for selected floating navigation, cart summaries, overlays and compact dashboard elements.

Use Claymorphism for selected category tiles, promotions or primary action elements.

Do not apply decorative effects indiscriminately. POS, kitchen, inventory and financial interfaces must prioritize clarity, speed and readability.

### 3.3 Typography and components

Use a clean typeface such as Inter, subject to licence and delivery requirements.

Establish consistent:

- Heading hierarchy.
- Body typography.
- Form controls.
- Buttons.
- Inputs.
- Tables.
- Cards.
- Dialogs.
- Drawers.
- Navigation.
- Badges.
- Notifications.
- Charts.
- Loading indicators.
- Empty states.
- Error messages.

Use Lucide icons or another properly licensed icon set.

### 3.4 Animation

Use Motion for React where it improves the experience.

Animations must be restrained and purposeful. Respect reduced-motion settings. Do not delay checkout, order acceptance, kitchen status changes or other important operations with decorative transitions.

### 3.5 Responsive layouts

Optimize separately for:

- Desktop POS.
- Laptop administration.
- Kitchen display.
- Tablet.
- Android owner dashboard.
- Customer mobile ordering.
- Customer desktop ordering.

Do not merely compress desktop tables onto mobile screens.

### 3.6 Theme preferences

Support light and dark themes with persistent user preferences.

Ensure sufficient contrast in both themes, including:

- Disabled controls.
- Error states.
- Tables.
- Charts.
- Form placeholders.
- Modal dialogs.
- Status indicators.

### 3.7 Accessibility

Implement:

- Keyboard navigation.
- Focus indicators.
- Accessible labels.
- Appropriate touch targets.
- Screen-reader-friendly controls.
- Form error associations.
- Reduced-motion support.
- Meaningful status announcements.
- Non-colour-only status identification.

### 3.8 Branding information

Use these details exactly.

**Application:** Hanan Cafe  
**Company:** Ztech  
**Developer:** KASHIIF BASHIRR RAJPUT  
**Contact:** +92 300 1814159  
**Copyright:** © 2026 Ztech. All rights reserved.

Create a dedicated Settings section called **Company & Developer Information**.

Include:

- Company name.
- Application name.
- Developer name.
- Contact number.
- Copyright.
- Application version.
- Build number.
- Open-source notices.
- Privacy policy and terms links once implemented.

Add a working copy-to-clipboard control for the phone number.

Display discreet company credit on the login screen, About screen, application sidebar, appropriate PDF reports and optional receipt footer.

Keep Hanan Cafe as the customer-facing brand and Ztech as the software-company identity.

Only authorized users may change editable branding information. Do not invent a logo; use supplied assets or professional text-based branding.

---

# PART D — TECHNOLOGY STACK AND LONG-TERM COST CONTROL

## 4. Technology selection rules

Use current, mutually compatible stable releases available at implementation time. Verify current official documentation, security status, compatibility, maintenance and licence before adding a dependency.

Preferred options:

### Frontend

- React.
- TypeScript with strict mode.
- Next.js App Router where suitable.
- Tailwind CSS.
- shadcn/ui.
- Radix UI.
- Lucide.
- Motion for React.
- Floating UI where appropriate.
- Zod or equivalent schema validation.

Additional UI libraries must be selected selectively, not installed merely because they are fashionable.

### Desktop

Electron is a suitable option for packaging the React application as a Windows application.

Configure it securely:

- Context isolation enabled.
- Node integration disabled in renderer processes.
- Strict Content Security Policy.
- Restricted preload APIs.
- Validated IPC messages.
- No unrestricted shell execution from renderer content.
- Controlled filesystem access.
- Secure handling of external links.
- No untrusted remote content in privileged windows.

Use an appropriate installer and update strategy. Verify the actual Windows packaging process.

### Database

#### Local-first edition

Use SQLite for local restaurant operations when appropriate.

Use:

- Parameterized queries.
- Database transactions.
- Foreign-key constraints.
- Unique constraints.
- Appropriate indexes.
- Versioned migrations.
- Integrity checks.
- Explicit transaction ownership.
- Controlled write access.

Place the database under the operating system's appropriate application-data directory, not inside the installation directory.

#### Connected edition

For customer online ordering and remote owner monitoring, use a secure cloud architecture with PostgreSQL and a suitable authenticated API/backend.

Supabase or a self-hostable equivalent may be used after evaluating the actual architecture, cost and current terms.

Use one authoritative source of truth for connected operations. Avoid independently writable local and cloud databases without a defined synchronization protocol.

### Validation and testing

Use suitable tools such as:

- Zod.
- Vitest.
- Testing Library.
- Playwright.
- ESLint.
- TypeScript checks.
- Dependency auditing.
- Automated security checks.

### Image processing

Use a maintained image-processing library such as Sharp where its licence, runtime compatibility and packaging support are suitable.

### Reporting and exports

Use appropriately licensed maintained libraries for CSV, PDF and charting.

### Free and open-source policy

Prefer mature tools that can be used commercially without recurring licence fees.

Do not introduce paid UI kits, mandatory AI APIs, proprietary icons, per-export fees or subscription-only dependencies without a compelling reason and explicit approval.

Verify the licence of every dependency. Maintain a dependency inventory and applicable notices.

Never promise that third-party services will remain free forever.

---

# PART E — LOCAL-FIRST AND CLOUD ARCHITECTURE

## 5. Separate local operation from remote services

The application must be honest about what can operate without internet access.

### 5.1 Local capabilities

The local Windows installation should support the following wherever technically appropriate:

- POS.
- Local orders.
- Product and menu management.
- Kitchen display.
- Local receipt printing.
- Inventory.
- Expenses.
- Cash management.
- Reports.
- Staff permissions.
- Product-image storage.
- Local backups.
- Local restoration.

### 5.2 Connected capabilities

A secure cloud or remote-access architecture is needed for:

- Public customer online ordering.
- Owner access from outside the cafe.
- Cross-device synchronization.
- Remote backup storage.
- Online payment integration.
- External messaging.
- Multi-branch synchronization.

Make connected features optional modules where practical.

Do not expose a local SQLite database or unrestricted database port to the public internet.

### 5.3 Synchronization

If offline operations and cloud synchronization are supported:

- Use stable unique identifiers.
- Use idempotent operations.
- Define conflict-resolution policies.
- Use safe retry logic.
- Track pending operations.
- Track the last successful synchronization.
- Prevent duplicate orders and duplicate stock deductions.
- Preserve immutable transaction history.
- Log synchronization failures.
- Provide controlled recovery tools.

Never silently overwrite newer financial data with an older version.

Clearly indicate online, offline, syncing, failed and stale-data states.

---

# PART F — DATABASE AND DATA INTEGRITY

## 6. Database architecture

Design the database before implementing dependent features.

Use versioned migrations and explicit relationships.

Potential entity groups include:

- Business and branch configuration.
- Users.
- Roles.
- Permissions.
- User-role assignments.
- Categories.
- Products.
- Product variants.
- Add-ons.
- Product images.
- Image history.
- Prices and price history.
- Customers.
- Customer addresses.
- Orders.
- Order items.
- Order-item modifiers.
- Order status history.
- Payments.
- Refunds.
- Discounts.
- Taxes.
- Delivery zones.
- Delivery assignments.
- Riders.
- Kitchen stations.
- Kitchen tasks.
- Printer configuration.
- Print jobs.
- Ingredients.
- Recipes.
- Stock items.
- Stock movements.
- Suppliers.
- Purchase orders.
- Goods received.
- Supplier invoices.
- Supplier payments.
- Expenses.
- Cash shifts.
- Cash movements.
- Approvals.
- Audit logs.
- Backup jobs.
- Application settings.
- Integration configuration.

Adapt the schema to the actual architecture instead of creating unnecessary tables.

### 6.1 Transaction integrity

Use transactions for operations that must succeed or fail together.

For example, order creation must not create a partial order with missing items or inconsistent totals.

A stock deduction and its corresponding movement record must be consistent.

A refund must be linked to its original payment and recorded exactly once.

### 6.2 Historical snapshots

When an order is created, preserve the necessary historical values, including:

- Product name.
- SKU where applicable.
- Variant.
- Modifiers.
- Quantity.
- Unit price.
- Discount.
- Tax treatment.
- Line total.
- Relevant fulfilment instructions.

Later product edits must not rewrite completed transaction history.

### 6.3 Deletion policy

Use archive and restore for business records where appropriate.

Do not permanently delete completed, paid, printed, refunded or otherwise financially significant transactions.

Correct errors through traceable reversal or adjustment records.

### 6.4 Database maintenance

Implement:

- Schema migrations.
- Referential integrity.
- Appropriate indexes.
- Query optimization.
- Database integrity checks.
- Recoverable maintenance procedures.
- Version compatibility checks.

Do not perform destructive migrations without a verified recovery path.

---

# PART G — CUSTOMER ORDERING

## 7. Complete customer experience

### 7.1 Menu

Build:

- Home page.
- Cafe details.
- Opening hours.
- Category navigation.
- Product search.
- Product cards.
- Product detail view.
- Product images.
- Variants.
- Add-ons.
- Availability.
- Sold-out state.
- Product notes.
- Cart.
- Checkout.
- Order confirmation.
- Order tracking.

Use real database content rather than hardcoded menu items.

### 7.2 Pricing

Recalculate totals on the trusted side.

For each item, calculate applicable:

- Quantity.
- Unit price.
- Modifier prices.
- Line discounts.
- Applicable tax.
- Line total.

For each order, calculate:

- Subtotal.
- Order-level discounts where allowed.
- Applicable tax.
- Delivery fee.
- Other configured charges.
- Final total.

Document the exact rounding and discount-allocation policy. Avoid double-counting tax or discounts.

### 7.3 Checkout

Support configurable:

- Guest checkout.
- Customer account checkout.
- Customer name.
- Contact number.
- Address.
- Delivery zone.
- Delivery fee.
- Parcel pickup.
- Requested pickup time.
- Requested delivery time.
- Order notes.
- Payment method.
- Terms or policies where appropriate.

Validate opening hours, availability, prices, product quantities and delivery rules.

Do not promise a delivery time the cafe has not accepted.

### 7.4 Customer history

Where accounts are enabled, support order history, order status, previous purchases, reordering and saved addresses.

Implement reasonable privacy and account-deletion procedures.

### 7.5 PWA

Implement a valid manifest, appropriate icons, responsive design and safe service-worker caching.

Do not cache sensitive customer records indiscriminately.

If an order is created offline and queued, clearly label it as pending until the server confirms receipt.

---

# PART H — POINT OF SALE

## 8. Fast operational POS

Design the POS for rapid use during busy service periods.

Include:

- Product search.
- Category filters.
- Product tiles.
- Variants and add-ons.
- Quantity changes.
- Item notes.
- Cart editing.
- Order type.
- Customer details.
- Delivery information.
- Discounts.
- Tax.
- Delivery fees.
- Totals.
- Payment method.
- Payment status.
- Order confirmation.
- Receipt printing.
- Order history.
- Draft or held orders where appropriate.

### 8.1 Order types

Support:

1. Counter.
2. Parcel/takeaway.
3. Home delivery.

Keep order type, fulfilment status and payment status separate.

### 8.2 Operational safeguards

- Prevent duplicate order submission.
- Use idempotency keys.
- Recalculate totals on the trusted side.
- Validate stock where stock tracking is enabled.
- Record the cashier.
- Record timestamps.
- Validate status transitions.
- Prevent unauthorized discounts and voids.
- Preserve financial snapshots.
- Handle recoverable network errors.
- Display offline and sync status.

### 8.3 Cancellation and correction

Require appropriate permissions and reasons.

Preserve the original transaction and record the correction.

Do not erase completed orders to make reports look correct.

---

# PART I — PARCEL AND DELIVERY

## 9. Parcel management

Implement the configurable lifecycle:

Received → Confirmed → Preparing → Packing → Ready for Pickup → Collected.

Support rejected orders, cancellations, failed pickups and exceptions through explicit rules.

Display:

- Order number.
- Customer.
- Items.
- Order age.
- Requested pickup time.
- Payment status.
- Preparation status.
- Notes.
- Collection confirmation.

## 9.1 Home delivery

Implement:

Received → Confirmed → Preparing → Packing → Ready for Dispatch → Rider Assigned → Out for Delivery → Delivered.

Also support:

- Failed delivery.
- Returned to cafe.
- Rider reassignment.
- Cancellation.
- Delivery exception.
- Payment exception.
- Cash reconciliation.

## 9.2 Filters

Support filters for:

- Date.
- Order number.
- Customer.
- Status.
- Order type.
- Payment status.
- Rider.
- Delivery zone.

Enforce valid state transitions and retain status history.

---

# PART J — KITCHEN DISPLAY SYSTEM

## 10. Kitchen operations

Build a dedicated kitchen interface with large text, high contrast and clear status controls.

Each ticket should show:

- Order number.
- Received time.
- Elapsed time.
- Product names.
- Quantities.
- Variants.
- Modifiers.
- Preparation instructions.
- Order type.
- Preparation station.
- Current status.
- Configured urgency indicators.

### 10.1 Stations

Support configurable stations based on the actual menu, such as:

- Main kitchen.
- Grill.
- Fryer.
- Drinks.
- Packing.

Do not assume every station is required.

### 10.2 Workflow

Allow authorized staff to:

- Accept orders.
- Start preparation.
- Complete individual tasks.
- Flag unavailable ingredients.
- Report exceptions.
- Request corrections.
- Complete packing.
- Mark orders ready when all required work is finished.

Keep station-level and order-level completion consistent.

### 10.3 Alerts

Use optional visual and audible alerts where supported.

Avoid repeating alerts unnecessarily.

Provide acknowledgement controls and configurable thresholds.

Persist status changes and recover the display after refresh or restart.

---

# PART K — PRINTING AND RECEIPTS

## 11. Printer integration

Support common thermal printers, particularly 80 mm devices, while allowing configuration for other supported sizes.

Inspect the real hardware and operating system before selecting the printing implementation.

Possible approaches include:

- Native operating-system printing.
- Browser print.
- Local print agent.
- ESC/POS integration.
- Network printing.

Choose the approach based on compatibility and reliability.

### 11.1 Print queue

Implement:

- Printer configuration.
- Connection status where detectable.
- Test print.
- Receipt preview.
- Kitchen-ticket preview.
- Manual print.
- Authorized reprint.
- Queue.
- Retry.
- Error reporting.
- Print history.
- Duplicate protection.
- Printer-specific formatting.

Track states such as queued, submitted, confirmed when genuinely supported, failed and outcome unknown.

Do not claim the physical printer produced a document merely because a print command was sent.

### 11.2 Receipt format

Include applicable:

- Hanan Cafe name and logo if supplied.
- Order reference.
- Date and time.
- Order type.
- Products.
- Modifiers.
- Quantities.
- Unit prices.
- Discounts.
- Tax.
- Delivery fee.
- Total.
- Payment method.
- Payment status.
- Customer information needed for fulfilment.
- Configurable footer.
- Optional “Powered by Ztech”.

Kitchen tickets should exclude unnecessary sensitive financial details.

---

# PART L — RIDER MANAGEMENT

## 12. Delivery operations

Support:

- Rider profile.
- Contact information.
- Active/inactive status.
- Availability.
- Order assignment.
- Reassignment.
- Assigned deliveries.
- Delivery progress.
- Delivery history.
- Failed-delivery reasons.
- Cash collected.
- Cash reconciliation.
- Performance summaries.

Restrict riders to authorized information.

GPS tracking is not required initially. If added later, implement appropriate consent, access controls and privacy safeguards.

---

# PART M — PRODUCTS, MENU IMPORT AND IMAGES

## 13. Product management

Provide product fields for:

- Name.
- Description.
- Category.
- SKU.
- Image.
- Selling price.
- Cost price where available.
- Variants.
- Add-ons.
- Tax configuration.
- Recipe.
- Preparation station.
- Availability.
- Sales-channel availability.
- Scheduling.
- Stock tracking.
- Active/draft/archived status.

Support creation, editing, archiving, restoration, safe deletion of unused drafts, search, sorting, filtering, import, export, duplicate detection and price history.

### 13.1 Real menu import

The actual Hanan Cafe menu images will be supplied separately.

Create an import workflow that accepts supported images, extracts candidate text and prices with available OCR, and displays them for manual verification.

The workflow must:

1. Upload the source image.
2. Extract candidate text.
3. Show the source beside extracted fields.
4. Flag uncertain names and prices.
5. Allow manual correction.
6. Identify duplicates and missing values.
7. Require approval before publishing.
8. Preserve source references.
9. Import approved records.
10. Report validation errors.

Never publish uncertain prices without approval.

Do not invent products before receiving the real menu.

## 13.2 Product-image editing

Every product must provide:

- Add Image.
- Upload New Image.
- Change Image.
- Edit Image.
- Preview Image.
- Remove Image.
- Restore Previous Image where retained.
- Choose Existing Image from an authorized library where available.

Make image actions accessible from the product editor and appropriate product details or card menus.

### 13.3 Image editor

Provide, where practical:

- Preview before saving.
- Crop.
- Reposition.
- Rotate.
- Aspect ratio.
- Fit and fill.
- Cancel.
- Confirm replacement.
- Clear success and error messages.

Do not destroy the current image until the replacement has been validated and successfully saved.

### 13.4 Image security and storage

- Accept JPG, PNG and WebP.
- Validate actual file content, dimensions and size.
- Use unique filenames.
- Prevent path traversal.
- Reject executable or invalid uploads.
- Process images safely.
- Strip unnecessary metadata where appropriate.
- Generate optimized variants.
- Avoid using full-resolution images in every product tile.
- Store files in managed persistent storage.
- Include product images in backups.

Record image changes and retain previous images where practical.

Changing a product image must not modify historical financial records.

---

# PART N — INVENTORY AND PURCHASING

## 14. Inventory

Support:

- Stock items.
- Ingredients.
- Units of measure.
- Categories.
- Opening balances.
- Receipts.
- Stock adjustments.
- Stock counts.
- Transfers where applicable.
- Wastage.
- Spoilage.
- Damaged stock.
- Purchase receipts.
- Recipe consumption.
- Low-stock thresholds.
- Stock movement history.
- Inventory valuation.

### 14.1 Recipes

Support validated recipes and ingredient quantities when the cafe provides them.

Deduct stock according to a documented policy and prevent duplicate deduction when requests are retried.

Do not invent recipes or stock quantities.

### 14.2 Costing

Use a documented method such as weighted-average costing when appropriate.

Calculate reliable cost of goods sold only when required costs and recipe data are sufficiently complete.

Clearly identify missing or estimated data.

## 14.3 Suppliers and purchases

Support:

- Supplier records.
- Purchase orders.
- Approval.
- Goods received.
- Supplier invoices.
- Returns.
- Supplier payments.
- Outstanding payables where enabled.
- Purchase history.
- Documents.
- Reports.

Prevent duplicate recording of an invoice and its payment as two expenses.

Keep stock receipts, supplier liabilities and payments linked correctly.

---

# PART O — EXPENSES AND FINANCIAL CONTROLS

## 15. Expense register

Provide configurable categories such as rent, utilities, salaries, packaging, delivery, repairs and cleaning.

Record:

- Amount.
- Category.
- Date.
- Due date.
- Payment date.
- Supplier/payee.
- Payment method.
- Attachment.
- Notes.
- Approval status.
- Payment status.
- Creator.
- Approver.
- History.

Use audited corrections for paid or approved expenses rather than silent deletion.

Distinguish an incurred expense from a cash payment.

## 15.1 Cash management

Support:

- Opening float.
- Cash sales.
- Cash refunds.
- Cash expenses.
- Deposits.
- Withdrawals.
- Expected closing cash.
- Actual closing cash.
- Overages.
- Shortages.
- Explanations.
- Shift opening and closing.

Digital payments must not be counted as physical cash.

## 15.2 Payment methods

Support configurable cash, bank transfer, digital wallets and integrated online payments where available.

Payment status must be separate from order status.

Never store prohibited card credentials.

Prevent duplicate payment and refund processing.

## 15.3 Refunds and voids

Support full and partial refunds where appropriate, approval, reasons, original transaction references, financial reversals and audit history.

Do not mark an order paid because a payment method was selected.

Use payment-provider idempotency features when available.

---

# PART P — REPORTING AND ACCOUNTING

## 16. Reporting periods

Support:

- Hourly.
- Daily.
- Weekly.
- Monthly.
- Quarterly.
- Yearly.
- Financial year.
- Custom date range.
- Comparison with an equivalent previous period.

Make timezone, opening hours, week start and financial-year boundaries configurable.

Handle midnight boundaries and time zones consistently.

## 16.1 Required reports

Provide:

- Sales summary.
- Order count.
- Average order value.
- Gross sales.
- Discounts.
- Voids and cancellations.
- Refunds.
- Taxes.
- Delivery fees.
- Net sales.
- Product performance.
- Category performance.
- Order-type performance.
- Payment-method performance.
- Cashier performance.
- Shift reports.
- Kitchen backlog.
- Delivery performance.
- Expense reports.
- Stock and wastage reports.
- Supplier purchases.
- Payables where enabled.
- Cash reconciliation.
- Audit reports.

## 16.2 Financial definitions

Document formulas for:

- Gross sales.
- Discounts.
- Refunds.
- Tax.
- Delivery charges.
- Net sales.
- Cost of goods sold.
- Gross profit.
- Gross margin.
- Operating expenses.
- Operating profit.
- Net profit where sufficient information exists.

Sales are not profit.

Cash in the drawer is not the same as revenue.

Do not double-count supplier payments, refunds, taxes or inventory movements.

If costs are incomplete, clearly mark profit figures as incomplete or unavailable rather than inventing values.

## 16.3 Exports

Provide CSV and PDF exports.

Apply the same permissions and data filters to exports as to the underlying report.

Use readable tables, correct totals, date ranges, currency formatting and appropriate company branding.

---

# PART Q — OWNER DASHBOARD

## 17. Android-compatible dashboard

Build a mobile-first dashboard displaying actual authorized data.

Include:

- Today's sales.
- Orders received.
- Active orders.
- Completed orders.
- Parcel orders.
- Delivery orders.
- Cancellations.
- Refunds.
- Average order value.
- Expense summaries.
- Cash status.
- Kitchen backlog.
- Rider assignments.
- Low-stock warnings.
- Sold-out products.
- Staff activity.
- Printer status where detectable.
- Last successful backup.
- Backup warnings.
- Synchronization status.
- Recent audit events.

Provide navigation from summary cards to detailed records.

Allow authorized users to change product availability, monitor orders and approve requests.

Do not expose sensitive financial data to unauthorized roles.

Display the timestamp of the latest data and clearly indicate stale or disconnected information.

Remote dashboard access must use secure authentication and a protected backend.

---

# PART R — USER MANAGEMENT AND PERMISSIONS

## 18. Role-based access control

Provide suggested roles:

- Owner.
- Technical Administrator.
- General Manager.
- Shift Supervisor.
- Cashier.
- Senior Cashier.
- Kitchen Manager.
- Chef/Cook.
- Preparation Station Staff.
- Packer.
- Delivery Coordinator.
- Rider.
- Inventory Manager.
- Storekeeper.
- Accountant.
- Customer Support.
- Auditor/Read-Only.

Allow authorized administrators to define custom roles.

## 18.1 Granular permissions

Separate permissions for:

- View.
- Create.
- Edit.
- Archive.
- Safe deletion.
- Approve.
- Reject.
- Cancel.
- Void.
- Refund.
- Discount.
- Export.
- Print.
- Reprint.
- Manage users.
- Manage roles.
- Manage settings.
- Change prices.
- Adjust stock.
- Approve purchases.
- Manage expenses.
- View financial reports.
- Manage backups.
- Restore backups.
- Manage company branding.
- Manage security settings.

Do not give every administrator automatic access to all financial operations.

Enforce authorization in trusted backend or desktop services, not only in the frontend.

Prevent privilege escalation and unauthorized self-approval.

Maintain an audit trail for privileged changes.

---

# PART S — BACKUP, RESTORE AND DISASTER RECOVERY

## 19. Critical requirement: fully functional backup system

Implement a real backup and restoration subsystem under Settings.

### 19.1 Backup actions

Provide:

- Create Backup Now.
- Manual Backup.
- Scheduled Backup.
- Daily Schedule.
- Weekly Schedule.
- Monthly Schedule.
- Pre-Update Backup.
- Pre-Restore Safety Backup.
- Export Backup.
- Backup History.
- Verify Backup.
- Test Restore.
- Restore Backup.
- Retention Settings.
- Destination Configuration.

### 19.2 Backup data coverage

Include all essential records and related media:

- Products.
- Categories.
- Variants.
- Add-ons.
- Prices.
- Product images.
- Image history.
- Orders.
- Order items.
- Historical financial snapshots.
- Customers.
- Payments.
- Refunds.
- Delivery.
- Riders.
- Kitchen settings.
- Inventory.
- Recipes.
- Stock movements.
- Suppliers.
- Purchases.
- Expenses.
- Cash shifts.
- Users.
- Roles.
- Permissions.
- Application settings.
- Printer configuration.
- Audit logs.
- Other essential application data.

Never silently omit data. Clearly identify included, excluded and unsupported categories.

Exclude plaintext passwords, authentication tokens, recovery secrets and payment-card details.

### 19.3 Backup archive

Create a versioned archive containing a database export, media, manifest and required metadata.

Record:

- Backup identifier.
- Creation time.
- Application version.
- Schema version.
- Format version.
- Included categories.
- Record and file counts.
- File sizes.
- Integrity hashes.
- Encryption status.
- Warnings and exclusions.

### 19.4 Encryption

Use an established authenticated encryption implementation.

Handle keys safely. Explain how the owner can retain recovery credentials.

Do not store the only decryption key inside the backup.

Do not claim an encrypted backup is recoverable without the required key.

### 19.5 Storage

Support local backup directories, removable drives and selected destinations.

Add an optional cloud-storage adapter for connected deployments.

Keep backups and operational data outside the application installation directory.

### 19.6 Restore process

Implement this safety sequence:

1. Select backup.
2. Validate file type and structure.
3. Verify integrity hashes.
4. Validate encryption and compatibility.
5. Display a backup preview and manifest.
6. Show available record counts and media information.
7. Explain that restoration may replace current data.
8. Require explicit authorization and confirmation.
9. Create and verify a safety backup of current data.
10. Restore into staging or temporary storage where possible.
11. Validate database integrity and relationships.
12. Verify required files and schema compatibility.
13. Apply the restore through a controlled transaction or recoverable swap.
14. Verify essential application modules.
15. Record the outcome in the audit log.
16. Roll back where possible if restoration fails.

Never report success before verification.

Never merge incompatible data blindly.

If safe restoration cannot proceed, stop without silently destroying recoverable data.

### 19.7 Scheduling and retention

Show:

- Last successful backup.
- Next scheduled backup.
- Backup size.
- Backup status.
- Verification result.
- Failures.
- Destination status.

Support configurable retention, for example:

- Last 7 daily backups.
- Last 4 weekly backups.
- Last 12 monthly backups.

These are defaults, not mandatory limits.

Do not delete the last verified recovery copy.

Prevent conflicting backup and restore jobs.

Handle interrupted jobs safely and never mark incomplete archives as successful.

### 19.8 Restore verification

Test an actual restoration into a clean test environment.

Compare:

- Record counts.
- Critical financial totals.
- Product image hashes.
- Important relationships.
- Application startup.
- Access-control integrity.
- Essential workflows.

Also test corrupted archives, incompatible versions, incorrect passwords, interrupted jobs and failed restores.

Document how to recover from a disk failure, damaged computer, accidental deletion and application reinstall.

Do not claim protection against every possible disaster.

---

# PART T — SECURITY AND PRIVACY

## 20. Application security

Implement appropriate protections against:

- SQL injection.
- Cross-site scripting.
- Cross-site request forgery where applicable.
- Broken access control.
- Insecure direct object references.
- Session theft.
- Brute-force attacks.
- Privilege escalation.
- Unsafe uploads.
- Path traversal.
- Dependency vulnerabilities.
- Exposed secrets.
- Unsafe Electron IPC.
- Unauthorized exports.
- Duplicate financial operations.
- Malicious backup files.

### Required controls

- Secure authentication.
- Appropriate password hashing.
- Session expiration and revocation.
- Rate limiting.
- Input validation.
- Parameterized queries.
- Output encoding.
- Secure cookies where applicable.
- Appropriate security headers.
- Least-privilege permissions.
- Secrets outside frontend code.
- Protected privileged operations.
- Audit logs.
- Secure backup handling.
- Dependency scanning.
- Secure deployment guidance.

Provide MFA where supported and appropriate for privileged accounts.

Never expose database service-role keys or administrative secrets in client-side bundles.

Never expose a local database directly to the public internet.

### Privacy

Collect only necessary customer data.

Restrict customer addresses and contact information to authorized staff.

Provide appropriate retention, export and deletion procedures.

Use encrypted network connections for remote services and suitable local-data protection.

Do not log passwords, tokens or sensitive payment information.

Do not claim that the system is completely secure.

---

# PART U — PERFORMANCE, RECOVERY AND OPERATIONS

## 21. Performance

Design for reliable daily operation on practical cafe hardware.

Engineering targets for testing, not unconditional guarantees:

- Immediate feedback for local interactions.
- Typical indexed search below approximately 300 ms on suitable hardware.
- Order updates around one second on a healthy connection where supported.
- Optimized images.
- Indexed database queries.
- Pagination or virtualization for large lists.
- Controlled background operations.
- Safe retry and reconnect behaviour.
- Responsive interfaces.
- No unnecessary animation in critical workflows.

Benchmark actual performance and report the results.

## 21.1 Error handling

Provide meaningful errors without exposing stack traces, secrets or database details to ordinary users.

Record diagnostic information safely.

Include a retry option where appropriate.

Do not silently discard failed operations.

## 21.2 Updates

For Windows updates:

- Preserve the application data directory.
- Use a documented update process.
- Verify compatibility with database migrations.
- Create a verified pre-update backup.
- Avoid destructive automatic migrations.
- Provide a recovery procedure.
- Test upgrades with existing data.

Do not store the only operational database in the application installation folder.

---

# PART V — SETTINGS

## 22. Complete settings structure

Organize Settings into clear sections:

1. Cafe Profile.
2. Company & Developer Information.
3. Branding.
4. Opening Hours.
5. Business Timezone.
6. Currency.
7. Financial Year.
8. Tax Configuration.
9. Order Types.
10. Delivery Zones and Fees.
11. Pickup Rules.
12. Kitchen Stations.
13. Printers.
14. Receipt Templates.
15. Discounts.
16. Approval Thresholds.
17. Inventory.
18. Notifications.
19. Users and Permissions.
20. Appearance and Themes.
21. Backup and Restore.
22. Security.
23. Integrations.
24. Data Export and Migration.
25. Application Version and Licence Information.

Only display configuration fields relevant to the selected deployment.

Do not hardcode permanent tax, currency, opening-hour or delivery rules.

Use PKR as an initial currency only if confirmed as appropriate for the business.

Verify applicable tax rules before applying them to actual transactions.

---

# PART W — TESTING AND QUALITY ASSURANCE

## 23. Automated testing

Build a meaningful test suite.

### POS

Test:

- Order creation.
- Item modification.
- Variants and add-ons.
- Price validation.
- Discounts.
- Tax calculation.
- Duplicate submission.
- Payment status.
- Cancellation.
- Refunds.
- Historical snapshots.
- Order transitions.

### Kitchen

Test:

- Station routing.
- Task completion.
- Order-ready conditions.
- Exceptions.
- Refresh and restart recovery.

### Parcel and delivery

Test:

- Collection.
- Rider assignment.
- Reassignment.
- Delivery completion.
- Failed delivery.
- Return to cafe.
- Cash reconciliation.

### Product and images

Test:

- Product creation and editing.
- Image upload.
- Image replacement.
- Cropping.
- Preview.
- Invalid-file rejection.
- Permissions.
- Image persistence after restart.
- Image persistence after updates.
- Restoration from backup.
- Historical transaction integrity.

### Inventory and financial records

Test:

- Stock movements.
- Recipe consumption.
- Duplicate deduction prevention.
- Purchases.
- Supplier payments.
- Expense approvals.
- Cash reconciliation.
- Refund accounting.
- Reporting boundaries.
- Missing cost data.
- Double-counting prevention.

### Backup and restore

Test:

1. Create a complete backup.
2. Verify the manifest and integrity hashes.
3. Restore to a clean test environment.
4. Compare record counts and financial totals.
5. Compare important image hashes.
6. Reject corrupted archives.
7. Reject unsupported versions safely.
8. Handle wrong encryption credentials.
9. Handle interrupted backup jobs.
10. Simulate failed restoration.
11. Confirm original data remains recoverable.
12. Test scheduled backups.
13. Test retention.
14. Test permissions.
15. Test update and reinstall persistence.

### Authorization and security

Test:

- Unauthorized API access.
- Privilege escalation.
- Restricted financial reports.
- Unauthorized exports.
- Unsafe uploads.
- Session expiry.
- Protected backup actions.
- Protected branding settings.

### Final technical checks

Run:

- Dependency checks.
- Lint.
- TypeScript validation.
- Automated tests.
- Production build.
- Relevant end-to-end tests.
- Desktop packaging tests.
- Database migration tests.
- Accessibility checks.
- Dependency and security audits.

Fix the failures that can be resolved in the available environment.

Do not claim hardware or external integration tests passed when the hardware or credentials were unavailable.

---

# PART X — IMPLEMENTATION PLAN

## 24. Phase 1: Audit and foundation

- Inspect the repository.
- Identify risks and existing functionality.
- Establish the architecture.
- Configure database and migrations.
- Implement authentication and permissions.
- Establish the design system.
- Implement company branding.
- Create automated test infrastructure.

## Phase 2: Menu and POS

- Categories.
- Products.
- Product images.
- Menu import.
- Variants.
- Add-ons.
- Cart.
- Counter orders.
- Parcel orders.
- Payment states.
- Order history.

## Phase 3: Kitchen and printing

- Kitchen display.
- Preparation stations.
- Ticket workflows.
- Printer configuration.
- Receipts.
- Kitchen tickets.
- Print queue and error handling.

## Phase 4: Customers and delivery

- Customer PWA.
- Checkout.
- Delivery zones.
- Customer history.
- Rider assignment.
- Delivery workflows.

## Phase 5: Owner dashboard

- Mobile interface.
- Live updates where supported.
- Operational summaries.
- Product availability.
- Alerts.
- Approvals.

## Phase 6: Inventory and finance

- Ingredients.
- Recipes.
- Stock movements.
- Suppliers.
- Purchasing.
- Expenses.
- Cash shifts.
- Refunds.
- Financial reports.

## Phase 7: Backup and recovery

- Manual backups.
- Scheduled backups.
- Verification.
- Encryption.
- Restore workflow.
- History.
- Retention.
- Recovery testing.
- Documentation.

## Phase 8: Production readiness

- Full regression suite.
- Security checks.
- Performance testing.
- Responsive review.
- Windows packaging.
- Update testing.
- Backup/restore acceptance.
- Documentation.

Implement each phase in the real project. Maintain a clear checklist of completed, partially completed, blocked and untested features.

---

# PART Y — FINAL DELIVERABLES

## 25. Required delivery package

Provide:

1. Complete source code.
2. Customer ordering PWA.
3. POS and management interface.
4. Windows installer or distributable.
5. Kitchen display.
6. Receipt and kitchen-ticket printing integration.
7. Product management and image editor.
8. Menu import workflow.
9. Inventory and purchasing.
10. Expense management.
11. Cash management.
12. Payments and refund workflows.
13. Financial reports.
14. Rider and delivery management.
15. Android-compatible owner dashboard.
16. Authentication and granular permissions.
17. Database schema and migrations.
18. Backup and restore system.
19. Company & Developer Information.
20. Automated tests.
21. Environment-variable example with no real secrets.
22. Installation instructions.
23. Windows packaging instructions.
24. Printer configuration guide.
25. Backup and disaster-recovery guide.
26. Owner and staff user guide.
27. Optional cloud deployment guide.
28. Dependency and licence inventory.
29. Known limitations.
30. Future improvement plan.

Do not include fake production credentials or invent deployment results.

---

# PART Z — DEFINITION OF DONE

## 26. Completion requirements

Do not declare Hanan Cafe complete until the applicable checks below have been verified.

### Application

- The application starts successfully.
- The real project builds.
- Core screens work.
- Data persists after restart.
- Errors are handled safely.
- Desktop packaging works where supported.

### Business workflows

- Products can be created and edited.
- Product images can be uploaded, changed and restored.
- Orders can be created and retrieved.
- Prices are validated.
- Historical financial values remain unchanged after product edits.
- Parcel and delivery transitions work.
- Kitchen status changes persist.
- Inventory movements are traceable.
- Expenses and cash shifts reconcile according to documented rules.
- Reports use consistent financial definitions.

### Security

- Permissions are enforced outside the visual interface.
- Unauthorized financial access is rejected.
- Sensitive credentials are not exposed in frontend code.
- Privileged operations are audited.
- Uploads and external inputs are validated.

### Backup and restoration

- Backups contain the configured essential data and media.
- Integrity checks work.
- Restore is tested in a clean environment.
- Financial totals and image integrity are compared.
- Failed restoration does not silently destroy recoverable data.
- Update and reinstall procedures preserve operational data.
- The owner has clear recovery instructions.

### Branding and design

- The interface follows the established Hanan Cafe theme.
- Company name is Ztech.
- Developer name is KASHIIF BASHIRR RAJPUT.
- Contact number is +92 300 1814159.
- Copyright and company details appear in the intended locations.
- The layout works on the target devices.

### Final report

Provide a truthful report containing:

- Implemented features.
- Tested features.
- Actual test results.
- Build and packaging status.
- Database status.
- Backup and restore test results.
- Printer compatibility status.
- External integrations still requiring setup.
- Known limitations.
- Potential recurring costs.
- Instructions for starting, testing, building and deploying.

Never mark an untested integration as verified.

---

# FINAL DIRECTIVE

Build Hanan Cafe as a dependable, modern restaurant operating system—not a static dashboard.

Prioritize real functionality, accurate financial calculations, secure permissions, reliable local persistence, verified backup and restoration, practical printer integration, mobile owner access, customer ordering, a premium interface and minimal recurring costs.

Preserve existing working functionality. Use the real menu when supplied. Keep paid services optional wherever practical. Make every essential control functional. Test actual workflows, correct defects, and document any limitations that cannot be resolved in the available environment.

**Start by auditing the current repository, then implement the project in phases. Continue beyond planning and visual design until the available implementation and testing work is complete.**

# PART AA — COMPACT THERMAL RECEIPT SYSTEM (ADDED REQUIREMENTS)

Provide configurable, original Hanan Cafe thermal receipt layouts for 58 mm and 80 mm devices; do not copy proprietary third-party receipt artwork. Build six templates: compact, standard, tax invoice, parcel, delivery, and kitchen ticket. Keep template rendering separate from authoritative transaction calculations.

Each customer receipt prints configured cafe branding and contact details; prominent order reference; order type, time, permitted cashier/customer/delivery details; dynamically wrapped item descriptions, modifiers, quantities, unit prices and line totals; applicable subtotal, discount, tax, delivery, other charges, grand total, paid amount, change or balance, verified payment method and status; and optional return policy, support contact, reference/QR, configurable footer and Powered by Ztech. Omit missing and irrelevant fields. Kitchen tickets show preparation details but omit payment information and unnecessary customer personal data.

Implement paper-aware layouts, editable admin settings and defaults per printer/order type, safe print preview, configurable margins/feeds, printer selection, print/reprint controls, queue/history/retry/error states and warning/permission enforcement for duplicates. Cash-drawer pulses require compatible hardware and authorization. Native or local printing agent / ESC/POS integration must be chosen based on actual hardware. Store immutable transaction references for print jobs. Reprinting must not create sales/payments. Record states such as queued, submitted, confirmed (only if supported), failed and unknown. Never claim physical printing merely from print submission.

Acceptance requires width checks, wrapping, alignment, last-line preservation, correct display of calculated totals, non-Latin font handling where required, persistent settings through updates, permission and audit testing, safe retries and real-hardware tests on 58 mm and 80 mm printers when available. Never invent actual cafe details or transactions.
