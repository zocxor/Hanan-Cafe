# Changelog 0.6.0 — liquid glass + floating UI on every colour scheme

## What changed

- `float-ui.css` was scoped to the old Raspberry (`navy`) scheme, which was
  removed in v0.5.7 — so the liquid-glass panels, floating buttons/cards,
  entrance motion, glass dialogs and focus rings never rendered on the two
  remaining schemes. It is now theme-agnostic.
- Every tint is derived from the active scheme's own variables (`--accent`,
  `--surface`, `--canvas`) via `color-mix`, so Orange/Porcelain gets warm
  glass and White/Sky Blue gets cool glass — each scheme keeps its identity.
- Cinematic ambient canvas: soft accent glows layered over each theme's own
  background colour (no more hardcoded raspberry).
- Respects `prefers-reduced-motion` as before.

## Upgrade notes

- Replace the `static/` folder (`app.py` unchanged since v0.5.9); keep your
  data directory.
- Static asset versions bumped to `?v=060`; hard-refresh once (Cmd+Shift+R).
