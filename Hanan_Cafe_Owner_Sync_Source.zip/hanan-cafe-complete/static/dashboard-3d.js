/* Hanan Cafe · Dashboard 3D tilt (v0.5.0).
   Pointer-tracked 3D tilt + travelling glare for .dash-metric cards.
   Runs after the Motion entrance animation; respects reduced motion. */
(function(){
  'use strict';
  if (window.matchMedia('(prefers-reduced-motion:reduce)').matches) return;
  var MAX = 9; // max tilt degrees

  function arm(card){
    if (card.__tiltArmed) return;
    card.__tiltArmed = true;
    // Let the entrance animation finish, then hand transform control to the tilt.
    setTimeout(function(){ card.style.transform = ''; }, 750);
    var raf = 0, tRX = 0, tRY = 0, tTY = 0, cRX = 0, cRY = 0, cTY = 0;
    function frame(){
      raf = 0;
      cRX += (tRX - cRX) * 0.18; cRY += (tRY - cRY) * 0.18; cTY += (tTY - cTY) * 0.22;
      card.style.transform = 'perspective(950px) rotateX(' + cRX.toFixed(2) + 'deg) rotateY(' + cRY.toFixed(2) + 'deg) translateY(' + cTY.toFixed(2) + 'px)';
      if (Math.abs(tRX - cRX) > 0.02 || Math.abs(tRY - cRY) > 0.02 || Math.abs(tTY - cTY) > 0.02) {
        raf = requestAnimationFrame(frame);
      }
    }
    function kick(){ if (!raf) raf = requestAnimationFrame(frame); }
    card.style.transition = 'box-shadow .25s ease,border-color .25s ease';
    card.addEventListener('pointerenter', function(){ tTY = -6; kick(); });
    card.addEventListener('pointermove', function(e){
      var r = card.getBoundingClientRect();
      var px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
      tRY = (px - 0.5) * MAX;
      tRX = (0.5 - py) * MAX;
      card.style.setProperty('--gx', (px * 100).toFixed(1) + '%');
      card.style.setProperty('--gy', (py * 100).toFixed(1) + '%');
      kick();
    });
    card.addEventListener('pointerleave', function(){
      tRX = 0; tRY = 0; tTY = 0;
      card.style.setProperty('--gx', '50%');
      card.style.setProperty('--gy', '0%');
      kick();
    });
  }

  function sweep(){
    document.querySelectorAll('.dashboard-v045 .dash-metric').forEach(arm);
  }
  var page = document.getElementById('page') || document.body;
  if (window.MutationObserver) new MutationObserver(sweep).observe(page, { childList: true, subtree: true });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', sweep);
  else sweep();
})();
