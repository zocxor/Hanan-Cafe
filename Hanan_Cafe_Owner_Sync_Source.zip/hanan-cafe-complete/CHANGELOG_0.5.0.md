# Changelog 0.5.0 — Cyber Teal / Aqua Foam + 3D dashboard + import repair

## Colour scheme

- The "Navy / AI Green" scheme is now **Cyber Teal / Aqua Foam**, sampled from the
  approved palette: deep Cyber Teal `#05363A` surfaces with Aqua Foam `#97FFE1`
  accents, navigation and highlights.
- Orange / Porcelain and White / Sky Blue schemes are unchanged.
- The scheme picker label now reads "Cyber Teal / Aqua Foam".

## Dashboard 3D (liquid glass + claymorphism)

- New `static/dashboard-3d.css` skin, scoped to the dashboard only:
  - Liquid-glass metric cards — backdrop blur, translucent gradients, inner top
    highlight, glowing accent bar, travelling pointer glare.
  - Pointer-tracked 3D tilt on metric cards (`static/dashboard-3d.js`), with
    lerped motion and `prefers-reduced-motion` support.
  - Claymorphism panels — thick soft dual shadows with inner bevels (with a
    dedicated dark-theme tuning block).
  - Liquid activity bars — glossy gradient fills with glow and animated growth.
  - Floating glass status donut, tactile latest-order rows, 3D shortcut orbs,
    prominent glass hero band with gradient headline, ambient drifting light.
- No dashboard data logic changed; verified by `tests/test_dashboard.py`.

## Import backup repair

- macOS/Windows re-zipped archives (`__MACOSX/`, `.DS_Store`, `Thumbs.db`) no
  longer rejected; a single top-level folder wrapper is accepted.
- Missing `manifest.json` now returns a clear message instead of a raw KeyError.
- File picker resets after each verification, so re-selecting the same file
  retries correctly.
- Status-specific error hints (413 too large, 5xx server error).
- Restore cleanup can no longer mask a successful restore with a 500.
- Superseded preview stages are deleted when a new preview starts.
- Removed the dead divergent import handler in `upgrade.js`.
- New regression coverage: `tests/test_backup_import_050.py` (5 checks).
  Existing `tests/test_import_repair.py` still passes.

## Upgrade notes

- Replace the `static/` folder and `enhancements.py`, keep your data directory.
- Static asset versions bumped to `?v=050`; hard-refresh once after updating.
