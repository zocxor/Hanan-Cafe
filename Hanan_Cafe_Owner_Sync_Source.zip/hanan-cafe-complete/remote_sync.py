"""Optional outbound-only sync. Credentials stay on the cafe computer."""
import os, json, sqlite3, threading, urllib.request, time
from datetime import datetime, timezone
TABLES = ('settings','categories','products','product_variants','customers','orders','order_items','order_events','inventory_movements','expenses','audit','order_cancellations','kitchen_tasks')
def snapshot(db):
    c=sqlite3.connect(db, timeout=20);c.row_factory=sqlite3.Row
    try:
        c.execute('BEGIN')
        tables={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        result={t:[dict(r) for r in c.execute('SELECT * FROM '+t)] for t in TABLES if t in tables}
        # Never send user passwords, sessions, cloud settings or printer jobs.
        result['settings']=[r for r in result.get('settings',[]) if r['key'] in ('cafe_name','currency','address','phone')]
        return {'captured_at':datetime.now(timezone.utc).isoformat(), 'records':result}
    finally:c.close()
def start(db):
    url=os.environ.get('HANAN_SYNC_URL','').rstrip('/')
    token=os.environ.get('HANAN_SYNC_WRITE_TOKEN','')
    if not url or not token:return
    if not url.startswith('https://'):
        print('Owner sync disabled: HANAN_SYNC_URL must use HTTPS',flush=True)
        return
    def loop():
        while True:
            try:
                body=json.dumps(snapshot(db)).encode()
                req=urllib.request.Request(url+'/api/snapshot',data=body,headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'},method='PUT')
                # Reject redirects so credentials cannot be forwarded to another host.
                class NoRedirect(urllib.request.HTTPRedirectHandler):
                    def redirect_request(self,*args,**kwargs):return None
                with urllib.request.build_opener(NoRedirect()).open(req,timeout=30) as response:
                    if response.status!=200:raise RuntimeError('Sync rejected')
                print('Owner sync successful',flush=True)
            except Exception as e:print('Owner sync pending: '+type(e).__name__,flush=True)
            time.sleep(30)
    threading.Thread(target=loop,daemon=True,name='owner-sync').start()
