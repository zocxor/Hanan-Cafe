# Changelog 0.6.19 — concise POS header

## POS: Build an order

- Search bar and category dropdown now sit side by side in one row.
- Header tightened (helper line removed) so the menu grid starts higher.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=0619`; hard-refresh once (Cmd+Shift+R).
