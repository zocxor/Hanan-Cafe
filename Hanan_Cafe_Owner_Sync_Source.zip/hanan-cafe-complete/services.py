"""Additive customer directory, audited cancellation and atomic print batches."""
import re,uuid
from fastapi import Request,HTTPException
_g=None

def phone_key(phone):return re.sub(r'\D','',str(phone))
def save_order_contact(c,p,stamp=None):
    name=str(p.get('customer','')).strip()[:120];phone=str(p.get('phone','')).strip()[:40];key=phone_key(phone)
    if not name or not 7<=len(key)<=16:return
    stamp=stamp or _g['now']();address=str(p.get('address','')).strip()[:500]
    current=c.execute('SELECT id FROM customers WHERE phone_key=?',(key,)).fetchone()
    if current:c.execute("UPDATE customers SET name=?,phone=?,address=CASE WHEN ?!='' THEN ? ELSE address END,updated_at=?,last_order_at=? WHERE id=?",(name,phone,address,address,stamp,stamp,current['id']))
    else:c.execute('INSERT INTO customers(id,name,phone,phone_key,address,created_at,updated_at,last_order_at) VALUES(?,?,?,?,?,?,?,?)',(uuid.uuid4().hex,name,phone,key,address,stamp,stamp,stamp))

def record_cancellation(c,oid,u,reason,restock=False):
    o=c.execute('SELECT * FROM orders WHERE id=?',(oid,)).fetchone()
    if not o:raise HTTPException(404,'Order not found')
    existing=c.execute('SELECT * FROM order_cancellations WHERE order_id=?',(oid,)).fetchone()
    if existing:return dict(existing)
    if o['status'] in ('COMPLETED','DELIVERED'):raise HTTPException(409,'Completed orders require a separate financial adjustment')
    if restock and u['role'] not in ('owner','manager'):raise HTTPException(403,'Only a manager can return unused stock')
    if restock:
        for item in c.execute('SELECT product_id,SUM(qty) qty FROM order_items WHERE order_id=? GROUP BY product_id',(oid,)).fetchall():
            prod=c.execute('SELECT stock_tracking FROM products WHERE id=?',(item['product_id'],)).fetchone()
            if prod and prod['stock_tracking']:
                c.execute('UPDATE products SET stock_qty=stock_qty+? WHERE id=?',(item['qty'],item['product_id']))
                c.execute('INSERT INTO inventory_movements VALUES(?,?,?,?,?,?,?)',(uuid.uuid4().hex,item['product_id'],item['qty'],'Cancelled order: unused stock returned',oid,u['id'],_g['now']()))
    review=min(o['amount_paid'],o['grand_total'])
    c.execute('INSERT INTO order_cancellations VALUES(?,?,?,?,?,?)',(oid,reason,u['id'],_g['now'](),int(restock),review))
    _g['audit'](c,u['id'],'order_cancelled',{'order_id':oid,'reason':reason,'stock_returned':bool(restock),'refund_review_paisa':review,'refund_processed':False})
    return {'refund_review_paisa':review,'refund_processed':False}

def install_services(g):
    global _g
    _g=g;app=g['app'];auth=g['auth'];payload=g['payload'];tx=g['tx'];rows=g['rows'];now=g['now'];audit=g['audit']

    with tx() as c:
        if not c.execute("SELECT 1 FROM settings WHERE key='customers_import_043'").fetchone():
            before=c.execute('SELECT COUNT(*) FROM customers').fetchone()[0]
            for previous in c.execute("SELECT customer,phone,address,created_at FROM orders WHERE customer!='' AND phone!='' ORDER BY created_at").fetchall():save_order_contact(c,dict(previous),previous['created_at'])
            after=c.execute('SELECT COUNT(*) FROM customers').fetchone()[0]
            c.execute("INSERT INTO settings VALUES('customers_import_043','done')")
            if after>before:audit(c,None,'customers_imported_from_orders',{'count':after-before,'marketing_opt_in':False})

    @app.get('/api/customers')
    def customers(request:Request,q:str=''):
        auth(request,['owner','manager','cashier'])
        query='%'+q[:100]+'%'
        return rows('SELECT * FROM customers WHERE name LIKE ? OR phone LIKE ? OR email LIKE ? ORDER BY updated_at DESC LIMIT 500',(query,query,query))

    @app.post('/api/customers')
    async def create_customer(request:Request):
        u=auth(request,['owner','manager','cashier']);p=await payload(request);name=str(p.get('name','')).strip()[:120];phone=str(p.get('phone','')).strip()[:40];key=phone_key(phone)
        if not name or not 7<=len(key)<=16:raise HTTPException(400,'Enter a name and valid phone number')
        if p.get('marketing_opt_in',0) not in (0,1):raise HTTPException(400,'Invalid contact preference')
        with tx() as c:
            if c.execute('SELECT id FROM customers WHERE phone_key=?',(key,)).fetchone():raise HTTPException(409,'A customer with this phone number already exists')
            cid=uuid.uuid4().hex;c.execute('INSERT INTO customers VALUES(?,?,?,?,?,?,?,?,?,?,NULL)',(cid,name,phone,key,str(p.get('email','')).strip()[:200],str(p.get('address',''))[:500],str(p.get('notes',''))[:1000],int(p.get('marketing_opt_in',0)),now(),now()))
            audit(c,u['id'],'customer_created',{'id':cid,'marketing_opt_in':bool(p.get('marketing_opt_in'))})
        return {'id':cid}

    @app.delete('/api/customers/{cid}')
    def delete_customer(cid:str,request:Request):
        u=auth(request,['owner','manager'])
        with tx() as c:
            result=c.execute('DELETE FROM customers WHERE id=?',(cid,))
            if result.rowcount!=1:raise HTTPException(404,'Customer contact not found')
            audit(c,u['id'],'customer_deleted',{'id':cid,'historical_orders_preserved':True})
        return {'deleted':True}

    @app.patch('/api/customers/{cid}')
    async def edit_customer(cid:str,request:Request):
        u=auth(request,['owner','manager','cashier']);p=await payload(request)
        if not isinstance(p,dict) or not p or not set(p)<={'name','phone','email','address','notes','marketing_opt_in'}:raise HTTPException(400,'Invalid contact update')
        with tx() as c:
            old=c.execute('SELECT * FROM customers WHERE id=?',(cid,)).fetchone()
            if not old:raise HTTPException(404,'Customer not found')
            data=dict(old);data.update(p);name=str(data['name']).strip()[:120];phone=str(data['phone']).strip()[:40];key=phone_key(phone)
            if not name or not 7<=len(key)<=16 or data['marketing_opt_in'] not in (0,1):raise HTTPException(400,'Valid name, phone and contact preference required')
            if c.execute('SELECT id FROM customers WHERE phone_key=? AND id!=?',(key,cid)).fetchone():raise HTTPException(409,'Phone number belongs to another customer')
            c.execute('UPDATE customers SET name=?,phone=?,phone_key=?,email=?,address=?,notes=?,marketing_opt_in=?,updated_at=? WHERE id=?',(name,phone,key,str(data['email'])[:200],str(data['address'])[:500],str(data['notes'])[:1000],int(data['marketing_opt_in']),now(),cid))
            audit(c,u['id'],'customer_updated',{'id':cid,'fields':list(p)})
        return {'ok':True}

    @app.post('/api/orders/{oid}/cancel')
    async def cancel_order(oid:str,request:Request):
        u=auth(request,['owner','manager','cashier']);p=await payload(request);reason=str(p.get('reason','')).strip()[:500]
        if len(reason)<3:raise HTTPException(400,'Enter a short cancellation reason')
        with tx() as c:
            o=c.execute('SELECT status FROM orders WHERE id=?',(oid,)).fetchone()
            if not o:raise HTTPException(404)
            if o['status']=='CANCELLED':return {'ok':True,'duplicate':True,'refund_processed':False}
            result=record_cancellation(c,oid,u,reason,p.get('return_stock') is True)
            c.execute("UPDATE orders SET status='CANCELLED' WHERE id=?",(oid,));c.execute('INSERT INTO order_events VALUES(?,?,?,?,?)',(uuid.uuid4().hex,oid,'CANCELLED',u['id'],now()))
        return {'ok':True,**result}

    @app.post('/api/print-jobs/batch')
    async def batch_print(request:Request):
        u=auth(request,['owner','manager','cashier']);p=await payload(request);mode=p.get('mode');width=p.get('width',80)
        if mode not in ('customer','kitchen','both') or width not in (58,80):raise HTTPException(400,'Invalid print selection')
        with tx() as c:
            oid=p.get('order_id');o=c.execute('SELECT order_type FROM orders WHERE id=?',(oid,)).fetchone()
            if not o:raise HTTPException(404,'Order not found')
            previous=c.execute('SELECT COUNT(*) FROM print_jobs WHERE order_id=?',(oid,)).fetchone()[0]
            if previous and (u['role'] not in ('owner','manager') or p.get('reprint_confirmed') is not True):raise HTTPException(409,'Manager confirmation required for reprinting')
            customer_template=p.get('customer_template') or {'COUNTER':'standard','PARCEL':'parcel','DELIVERY':'delivery'}[o['order_type']]
            if customer_template not in ('compact','standard','tax','parcel','delivery'):raise HTTPException(400,'Invalid customer template')
            templates=([customer_template] if mode in ('customer','both') else [])+(['kitchen'] if mode in ('kitchen','both') else [])
            jobs=[]
            for template in templates:
                jid=uuid.uuid4().hex;c.execute('INSERT INTO print_jobs VALUES(?,?,?,?,?,?,?,?,?)',(jid,oid,template,width,'QUEUED',1,u['id'],now(),None))
                jobs.append({'id':jid,'template':template})
            audit(c,u['id'],'print_batch_queued',{'order_id':oid,'mode':mode,'width':width,'jobs':jobs,'reprint':bool(previous)})
        return {'jobs':jobs,'mode':mode,'width':width}
