# Update Hanan Cafe on macOS

1. Stop the server with Ctrl+C.
2. Back up your database and project folder before installing.
3. Extract this ZIP into Downloads.
4. Copy app.py, static/app.js, and static/style.css into `~/Downloads/Hanan_Cafe/hanan-cafe-complete/`.
5. Start using the existing `.venv315` environment. Do not run setup.py and do not replace the data folder.

The backend applies additive SQLite migrations at startup. Keep an independent backup before using any new feature.
