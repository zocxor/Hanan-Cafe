# Changelog 0.5.7 — brand fit + Raspberry scheme removed

## Brand

- Sidebar brand tightened (30px / 5px spacing) so "HANAN" always fits with
  room to spare; compact sizing restored for the mobile top bar.

## Removed

- The Raspberry / Pale Sky colour scheme has been removed from the scheme
  picker, as requested. Only Orange / Porcelain and White / Sky Blue remain.
  Anyone still set to the old "navy" value falls back to Orange / Porcelain
  automatically; backend validation updated accordingly. Nothing else changed.

## Upgrade notes

- Replace the `static/` folder and `app.py`; keep your data directory.
- Static asset versions bumped to `?v=057`; hard-refresh once (Cmd+Shift+R).
