# Hanan Cafe — v0.4.2

Local restaurant POS, Menu Studio, kitchen display, orders, receipts, reports, expenses, finance, staff profiles and owner-controlled recovery.

For the existing Mac folder used in this conversation, follow **UPDATE_MAC_v0.4.2.md**. This version includes the premium theme, 24 transparent food cutouts, four pizza sizes, dish duplication and simplified Kitchen/Orders.

## New installation (macOS)

Use Python 3.12 or 3.13 with OpenSSL/scrypt support. Unzip this download, open Terminal in `hanan-cafe-complete`, then run:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python setup.py
python -m uvicorn app:app --host 127.0.0.1 --port 8765
```

Choose your own owner username and password; no default login is shipped. Open http://127.0.0.1:8765 and leave Terminal running. On subsequent starts activate `.venv` and run the final command only. On Windows use `py -3.12` instead of `python3.12` and `.venv\Scripts\activate`.

## Upgrade an existing installation — preserve your data

1. Generate a backup in your current app and retain an additional copy of its entire data folder. Stop the server with Ctrl+C.
2. Copy the updated code, `static` folder, `starter` folder, `enhancements.py` and requirements into the existing project folder. Do not delete or replace the existing `data` folder or database. Do not copy test databases.
3. Activate the existing compatible virtual environment and run `python -m pip install -r requirements.txt`.
4. Start with the same `HANAN_DATA_DIR` setting as before. Existing `data/hanan.sqlite3` is detected; otherwise new installations use `~/.hanan-cafe`. The database and managed images stay together. If running from a new project folder, set `HANAN_DATA_DIR` to the ABSOLUTE path of the old data directory before starting.
5. Sign in using your existing account. Do not run setup.py for an existing database. Hard-refresh the browser to load updated scripts.
6. Existing catalogues are never automatically populated. As owner, go to **Backup → Add missing starter dishes** to explicitly add the starter menu. New installations receive it automatically.

```bash
# Example only: use your actual existing data directory
export HANAN_DATA_DIR="$HOME/Downloads/Hanan_Cafe/hanan-cafe-complete/data"
python -m uvicorn app:app --host 127.0.0.1 --port 8765
```

## Menu and images

24 starter dishes in 7 categories; editable demonstration prices in PKR. Every pizza has Small, Medium, Large and XL prices; set them in Menu → Edit dish → Sizes & prices. Each size initially retains the existing pizza price. Duplicate a dish under a new name using Menu → Duplicate. Seed records have stable identifiers and a starter marker. Existing names, archived starters and edits are preserved on repeat seeding. No sales, stock quantities, costs, recipes, taxes or suppliers are invented. Stock tracking is off for starter dishes.

Menu Studio includes search, category/status filters, grid/list views, pagination, dish editing and category management. Image Studio supports large previews, JPEG/PNG/WebP uploads up to 3 MB, crop/zoom/reposition, confirmed removal and retained-image restoration. Previous saved images are retained in history; cropped output is saved as the current image. The uncropped source selected in the browser is not separately archived. Images are copied into the persistent data directory, served locally, and included in backups. Source records are in `starter/IMAGE_CREDITS.md`.

## Backup, restore and reset

**Backup → Generate & download ZIP** exports the database and managed images. **Import backup** validates ZIP paths, checksums, SQLite integrity and referenced media, then previews record counts. Restore is full replacement, not a merge; it requires the current owner password and the exact confirmation phrase. After restore, use the owner credentials contained in the backup.

**Factory reset** is owner-only and requires the password plus `RESET HANAN CAFE`. It removes operational records, catalogue, staff accounts and settings while retaining the current owner account. Sessions are revoked. A recovery ZIP is saved before reset or restore and can be downloaded from Backup. Download recovery archives to another device for protection against computer failure. Starter dishes can be explicitly added again after reset.

## Tests and scope

```bash
python -m pip install httpx
python tests/test_smoke.py
python tests/test_upgrade.py
python tests/test_sizes_duplicate.py
```

Tests use temporary isolated databases. See `docs/UPGRADE_REPORT.md` for results and limitations. This is a local recordkeeping application: bank/wallet selections do not initiate transfers; cloud synchronization and remote customer ordering are not implemented. Physical printer output requires your hardware verification. Run on trusted localhost; public internet hosting requires separate deployment hardening.
