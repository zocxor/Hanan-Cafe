# Changelog 0.5.5 — scheme division & readability (Raspberry / Pale Sky)

## Fixed colour division (navy scheme only)

- Sidebar is now a near-black plum layer, clearly separated from the canvas;
  the active nav item is a glowing Raspberry gradient with white text.
- Canvas deepened to a cinematic plum-maroon gradient with layered ambient
  glows (body), giving clear separation: sidebar < canvas < pale cards.
- Hero was unreadable (dark text on dark): it is now a solid Pale Sky panel
  with a vivid raspberry gradient headline, dark date and a white eyebrow
  pill — all high contrast.
- Bare-canvas text (top title, page intros, pagination) confirmed light and
  legible; card/table/dialog text stays dark raspberry on pale.

## Readability pass

- Day labels under activity bars 10px -> 11px, per-day sales 9px -> 10px,
  metric detail lines 10px -> 11px.

## Upgrade notes

- Replace the `static/` folder; keep your data directory.
- Static asset versions bumped to `?v=055`; hard-refresh once after updating.
