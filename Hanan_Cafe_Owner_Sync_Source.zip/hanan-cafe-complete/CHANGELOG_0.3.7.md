# Hanan Cafe v0.3.7 — Heritage UI, Staff Access & Service Charges

- Compact, scroll-limited category management card for long menus.
- Updated Hanan Cafe heritage branding and liquid-glass navigation treatment.
- Added configurable service charge at checkout; it is stored per order and included in the grand total and customer receipt.
- Added owner-managed staff accounts (up to 15 non-owner accounts), roles, per-section access selection, account enable/disable, password changes, and staff profile photos.
- Added owner profile username/password update and profile photo.
- Reports now include reporting-period selectors and explicitly label metrics as today, yesterday, a selected range, or all time.
- Added safe additive SQLite migrations for user profile/permissions and service-charge storage; existing order data is preserved.

This remains a local recordkeeping application. It does not execute bank transfers, verify non-cash payments, or provide statutory accounting/legal records. Cloud synchronization is not implemented in this release.
