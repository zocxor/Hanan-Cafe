# Changelog 0.6.20 — compact headers + receipt auto-fit

## Compact hero bars (Orders, Menu, Kitchen)

- The tall "ORDER BOOK / Orders", "Menu Studio" and "Kitchen" header bars
  are now slim: tighter padding, smaller titles, less space before content.

## Reports: concise stat cards

- The 4 report cards (Orders, Turnover, Discounts, Expenses) are compact
  and sit in one row on desktop (2x2 on small screens).

## Receipts: preview auto-fits the screen

- The receipt preview scales down to fit the display — no page scrolling
  needed to see the whole receipt. Extremely long receipts keep a
  contained scroll inside the preview panel only.
- Print queue & history below is untouched (scrolls as before).

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=0620`; hard-refresh once (Cmd+Shift+R).
