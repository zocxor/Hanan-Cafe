# Hanan Cafe 0.4.5 — Dashboard and compact workflows

- Dashboard redesign with four daily status cards, seven-day order activity, status ring, recent product summaries, ready-for-handoff count and permission-aware quick actions. All daily figures use Pakistan time. Full-database aggregation avoids the 300-row recent-order limit. Order value excludes cancelled orders and is clearly distinguished from cash collected.
- Green completed/delivered and red cancelled statuses on Dashboard and Orders. Cancellation records remain in history.
- Compact Menu Studio grid with named, accessible edit/image/duplicate/delete icons. Duplicate immediately creates a copy with a unique name chosen inside the database transaction, including against deleted products. Image, category and pizza sizes copy; stock remains untracked. Use Edit to make further changes.
- Desktop POS: independent product scrolling beside the stable current-order panel, preserving product search and scroll position as items are added. Added lines have a tinted background and accent border. Checkout fields have visible borders before focus. Compact short-screen layout displays delivery fields, notes and Confirm order without an inner checkout scrollbar. Long item lists retain their own scrollbar. Mobile uses natural page scrolling so nothing is clipped.
- Receipt print selection is in the control grid and action buttons align below it. The on-screen preview follows the selected customer/kitchen/both mode. The combined customer/kitchen printing introduced in 0.4.4 remains.
- One developer information panel, retaining developer/contact details without repeating copyright. Organisation: Zocxorian Technologies. Short name: ZTechx. Old ZTech/Ztech visible labels replaced.
- Existing local bundled Motion interactions and Lucide icons power the dashboard; no additional remote dependency or framework migration.
- Cache version incremented to 045 so the updated scripts and styles load on upgrade.
