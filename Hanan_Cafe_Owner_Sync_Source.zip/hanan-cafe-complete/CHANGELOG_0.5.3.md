# Changelog 0.5.3 — Raspberry / Pale Sky + floating UI

## Scheme change (navy scheme only; other schemes untouched)

- The navy slot is now **Raspberry / Pale Sky**, sampled from the approved
  palette: Raspberry `#B10257` with Pale Sky `#E0F3FA`.
- Deep raspberry-maroon canvas `#3D0A24`; Pale Sky cards, panels, tables,
  dialogs and top bar with dark raspberry text for maximum contrast.
- Dark raspberry sidebar; the active nav option is Pale Sky.
- Raspberry buttons with light text; white inputs; pale secondary buttons.
- Scheme picker label now reads "Raspberry / Pale Sky".

## Floating UI + liquid glass (all features, Raspberry scheme only)

- New `static/float-ui.css`: cinematic ambient canvas (layered raspberry/pale
  glows), layered translucent panels with backdrop blur and soft deep shadows,
  floating buttons (lift on hover, press on click), floating cards
  (product/dish/kitchen hover lift), gentle staggered entrance, cinematic
  dialog scale-in with blurred backdrop, glassy input focus rings, fluid table
  row hovers, sidebar glow. All motion respects `prefers-reduced-motion`.
- Dashboard keeps its dedicated 3D skin, retuned automatically via the new
  variables (raspberry orbs/bars, pale glow).

## Upgrade notes

- Replace the `static/` folder; keep your data directory.
- Static asset versions bumped to `?v=053`; hard-refresh once after updating.
