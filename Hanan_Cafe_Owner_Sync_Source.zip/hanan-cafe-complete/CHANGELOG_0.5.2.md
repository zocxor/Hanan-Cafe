# Changelog 0.5.2 — Aqua Foam cards on Cyber Teal

## Scheme change (navy scheme only; other schemes untouched)

- App/canvas background is now dark Cyber Teal `#042E2D`.
- All cards, panels, tables, dialogs, the top glass bar and hero are light
  Aqua Foam `#97FFE1` with dark Cyber Teal text for maximum contrast.
- Side navigation stays dark Cyber Teal with the active option in Aqua Foam.
- Buttons use dark Cyber Teal with light text; inputs stay white; secondary
  buttons are pale mint — all legible on both cards and the dark canvas.
- Bare-canvas text (top title, page intros, pagination) uses light text.
- 3D dashboard skin retuned: light clay shadows for the mint panels, aqua
  ambient glow, dark-teal activity bars and icon orbs on the mint cards.
- Static asset versions bumped to `?v=052`; hard-refresh once after updating.
