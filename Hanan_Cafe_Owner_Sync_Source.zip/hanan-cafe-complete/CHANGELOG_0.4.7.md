# 0.4.7 — Backup import repair

- Restore no longer fails on image filename collisions. Private staged image references are remapped to new names; existing live images and the automatic recovery archive remain intact.
- Restoring a backup from another installation no longer writes an audit foreign key to an owner ID absent from the restored database. The prior authorized username is recorded as metadata, with a null actor when necessary.
- Preview tolerates additive image/permission columns absent from older compatible schemas and ignores empty image references. Checksums, integrity, archive path restrictions and active-owner checks remain.
- Backup page has an explicit Verify selected backup button, persistent progress/error messages, retry support and clearer rejection of application update ZIPs.
- Generated-backup browser flow tested through download, invalid-file rejection, valid preview, password/phrase confirmation, sign-out and login. Dedicated backend test covers different owner IDs, conflicting images, retained recovery data and restored image bytes.
