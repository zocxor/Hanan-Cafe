# Changelog 0.6.8 — dashboard card design on product cards + 3D everywhere

## POS product cards

- Product cards now mirror the dashboard metric cards: glass background with
  backdrop blur, name + gradient icon badge on the top row, photo, big price,
  category caption, accent underline, hover lift and travelling glare.
- The icon badge shows a "+" normally and the in-cart quantity when the item
  is selected.

## 3D system on all pages

- The pointer-tracked 3D tilt + glare (previously dashboard-only) now also
  applies to POS product cards and Menu dish cards on every page.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=068`; hard-refresh once (Cmd+Shift+R).
