# Changelog 0.6.24 — instant dashboard

## Dashboard: no more loading flash

- The dashboard now renders instantly from already-loaded data instead of
  showing "Loading today's overview…" and fetching from the server. Same
  numbers, same layout — just immediate.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=0624`; hard-refresh once (Cmd+Shift+R).
