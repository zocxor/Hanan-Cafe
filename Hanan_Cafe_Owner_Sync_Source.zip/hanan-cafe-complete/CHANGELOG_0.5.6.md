# Changelog 0.5.6 — compact single-row metric cards

## Dashboard

- Metric cards are smaller and always stay in one row on desktop: tighter
  padding, smaller icon orbs, numbers at clamp(28px,2.2vw,38px) with tabular
  numerals so "Rs. 650.00" fits, `min-width:0` so columns never force a wrap.
- Breakpoints retuned: 5 columns -> 3 below 1150px -> 2 below 700px.
- `index.html` now sends a no-cache hint so the browser never holds a stale
  copy of the page (which previously caused the 5th card to wrap under an
  old 4-column stylesheet).

## Upgrade notes

- Replace the `static/` folder; keep your data directory.
- Static asset versions bumped to `?v=056`; hard-refresh once (Cmd+Shift+R).
