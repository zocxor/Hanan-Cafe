# Changelog 0.6.11 — cart delete button, concise expenses

## POS cart

- Each item in "Current order" now has a red × delete button at the right of
  the −/+ controls, so a line can be removed in one tap instead of tapping −
  repeatedly.

## Expenses page

- The Record expense form and the Recorded expenses summary no longer stretch
  across the whole page: the pair is capped at a comfortable width, the form
  card is tighter, and the big total figure is smaller.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=0611`; hard-refresh once (Cmd+Shift+R).
