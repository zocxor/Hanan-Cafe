# Changelog 0.5.1 — Cyber Teal / Aqua Foam direction flip

## Scheme change (navy scheme only; other schemes untouched)

- Dashboard/canvas background is now light Aqua Foam `#D2F0E3`.
- Side navigation bar is dark Cyber Teal (`#05363A → #032A2E` gradient) with
  light text; the active nav option is solid Aqua Foam `#97FFE1` with dark text.
- All cards, panels, tables, dialogs and the top glass bar are dark Cyber Teal
  with light readable text (scoped `--text`/`--subtext`/`--muted` flip, so every
  screen in the app follows the scheme automatically).
- Inputs and secondary buttons are light so they stay legible on both the
  light canvas and inside dark cards.
- Headings directly on the canvas (top bar title, page intros, pagination) use
  dark teal for contrast.
- Removed the v0.5.0 mint status-panel/metric overrides; those panels now match
  the dark card system.
- Static asset versions bumped to `?v=051`; hard-refresh once after updating.
