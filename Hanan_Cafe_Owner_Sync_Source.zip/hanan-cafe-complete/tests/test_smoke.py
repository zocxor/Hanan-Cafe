import os,tempfile,sys
from pathlib import Path
from fastapi.testclient import TestClient
os.environ['HANAN_DATA_DIR']=tempfile.mkdtemp(prefix='hanan-test-')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
app.create_owner('owner','SafeTestPassword123!')
client=TestClient(app.app)
def request(method,path,**kwargs):
    resp=client.request(method,path,**kwargs)
    assert resp.status_code<400,(method,path,resp.status_code,resp.text)
    return resp.json()
assert request('GET','/api/ready')['initialized']
assert client.get('/api/products').status_code==401
request('POST','/api/login',json={'username':'owner','password':'SafeTestPassword123!'})
cat=request('POST','/api/categories',json={'name':'Main course'})
assert cat['ok']
cid=request('GET','/api/categories')[0]['id']
pid=request('POST','/api/products',json={'name':'Smoke test item','category_id':cid,'price_paisa':25000,'stock_tracking':True,'stock_qty':6})['id']
order={'idempotency_key':'test-order-idempotency-0001','order_type':'COUNTER','payment_method':'CASH','amount_paid_paisa':50000,'items':[{'product_id':pid,'qty':2}], 'discount_paisa':0,'delivery_fee_paisa':0}
sale=request('POST','/api/orders',json=order)
assert sale['grand_total']==50000,sale
assert sale['payment_status']=='PAID'
assert request('POST','/api/orders',json=order)['duplicate']
assert next(p for p in request('GET','/api/products') if p['id']==pid)['stock_qty']==4
stored=request('GET','/api/orders/'+sale['id'])
assert stored['order']['status']=='PREPARING'
assert stored['items'][0]['line_total']==50000
request('PATCH','/api/products/'+pid,json={'price_paisa':60000})
assert request('GET','/api/orders/'+sale['id'])['items'][0]['unit_price']==25000
job=request('POST','/api/print-jobs',json={'order_id':sale['id'],'template':'compact','width':58})
assert job['status']=='QUEUED'
assert client.post('/api/print-jobs',json={'order_id':sale['id'],'template':'compact','width':58}).status_code==409
request('POST',f"/api/print-jobs/{job['id']}/submitted")
assert request('GET','/api/print-jobs')[0]['status']=='OUTCOME_UNKNOWN'
assert client.post('/api/orders/'+sale['id']+'/status',json={'status':'READY'}).status_code==409
for item in stored['items']:request('POST','/api/orders/'+sale['id']+'/tasks/'+item['id'],json={'done':True})
request('POST','/api/orders/'+sale['id']+'/status',json={'status':'READY'})
request('POST','/api/orders/'+sale['id']+'/status',json={'status':'COMPLETED'})
request('POST','/api/expenses',json={'category':'Utilities','amount_paisa':3200,'payment_method':'BANK_TRANSFER'})
assert request('GET','/api/report')['recorded_expenses']==3200
finance=request('GET','/api/finance')
assert finance['expenses_total']==3200 and finance['expense_methods'][0]['payment_method']=='BANK_TRANSFER'
pdf=client.get('/api/finance.pdf');assert pdf.status_code==200 and pdf.headers['content-type']=='application/pdf'
# Finance and PDF routes are restricted to the owner role.
manager_client=TestClient(app.app)
with app.tx() as c:
    salt='00112233445566778899aabbccddeeff'
    c.execute('INSERT INTO users(id,username,salt,password_hash,role,active) VALUES(?,?,?,?,?,1)',('manager-test-id','manager_test',salt,app.password_hash('ManagerTestPassword123!',salt),'manager'))
manager_client.post('/api/login',json={'username':'manager_test','password':'ManagerTestPassword123!'})
assert manager_client.get('/api/finance').status_code==403
assert manager_client.get('/api/finance.pdf').status_code==403
# Image upload accepts only verified image bytes and the stored file is served from managed media.
import base64
from PIL import Image
import io
image_bytes=io.BytesIO();Image.new('RGB',(8,8),'green').save(image_bytes,format='PNG')
png=base64.b64encode(image_bytes.getvalue()).decode()
img=request('POST',f'/api/products/{pid}/image',json={'data_url':'data:image/png;base64,'+png})
assert img['ok'] and client.get(img['image_path']).status_code==200
assert next(p for p in request('GET','/api/products') if p['id']==pid)['image_path']
zip_result=client.get('/api/backup');assert zip_result.status_code==200
import zipfile,io,json,hashlib
with zipfile.ZipFile(io.BytesIO(zip_result.content)) as z:
    db=z.read('hanan.sqlite3');man=json.loads(z.read('manifest.json'));assert hashlib.sha256(db).hexdigest()==man['database_sha256'];assert any(n.startswith('media/') for n in z.namelist())
assert client.get('/').status_code==200
import re
html=client.get('/').text
assets=sorted(set(re.findall(r'/static/([A-Za-z0-9_./-]+\.(?:css|js|png))',html)))
assert assets,'no static assets referenced by index.html'
for a in assets:
    r=client.get('/static/'+a)
    assert r.status_code==200,f'static asset not served: /static/{a} (HTTP {r.status_code})'
print('PASS: auth, categories, products, stock, orders, idempotency, historical price, receipt queue, reprint warning, print unknown, statuses, expenses, owner finance, PDF export, menu image upload, media backup hashes, frontend route, static assets (%d)'%len(assets))
