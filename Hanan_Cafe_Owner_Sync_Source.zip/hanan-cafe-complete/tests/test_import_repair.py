"""Restoring a backup from another installation preserves media and authenticates correctly."""
import os,sys,tempfile,io,json,zipfile,sqlite3,hashlib,uuid
from pathlib import Path
os.environ['HANAN_DATA_DIR']=tempfile.mkdtemp(prefix='hanan-import-')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
import app
app.create_owner('owner','RestoreFixture123!');c=TestClient(app.app);c.post('/api/login',json={'username':'owner','password':'RestoreFixture123!'})
raw=c.get('/api/backup').content
# Represent a genuine older installation with a different owner ID.
with zipfile.ZipFile(io.BytesIO(raw)) as z:files={n:z.read(n) for n in z.namelist()}
path=Path(tempfile.mkdtemp())/'backup.db';path.write_bytes(files['hanan.sqlite3'])
db=sqlite3.connect(path);old=db.execute("SELECT id FROM users WHERE role='owner'").fetchone()[0];new=uuid.uuid4().hex
for table in [x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")]:
 for fk in db.execute('PRAGMA foreign_key_list('+table+')').fetchall():
  if fk[2]=='users':db.execute('UPDATE '+table+' SET '+fk[3]+'=? WHERE '+fk[3]+'=?',(new,old))
db.execute('UPDATE users SET id=? WHERE id=?',(new,old));db.commit();db.close();files['hanan.sqlite3']=path.read_bytes();manifest=json.loads(files['manifest.json']);manifest['database_sha256']=hashlib.sha256(files['hanan.sqlite3']).hexdigest();files['manifest.json']=json.dumps(manifest).encode()
out=io.BytesIO()
with zipfile.ZipFile(out,'w') as z:
 for n,v in files.items():z.writestr(n,v)
p=c.get('/api/products').json()[0];image=p['image_path'];oldbytes=(app.MEDIA/image).read_bytes();(app.MEDIA/image).write_bytes(oldbytes+b'changed-after-backup');changed=(app.MEDIA/image).read_bytes()
preview=c.post('/api/backup/preview',content=out.getvalue());assert preview.status_code==200,preview.text
restore=c.post('/api/backup/restore',json={'token':preview.json()['token'],'password':'RestoreFixture123!','confirmation':'RESTORE HANAN CAFE'});assert restore.status_code==200,restore.text
assert restore.json()['remapped_media']==1 and c.get('/api/me').status_code==401
assert c.post('/api/login',json={'username':'owner','password':'RestoreFixture123!'}).status_code==200
restored=next(x for x in c.get('/api/products').json() if x['id']==p['id']);assert restored['image_path']!=image
assert (app.MEDIA/restored['image_path']).read_bytes()==oldbytes and (app.MEDIA/image).read_bytes()==changed
assert len(c.get('/api/backup/recovery').json())==1
assert c.post('/api/backup/preview',content=b'not a zip').status_code==400
print('PASS: generated ZIP preview and full restore with different owner ID and colliding image; restored image works, original media/recovery retained, sessions invalidated and login works')
