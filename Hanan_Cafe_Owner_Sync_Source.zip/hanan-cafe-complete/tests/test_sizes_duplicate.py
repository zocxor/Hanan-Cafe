"""Isolated tests for priced pizza sizes, duplication and simplified fulfilment."""
import os,tempfile,sys,subprocess
from pathlib import Path
os.environ['HANAN_DATA_DIR']=tempfile.mkdtemp(prefix='hanan-sizes-')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
import app
app.create_owner('owner','SizeTestPassword123!');c=TestClient(app.app)
def ok(method,path,**kw):
 r=c.request(method,path,**kw);assert r.status_code<400,(path,r.status_code,r.text);return r
ok('POST','/api/login',json={'username':'owner','password':'SizeTestPassword123!'})
pizzas=[p for p in ok('GET','/api/products').json() if p['category']=='Pizza'];assert len(pizzas)==5
for p in pizzas:
 assert [v['label'] for v in p['variants']]==['Small','Medium','Large','XL']
 assert all(v['price_paisa']==p['price_paisa'] for v in p['variants'])
p=pizzas[0];pid=p['id'];sizes=p['variants']
ok('PATCH','/api/products/'+pid+'/variants',json={'sizes':[{'label':v['label'],'price_paisa':(i+1)*10000,'active':1} for i,v in enumerate(sizes)]})
line=lambda v,q=1:{'product_id':pid,'variant_id':v,'qty':q}
base={'idempotency_key':'size-test-order-00001','order_type':'COUNTER','payment_method':'UNPAID','items':[line(sizes[0]['id'],2),line(sizes[3]['id'])]}
o=ok('POST','/api/orders',json=base).json();assert o['grand_total']==60000
snapshot=ok('GET','/api/orders/'+o['id']).json();assert {i['name'].split(' · ')[-1] for i in snapshot['items']}=={'Small','XL'}
assert [i['unit_price'] for i in snapshot['items']]==[10000,40000]
ok('POST','/api/orders/'+o['id']+'/status',json={'status':'READY','complete_all':True})
assert all(i['kitchen_done'] for i in ok('GET','/api/orders/'+o['id']).json()['items'])
ok('POST','/api/orders/'+o['id']+'/status',json={'status':'COMPLETED'})
assert ok('GET','/api/orders/'+o['id']).json()['order']['payment_status']=='UNPAID'
assert c.post('/api/orders',json={**base,'idempotency_key':'missing-size-order-01','items':[{'product_id':pid,'qty':1}]}).status_code==400
assert c.post('/api/orders',json={**base,'idempotency_key':'invalid-size-order-01','items':[line('not-a-size')]}).status_code==400
ok('PATCH','/api/products/'+pid,json={'stock_tracking':1})
ok('POST','/api/stock',json={'product_id':pid,'delta':5,'reason':'Test fixture'})
assert c.post('/api/orders',json={**base,'idempotency_key':'stock-size-order-01','items':[line(sizes[0]['id'],3),line(sizes[1]['id'],3)]}).status_code==400
copy=ok('POST','/api/products/'+pid+'/duplicate',json={'name':'New named pizza'}).json()['id']
new=next(p for p in ok('GET','/api/products').json() if p['id']==copy)
assert new['id']!=pid and new['image_path']==p['image_path'] and not new['stock_tracking'] and new['stock_qty']==0 and not new['starter_key']
assert [v['price_paisa'] for v in new['variants']]==[10000,20000,30000,40000]
assert c.post('/api/products/'+pid+'/duplicate',json={'name':p['name']}).status_code==400
ok('PATCH','/api/products/'+pid+'/variants',json={'sizes':[{'label':v['label'],'price_paisa':99999,'active':1} for v in sizes]})
assert [i['unit_price'] for i in ok('GET','/api/orders/'+o['id']).json()['items']]==[10000,40000]
ok('POST','/api/users',json={'username':'cashier','password':'Cashier123!','role':'cashier'})
staff=TestClient(app.app);staff.post('/api/login',json={'username':'cashier','password':'Cashier123!'})
assert staff.patch('/api/products/'+pid+'/variants',json={}).status_code==403
assert staff.post('/api/products/'+pid+'/duplicate',json={'name':'No'}).status_code==403
backup=ok('GET','/api/backup').content;v=ok('POST','/api/backup/preview',content=backup).json()
ok('POST','/api/backup/restore',json={'token':v['token'],'password':'SizeTestPassword123!','confirmation':'RESTORE HANAN CAFE'})
ok('POST','/api/login',json={'username':'owner','password':'SizeTestPassword123!'})
assert len(ok('GET','/api/products/'+copy+'/variants').json())==4
ok('POST','/api/backup/factory-reset',json={'password':'SizeTestPassword123!','confirmation':'RESET HANAN CAFE'})
assert not app.rows('SELECT * FROM product_variants')
print('PASS: 5 pizzas × 4 sizes; server prices; mixed-size cart; size validation; aggregate stock; immutable order size/price; kitchen one-click ready; unpaid state preserved; duplication with variants/image and untracked stock; name validation; cashier denials; backup restore and reset of sizes.')
