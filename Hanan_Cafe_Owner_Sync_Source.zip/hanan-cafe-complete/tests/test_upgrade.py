"""Run directly; all destructive tests use a new temporary data directory."""
import os,sys,tempfile,io,json,base64,zipfile,hashlib,subprocess
from pathlib import Path
os.environ['HANAN_DATA_DIR']=tempfile.mkdtemp(prefix='hanan-upgrade-test-')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
from PIL import Image
import app
app.create_owner('owner','SafeTestPassword123!')
c=TestClient(app.app)
def ok(method,path,**kwargs):
 r=c.request(method,path,**kwargs);assert r.status_code<400,(path,r.status_code,r.text);return r
ok('POST','/api/login',json={'username':'owner','password':'SafeTestPassword123!'})
products=ok('GET','/api/products').json();assert len(products)==24
assert len({p['id'] for p in products})==24
assert len({p['image_path'] for p in products})==24
for p in products:
 assert p['description'] and p['starter_key'] and p['active'] and not p['stock_tracking']
 image=ok('GET','/media/'+p['image_path']);Image.open(io.BytesIO(image.content)).verify()
assert not ok('GET','/api/orders').json()
pid=products[0]['id'];old=products[0]['image_path']
ok('PATCH','/api/products/'+pid,json={'price_paisa':12345,'description':'Owner edit','active':0})
for _ in range(2):assert ok('POST','/api/catalogue/seed').json()['added']==0
p=next(x for x in ok('GET','/api/products').json() if x['id']==pid)
assert (p['price_paisa'],p['description'],p['active'],p['image_path'])==(12345,'Owner edit',0,old)
ok('PATCH','/api/products/'+pid,json={'active':1})
img=io.BytesIO();Image.new('RGB',(60,40),'orange').save(img,'PNG');data='data:image/png;base64,'+base64.b64encode(img.getvalue()).decode()
ok('POST','/api/products/'+pid+'/image',json={'data_url':data})
assert c.post('/api/products/'+pid+'/image',json={'data_url':'data:image/png;base64,aW52YWxpZA=='}).status_code==400
assert c.post('/api/products/'+pid+'/image',json={'data_url':'data:image/png;base64,'+base64.b64encode(b'x'*(3*1024*1024+1)).decode()}).status_code==413
history=ok('GET','/api/products/'+pid+'/image-history').json();assert any(h['image_path']==old for h in history)
ok('POST','/api/products/'+pid+'/image-restore',json={'history_id':history[0]['id']})
ok('DELETE','/api/products/'+pid+'/image');assert ok('GET','/media/'+old).status_code==200
history=ok('GET','/api/products/'+pid+'/image-history').json();h=next(h for h in history if h['image_path']==old)
ok('POST','/api/products/'+pid+'/image-restore',json={'history_id':h['id']})
# Correct quantity totals, fees, immutable order snapshots, unpaid method.
order=ok('POST','/api/orders',json={'idempotency_key':'upgrade-test-unique-id-000001','order_type':'COUNTER','payment_method':'UNPAID','items':[{'product_id':pid,'qty':3}],'service_charge_paisa':5000,'amount_paid_paisa':0}).json()
assert order['grand_total']==12345*3+5000 and order['payment_status']!='PAID'
assert c.post('/api/orders/'+order['id']+'/status',json={'status':'READY'}).status_code==409
v=ok('GET','/api/orders/'+order['id']).json()
for item in v['items']:ok('POST','/api/orders/'+order['id']+'/tasks/'+item['id'],json={'done':True})
ok('POST','/api/orders/'+order['id']+'/status',json={'status':'READY'})
ok('PATCH','/api/products/'+pid,json={'price_paisa':99900})
assert ok('GET','/api/orders/'+order['id']).json()['items'][0]['unit_price']==12345
ok('POST','/api/users',json={'username':'cashier','password':'Cashier123!','role':'cashier'})
staff=TestClient(app.app);staff.post('/api/login',json={'username':'cashier','password':'Cashier123!'})
for path in ['/api/catalogue/seed','/api/backup/preview','/api/backup/restore','/api/backup/factory-reset']:
 assert staff.post(path,json={}).status_code==403,path
assert staff.patch('/api/products/'+pid,json={'price_paisa':1}).status_code==403
backup=ok('GET','/api/backup').content
assert c.post('/api/backup/preview',content=b'bad zip').status_code==400
# Tampering must fail validation.
b=io.BytesIO()
with zipfile.ZipFile(io.BytesIO(backup)) as src,zipfile.ZipFile(b,'w') as out:
 for name in src.namelist():out.writestr(name,b'tampered' if name=='hanan.sqlite3' else src.read(name))
assert c.post('/api/backup/preview',content=b.getvalue()).status_code==400
preview=ok('POST','/api/backup/preview',content=backup).json();assert preview['counts']['products']==24
assert c.post('/api/backup/restore',json={'token':preview['token'],'password':'wrong','confirmation':'RESTORE HANAN CAFE'}).status_code==403
ok('PATCH','/api/products/'+pid,json={'price_paisa':77700})
result=ok('POST','/api/backup/restore',json={'token':preview['token'],'password':'SafeTestPassword123!','confirmation':'RESTORE HANAN CAFE'}).json()
assert (app.DATA/'recovery'/result['recovery']).is_file()
assert c.get('/api/products').status_code==401
ok('POST','/api/login',json={'username':'owner','password':'SafeTestPassword123!'})
assert next(p for p in ok('GET','/api/products').json() if p['id']==pid)['price_paisa']==99900
assert len(ok('GET','/api/orders').json())==1
# A new process reopens the database without losing edits or duplicating starters.
subprocess.run([sys.executable,'-c',"import app; assert len(app.rows('SELECT * FROM products'))==24; assert len(app.rows('SELECT * FROM orders'))==1"],cwd=str(app.BASE),env=os.environ.copy(),check=True)
assert c.post('/api/backup/factory-reset',json={'password':'SafeTestPassword123!','confirmation':'wrong'}).status_code==400
reset=ok('POST','/api/backup/factory-reset',json={'password':'SafeTestPassword123!','confirmation':'RESET HANAN CAFE'}).json()
assert (app.DATA/'recovery'/reset['recovery']).exists()
ok('POST','/api/login',json={'username':'owner','password':'SafeTestPassword123!'})
assert ok('GET','/api/products').json()==[] and ok('GET','/api/orders').json()==[]
assert len(ok('GET','/api/users').json())==1
subprocess.run([sys.executable,'-c',"import app; assert not app.rows('SELECT * FROM products')"],cwd=str(app.BASE),env=os.environ.copy(),check=True)
assert ok('POST','/api/catalogue/seed').json()['added']==24
files=ok('GET','/api/backup/recovery').json();assert len(files)==2
for f in files:assert ok('GET','/api/backup/recovery/'+f['name']).content.startswith(b'PK')
print('PASS: 24 records and 24 unique local images; zero fake transactions; seed idempotency and edit preservation; image validation, history, removal and restore; quantities/fees and historical prices; kitchen tasks; unauthorized access; corrupt backups; preview, restore and pre-restore archive; factory reset and recovery ZIP; restart persistence and reset persistence.')
