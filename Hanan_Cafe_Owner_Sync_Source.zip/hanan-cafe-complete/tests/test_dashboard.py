"""Dashboard totals cover the full database and Pakistan business dates."""
import os,sys,tempfile,uuid
from pathlib import Path
from datetime import datetime,timedelta,timezone
os.environ['HANAN_DATA_DIR']=tempfile.mkdtemp(prefix='hanan-dashboard-')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
import app
app.create_owner('owner','DashboardFixture123!');c=TestClient(app.app)
assert c.get('/api/dashboard').status_code==401
assert c.post('/api/login',json={'username':'owner','password':'DashboardFixture123!'}).status_code==200
assert c.get('/api/dashboard').json()['orders_today']==0
pid=c.get('/api/products').json()[0]['id']
r=c.post('/api/orders',json={'idempotency_key':'dashboard-base','order_type':'COUNTER','payment_method':'UNPAID','items':[{'product_id':pid,'qty':1}]});assert r.status_code==200,r.text
oid=r.json()['id'];today=datetime.now(timezone(timedelta(hours=5))).date()
# Test database only: add enough historical rows to exceed the recent-list cap.
with app.tx() as db:
 source=dict(db.execute('SELECT * FROM orders WHERE id=?',(oid,)).fetchone());columns=list(source)
 for n in range(304):
  data=source.copy();data['id']=uuid.uuid4().hex;data['order_no']=n+2;data['status']=['COMPLETED','CANCELLED','READY','PREPARING'][n%4];data['created_at']=str(today)+'T07:00:00+00:00'
  db.execute('INSERT INTO orders('+','.join(columns)+') VALUES('+','.join('?' for _ in columns)+')',[data[k] for k in columns])
 db.execute('UPDATE orders SET created_at=? WHERE id=?',(str(today-timedelta(days=1))+'T19:30:00+00:00',oid))
d=c.get('/api/dashboard').json();assert d['orders_today']==305,d
assert (d['completed'],d['cancelled'],d['pending'],d['ready'])==(76,76,153,76),d
assert len(c.get('/api/orders').json())==300
assert d['order_value']==source['grand_total']*229
assert d['days'][-1]['orders']==305 and sum(x['orders'] for x in d['days'])==305
assert c.post('/api/users',json={'username':'limited','password':'DashboardFixture123!','role':'cashier','permissions':['POS']}).status_code==200
limited=TestClient(app.app);limited.post('/api/login',json={'username':'limited','password':'DashboardFixture123!'})
assert limited.get('/api/dashboard').status_code==403
print('PASS: full database counts beyond 300, cancelled exclusions, status breakdown, Pakistan date boundary, empty state and permissions')
a=c.post('/api/products/'+pid+'/duplicate',json={'auto_name':True});assert a.status_code==200,a.text
assert c.delete('/api/products/'+a.json()['id']).status_code==200
b=c.post('/api/products/'+pid+'/duplicate',json={'auto_name':True});assert b.status_code==200,b.text
copy=next(x for x in c.get('/api/products').json() if x['id']==b.json()['id']);assert copy['name'].endswith(' — copy 2')
assert not copy['stock_tracking'] and copy['stock_qty']==0
print('PASS: instant duplicate names remain unique after a prior copy is deleted')
