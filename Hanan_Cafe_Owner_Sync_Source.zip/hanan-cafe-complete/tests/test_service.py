"""Isolated service regression tests; no business fixture data is shipped."""
import os,tempfile,sys,json,subprocess
from pathlib import Path
os.environ['HANAN_DATA_DIR']=tempfile.mkdtemp(prefix='hanan-service-')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
import app
app.create_owner('owner','ServiceTestPassword123!');c=TestClient(app.app)
def ok(method,path,**kw):
 r=c.request(method,path,**kw);assert r.status_code<400,(path,r.status_code,r.text);return r
ok('POST','/api/login',json={'username':'owner','password':'ServiceTestPassword123!'})
products=ok('GET','/api/products').json();p=next(x for x in products if x['name']=='Beef Burger');pid=p['id']
ok('PATCH','/api/products/'+pid,json={'stock_tracking':1});ok('POST','/api/stock',json={'product_id':pid,'delta':20,'reason':'Isolated test stock'})
def order(key,**extra):return ok('POST','/api/orders',json={'idempotency_key':'service-order-'+key,'order_type':'COUNTER','payment_method':'UNPAID','items':[{'product_id':pid,'qty':2}],'customer':'Fixture Customer','phone':'0300 000 0000',**extra}).json()
a=order('first',payment_method='CASH',amount_paid_paisa=130000)
summary=next(x for x in ok('GET','/api/orders').json() if x['id']==a['id']);assert summary['items_summary']==[{'name':'Beef Burger','qty':2}] and '2 × Beef Burger' in summary['summary']
contacts=ok('GET','/api/customers').json();assert len(contacts)==1 and not contacts[0]['marketing_opt_in']
b=order('second',phone='03000000000');assert len(ok('GET','/api/customers').json())==1
contact=contacts[0];ok('PATCH','/api/customers/'+contact['id'],json={'notes':'Greeting preference test','marketing_opt_in':1})
order('third');assert ok('GET','/api/customers').json()[0]['marketing_opt_in']==1
assert c.post('/api/customers',json={'name':'Duplicate','phone':'03000000000'}).status_code==409
assert c.post('/api/customers',json={'name':'Bad','phone':'abc'}).status_code==400
# One atomic print batch creates the exact requested templates even for a cashier.
ok('POST','/api/users',json={'username':'cashier','password':'Cashier123!','role':'cashier'})
staff=TestClient(app.app);staff.post('/api/login',json={'username':'cashier','password':'Cashier123!'})
assert staff.get('/api/customers').status_code==200
batch=staff.post('/api/print-jobs/batch',json={'order_id':a['id'],'mode':'both','width':80});assert batch.status_code==200,batch.text
assert [x['template'] for x in batch.json()['jobs']]==['standard','kitchen']
assert staff.post('/api/print-jobs/batch',json={'order_id':a['id'],'mode':'both','width':80}).status_code==409
for job in batch.json()['jobs']:ok('POST','/api/print-jobs/'+job['id']+'/submitted')
assert all(x['status']=='OUTCOME_UNKNOWN' for x in ok('GET','/api/print-jobs').json())
assert staff.post('/api/orders/'+b['id']+'/status',json={'status':'READY','complete_all':True}).status_code==200
assert staff.post('/api/orders/'+b['id']+'/status',json={'status':'COMPLETED'}).status_code==200
assert c.post('/api/orders/'+b['id']+'/cancel',json={'reason':'Completed record'}).status_code==409
assert staff.post('/api/orders/'+a['id']+'/cancel',json={'reason':'Customer cancelled','return_stock':True}).status_code==403
before=app.rows('SELECT stock_qty FROM products WHERE id=?',(pid,))[0]['stock_qty']
can=ok('POST','/api/orders/'+a['id']+'/cancel',json={'reason':'Unused test order','return_stock':True}).json();assert can['refund_review_paisa']==130000 and not can['refund_processed']
assert app.rows('SELECT stock_qty FROM products WHERE id=?',(pid,))[0]['stock_qty']==before+2
ok('POST','/api/orders/'+a['id']+'/cancel',json={'reason':'Retry','return_stock':True});assert app.rows('SELECT stock_qty FROM products WHERE id=?',(pid,))[0]['stock_qty']==before+2
assert ok('GET','/api/orders/'+a['id']).json()['order']['amount_paid']==130000
# Custom finance dates include the Pakistan business date, not UTC's preceding date.
with app.tx() as db:
 db.execute('UPDATE orders SET created_at=?',('2026-10-16T10:00:00+00:00',))
 db.execute('UPDATE orders SET created_at=? WHERE id=?',('2026-10-17T19:30:00+00:00',b['id']))
q='?period=custom&start_date=2026-10-18&end_date=2026-10-18'
v=ok('GET','/api/finance'+q).json();assert v['orders']['orders_count']==1 and v['orders']['sales']==130000
assert c.get('/api/finance?period=custom&start_date=2026-10-19&end_date=2026-10-18').status_code==400
assert c.get('/api/finance.pdf?period=custom').status_code==400
assert staff.get('/api/finance.pdf'+q).status_code==403
report=ok('GET','/api/finance.pdf'+q);assert report.content.startswith(b'%PDF')
out=Path(os.environ.get('HANAN_TEST_OUTPUT',tempfile.mkdtemp(prefix='hanan-export-')));out.mkdir(parents=True,exist_ok=True);pdf=out/'Finance_Custom.pdf';pdf.write_bytes(report.content)
text=subprocess.check_output(['pdftotext',str(pdf),'-'],text=True);assert '2026-10-18' in text and '1,300.00' in text and 'Net amount recorded' in text
# Delete is a catalogue tombstone; transaction snapshots and seeded identities remain.
ok('DELETE','/api/products/'+pid);assert all(x['id']!=pid for x in ok('GET','/api/products').json())
assert ok('GET','/api/orders/'+b['id']).json()['items'][0]['name']=='Beef Burger'
assert ok('POST','/api/catalogue/seed').json()['added']==0
backup=ok('GET','/api/backup').content;preview=ok('POST','/api/backup/preview',content=backup).json();ok('POST','/api/backup/restore',json={'token':preview['token'],'password':'ServiceTestPassword123!','confirmation':'RESTORE HANAN CAFE'})
ok('POST','/api/login',json={'username':'owner','password':'ServiceTestPassword123!'})
assert len(ok('GET','/api/customers').json())==1 and app.rows('SELECT * FROM order_cancellations')
ok('POST','/api/backup/factory-reset',json={'password':'ServiceTestPassword123!','confirmation':'RESET HANAN CAFE'})
assert not app.rows('SELECT * FROM customers') and not app.rows('SELECT * FROM order_cancellations')
for name in ['service.js','themes.css','assets/ztechx-logo.png']:assert c.get('/static/'+name).status_code==200
assert c.get('/static/services.py').status_code==404
print('PASS: item summaries; normalized contacts with explicit offer preference; atomic both-slip print queue; cashier fulfilment; audited cancellation/refund review/optional stock return once; custom-date finance/PDF; product deletion preserves history; backup/restore/reset includes new tables; safe static assets.')
