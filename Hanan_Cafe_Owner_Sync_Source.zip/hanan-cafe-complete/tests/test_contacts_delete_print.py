"""Isolated regression: per-contact deletion and receipt separation preferences."""
import os,sys,tempfile
from pathlib import Path
os.environ['HANAN_DATA_DIR']=tempfile.mkdtemp(prefix='hanan-delete-')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
import app
app.create_owner('owner','ContactsFixture123!');c=TestClient(app.app);c.post('/api/login',json={'username':'owner','password':'ContactsFixture123!'})
assert c.get('/api/settings').json()['receipt_separation']=='pages'
assert c.patch('/api/settings',json={'receipt_separation':'continuous'}).status_code==200
app.init();assert c.get('/api/settings').json()['receipt_separation']=='continuous'
assert c.patch('/api/settings',json={'receipt_separation':'bad'}).status_code==400
pid=c.get('/api/products').json()[0]['id']
o=c.post('/api/orders',json={'idempotency_key':'contact-history','order_type':'COUNTER','payment_method':'UNPAID','customer':'Fixture A','phone':'03000000001','items':[{'product_id':pid,'qty':1}]}).json()
a=c.get('/api/customers').json()[0];b=c.post('/api/customers',json={'name':'Fixture B','phone':'03000000002'}).json()
assert c.post('/api/users',json={'username':'cashier','password':'ContactsFixture123!','role':'cashier'}).status_code==200
cashier=TestClient(app.app);cashier.post('/api/login',json={'username':'cashier','password':'ContactsFixture123!'})
assert cashier.delete('/api/customers/'+a['id']).status_code==403
assert TestClient(app.app).delete('/api/customers/'+a['id']).status_code==401
assert c.delete('/api/customers/'+a['id']).status_code==200
assert [x['id'] for x in c.get('/api/customers').json()]==[b['id']]
v=c.get('/api/orders/'+o['id']).json();assert v['order']['customer']=='Fixture A' and len(v['items'])==1
app.init();assert [x['id'] for x in c.get('/api/customers').json()]==[b['id']]
assert c.delete('/api/customers/'+a['id']).status_code==404
print('PASS: separation default/validation/persistence, unauthorized deletion denied, only selected contact removed, past order preserved, deleted contact not reimported on initialization')
