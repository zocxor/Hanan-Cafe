"""v0.5.0: backup import tolerates real-world ZIPs and cleans up stages."""
import os, sys, tempfile, io, zipfile
from pathlib import Path
os.environ['HANAN_DATA_DIR'] = tempfile.mkdtemp(prefix='hanan-import-050-')
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
import app
app.create_owner('owner', 'Import050Fixture!')
c = TestClient(app.app)
c.post('/api/login', json={'username': 'owner', 'password': 'Import050Fixture!'})
raw = c.get('/api/backup').content
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    files = {n: z.read(n) for n in z.namelist()}

def make_zip(entries):
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w') as z:
        for n, v in entries.items():
            z.writestr(n, v)
    return out.getvalue()

# 1. macOS/Windows metadata cruft is ignored, not rejected.
cruft = dict(files)
cruft['__MACOSX/manifest.json'] = b'junk'
cruft['__MACOSX/._hanan.sqlite3'] = b'junk'
cruft['.DS_Store'] = b'junk'
cruft['media/.DS_Store'] = b'junk'
r = c.post('/api/backup/preview', content=make_zip(cruft))
assert r.status_code == 200, r.text
print('PASS 1: __MACOSX/.DS_Store entries ignored')

# 2. Single top-level folder wrapper is accepted.
wrapped = {'Backup/' + n: v for n, v in files.items()}
r = c.post('/api/backup/preview', content=make_zip(wrapped))
assert r.status_code == 200, r.text
print('PASS 2: top-level folder wrapper accepted')

# 3. Missing manifest -> friendly 400, not a raw KeyError.
no_manifest = {n: v for n, v in files.items() if n != 'manifest.json'}
r = c.post('/api/backup/preview', content=make_zip(no_manifest))
assert r.status_code == 400, r.text
assert 'manifest.json is missing' in r.text, r.text
print('PASS 3: missing manifest gives friendly error')

# 4. Previewing twice does not leak stage directories.
import enhancements
r1 = c.post('/api/backup/preview', content=make_zip(files)); assert r1.status_code == 200
r2 = c.post('/api/backup/preview', content=make_zip(files)); assert r2.status_code == 200
import glob
stage_dirs = glob.glob(str(app.DATA / 'restore-*'))
assert len(stage_dirs) == 1, stage_dirs
print('PASS 4: superseded preview stage cleaned up')

# 5. Restore still succeeds end-to-end after cleanup hardening.
r = c.post('/api/backup/restore', json={'token': r2.json()['token'], 'password': 'Import050Fixture!', 'confirmation': 'RESTORE HANAN CAFE'})
assert r.status_code == 200, r.text
assert r.json()['ok'] is True
print('PASS 5: restore succeeds with hardened cleanup')
print('ALL v0.5.0 BACKUP IMPORT TESTS PASS')
