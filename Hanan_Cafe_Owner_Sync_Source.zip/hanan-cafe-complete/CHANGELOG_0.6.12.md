# Changelog 0.6.12 — Vertix-style dashboard

## Dashboard restructure (only the dashboard changed)

- Greeting header: "Good morning/afternoon/evening, <name>" with the date,
  plus Refresh and New order actions.
- Big "Today's sales" card (white text, both schemes) beside a 2x2 grid of
  the four order-count cards.
- "Sales overview": 7-day sales bar chart.
- "Order completion": progress bar (completed vs today's orders, with the
  ready-for-handoff count).
- Order status donut kept, now beside the progress card.
- Recent orders shown as a clean table (Order / Type / Time / Total / Status).
- Shortcuts kept as a compact strip.

All numbers come from the same live data as before; nothing else changed.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=0612`; hard-refresh once (Cmd+Shift+R).
