# Hanan Cafe v0.3.3 — Finance reporting refinement

- Reordered sidebar so Expenses and owner-only Finance appear directly above Settings.
- Added Today, Yesterday, Last 7 days, Last 30 days, This month, Last month, This year and All time finance filters.
- Added period selection to owner-only financial PDF export.
- Clarified cash accounting: customer tender, change returned, and net cash retained after change are reported separately.
- Order payment-method summaries report net cash retained for cash orders rather than the amount tendered before returning change.
- Removed the Application line and the grey local-first footer from Company & Developer Information.
- Removed cloud project identifiers from Settings. No cloud integration is claimed or enabled.
- Existing database schema is unchanged.
