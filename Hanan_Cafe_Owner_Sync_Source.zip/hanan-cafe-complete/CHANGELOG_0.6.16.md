# Changelog 0.6.16 — finance PDF redesign + column alignment

## Financial PDF export redesigned (app.py)

- Matches the new Finance page: dark brand header band, SUMMARY 2x2 cards,
  complete INCOME STATEMENT (Revenue / Less: expenses / Net income), then
  the payment-method tables — all in the Orange/Porcelain colour scheme.
- Page footer with page number and © 2026 Zocxorian Technology.
- Amounts now keep paisa (2 decimals) instead of truncating.

## Finance page alignment

- The cards column and the income statement now stretch to equal height,
  so both sides align top and bottom as one even block.

## Upgrade notes (IMPORTANT)

- This build changes BOTH app.py and static/ — replace both folders/files,
  keep your data directory, restart uvicorn, hard-refresh once (Cmd+Shift+R).
- Static asset versions bumped to `?v=0616`.
