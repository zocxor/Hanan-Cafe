# Hanan Cafe owner sync — source update

This package contains source code and build scripts, not compiled EXE/APK binaries.

The cafe retains SQLite and operates offline. An optional uploader sends a consistent record snapshot every 30 seconds over HTTPS. The relay keeps the last snapshot when the cafe is off. The owner dashboard polls every 30 seconds while open (normally up to about one minute end-to-end). It requires internet; records already displayed remain visible during an interruption, but are not persisted after closing the APK. Images and printable receipts are not synced. Credentials and sessions are excluded. The mobile dashboard is read-only and includes search across synced record tables.

## 1. Host the relay
Use a persistent server with Python 3 and an HTTPS reverse proxy. This server is separate from the cafe PC. Configure a durable RELAY_DB path and backups. Generate TWO independent keys with `python -c "import secrets; print(secrets.token_urlsafe(48))"`. Keep one as HANAN_SYNC_WRITE_TOKEN and the other as HANAN_OWNER_READ_TOKEN. Set these environment variables for the server process. Run `python cloud/server.py` as a managed service. Proxy your HTTPS domain to 127.0.0.1:8780, limit request size to 50 MiB, and rate-limit authentication failures at the proxy. Do not expose the localhost port directly. Each relay is for one cafe. The snapshot contains business/customer data; restrict server and backup access.

## 2. Configure the cafe
Set HANAN_SYNC_URL to the HTTPS relay origin and HANAN_SYNC_WRITE_TOKEN to the write key in the environment used to launch the POS. Never put the owner read key on cashier PCs. Restart the POS. Without these variables, the original local POS continues normally. The console reports sync success/pending; failures retry without blocking sales. The relay replaces its snapshot atomically; deletions propagate on the next upload. Large databases above 50 MiB of JSON require a future incremental-sync implementation.

## 3. Build Windows
On Windows with Python 3.12, run build-windows.bat. Distribute the ENTIRE dist/HananCafe folder; HananCafe.exe needs its companion files. Keep the console window open while using the app. For an existing cafe, point HANAN_DATA_DIR to its existing data directory before launching. Back up that directory first. New installations need an owner created using `python setup.py` from a Python environment with requirements installed. The EXE is unsigned.

## 4. Build Android
With Java 17, Android SDK 35 and Gradle 8.9, run `gradle -p android assembleDebug`. Install android/app/build/outputs/apk/debug/app-debug.apk for personal testing. It is a debug-signed testing APK, not a production signed release. On first open, enter the HTTPS relay origin, then the owner read key. The key is kept only in memory and must be entered again after restarting the app. The dashboard URL is remembered. Invalid HTTPS certificates are rejected.

Alternatively put this project's contents at a private GitHub repository root and run the included Build Hanan apps workflow. Download both artifacts from the workflow run. No cloud credentials are required for compilation; configure them at runtime. Workflow compilation has not been executed in this environment.

## Current validation
Python syntax and an isolated relay round trip/authentication/persistence test were run. Windows EXE compilation, Android APK compilation, real-device UI checks and deployment have not been performed. A real HTTPS relay URL and deployment environment remain required before remote syncing works.
