"""Create first local owner account. No default passwords."""
from getpass import getpass
from app import create_owner
if __name__=='__main__':
    username=input('Owner username: ').strip()
    pw=getpass('Owner password (at least 12 characters): ')
    confirm=getpass('Confirm password: ')
    if not username or pw!=confirm: raise SystemExit('Username missing or password mismatch')
    create_owner(username,pw)
    print('Owner created. Start app with: python -m uvicorn app:app --host 127.0.0.1 --port 8765')
