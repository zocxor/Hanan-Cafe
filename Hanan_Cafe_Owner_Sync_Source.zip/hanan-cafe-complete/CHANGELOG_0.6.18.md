# Changelog 0.6.18 — expense edit/delete + permission checkboxes

## Expense history: edit & delete (app.py + static)

- New Actions column in Expense history with edit (pencil) and delete
  (trash) icon buttons, matching the Users page style.
- Edit prompts for category, amount, method and description; delete asks
  for confirmation. Both write to the audit log.
- New endpoints: PATCH /api/expenses/{id}, DELETE /api/expenses/{id}
  (owner/manager only).

## Users page: permission checkboxes fixed

- Custom checkboxes with a bold, clearly visible checkmark in both
  colour schemes (washed-out native rendering replaced).

## Upgrade notes (IMPORTANT)

- This build changes BOTH app.py and static/ — replace both, keep your
  data directory, restart uvicorn, hard-refresh once (Cmd+Shift+R).
- Static asset versions bumped to `?v=0618`.

## Also included (v0.6.17)

- Dashboard Order status card redesigned: neon glowing ring with slow
  rotating radar sheen, gradient center number, pulsing LIVE indicator,
  legend rebuilt as telemetry share bars. Same data, both schemes.
