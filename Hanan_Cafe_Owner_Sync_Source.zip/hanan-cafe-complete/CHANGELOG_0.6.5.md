# Changelog 0.6.5 — compact centered staff form

## Users page

- The "Create staff account" form no longer stretches across the whole page;
  it is now a concise card (max 680px) centered at the top. The staff list
  below is unchanged.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=065`; hard-refresh once (Cmd+Shift+R).
