# Hanan Cafe — Update 0.2.0

- Renamed Products navigation to Menu.
- Added editable menu item forms, soft-delete/archive and restore.
- Added managed menu image uploads (JPG, PNG, WebP), replacement, removal and image backup coverage.
- Added selected-item highlighting, quantity controls, per-item instructions and clearer sold-out status in POS.
- Added expense payment-method recordkeeping.
- Added owner-only Financial Management page and server-enforced owner-only PDF export.
- Added cloud project identifiers as references without enabling cloud sync or payment processing.
- Redesigned the interface with stronger contrast, polished tactile cards, glass surfaces, CSS transitions, and reduced-motion support.
- Removed the design-percentage line from Company & Developer Information.
- Preserved old databases with additive schema migrations.

## Explicitly not included in this update

- React/Vite migration or installed shadcn/ui, Aceternity UI, Magic UI, 21st.dev, Framer Motion, or GSAP packages. The existing frontend is vanilla JavaScript, so this release uses accessible CSS motion instead of claiming those libraries are integrated.
- Firebase synchronization or cloud-hosted database.
- Actual bank/wallet transactions or payment verification.
- Tested physical ESC/POS printer output.
- Automated backup restoration.
