# v0.4.0

- Forest green/cream/orange shared design system, prominent heritage branding, glass navigation, compact catalogue and responsive POS.
- 24 starter dishes with distinct optimized, bundled licensed food photos, stable identifiers, descriptions and owner-editable PKR prices.
- Idempotent starter registry; explicit seed action for existing databases; no fake transactions or stock.
- Durable media, validated uploads, cropping/repositioning, full previews, retained image history and restore.
- Menu search, category/status filters, grid/list views, pagination, compact editor and category reorder/archive.
- Kitchen lanes, persisted item preparation tasks, elapsed time, preparation target and refresh state.
- Quantity controls, notes, service charges, duplicate-submit prevention and independent payment/fulfilment state.
- Owner-only generate/import backup, integrity preview, password-confirmed restore/reset and automatic downloadable recovery archives.
- Additive database migrations, new-install user data directory, existing legacy data directory detection.
