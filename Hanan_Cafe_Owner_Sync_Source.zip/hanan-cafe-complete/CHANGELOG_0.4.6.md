# 0.4.6 — Electric green, expense contrast and receipt separation

- Navy / AI Green now has an AI-green navigation surface, dark active item with green lettering, a green orders card and a mint status card. Dark text remains readable on the green surfaces.
- Expenses total has an explicit high-contrast surface and text colour, full opacity and larger weight/size in all three themes.
- Dashboard New order is a large primary action with a larger plus icon, 58px desktop height and 18px label.
- New Settings control: Customer & kitchen separation. Default Separate slips starts each ticket on a new page in one print dialog. Continuous roll remains selectable and retains the manual cut line. The default is added without overwriting existing settings.
- Automatic cutting requires a cutter-equipped printer with its driver configured to cut after each page. The application does not send cutter commands. Physical cutting and printer output are not verified. Choose All pages in the print dialog.
- Browser checks cover all three themes and responsive layouts, expense total visibility, the green navigation, large New order action, both-slip document creation and both separation modes. 58mm and 80mm separate-mode proofs contain two pages; the short continuous-mode proof contains one page.

- Customers: owner/manager delete icon with Keep/Delete confirmation. Deletes only the chosen directory contact; historical order snapshots remain. Deletion persists across reload and does not rerun historical contact import.
- Settings: compact Cafe profile/receipt settings and My profile side by side on desktop, stacking below 1051px. Existing forms and permissions remain intact.
