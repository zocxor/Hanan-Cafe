# Hanan Cafe 0.3.2 — Kitchen board layout

- Replaced the large square kitchen card grid with a compact horizontal ticket list.
- Aligned order reference, order type, timestamp/status, items/instructions, and the next-stage action in a single row on desktop.
- Added tablet/mobile layout rules that preserve readable horizontal ticket structure and allow the action to wrap below details on narrow screens.
- No database schema or order workflow changes.
