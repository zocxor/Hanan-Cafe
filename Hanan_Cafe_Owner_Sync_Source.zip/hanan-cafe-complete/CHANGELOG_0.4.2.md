# v0.4.2 — Premium visuals, pizza sizes and practical checkout

- Pistachio/deep teal/ice blue/coral theme, heritage wordmark, glass navigation, tactile cards and selected-item effects.
- Bundled local Lucide 1.59.0 icons and Motion 14.3.0 animations, with reduced-motion support. No runtime CDN requirement.
- 24 optimized generated food cutouts with genuine alpha transparency; image containers reduced 10%, object-fit contain and soft CSS shadows.
- One-time refresh for untouched shipped starter photos; owner uploads/prices/edits and image history preserved.
- Kitchen and Orders share Mark ready → Mark delivered, without per-item checkboxes or override prompts.
- Bounded order card, scrollable fields, pinned totals/Confirm order; checkout field values retained when changing quantities.
- Four priced sizes per pizza: Small, Medium, Large, XL. Server validates price/size/availability and combined stock across sizes. Ordered size/price are snapshotted in receipts and kitchen tickets.
- Duplicate dish with a new name, copied details/image/size prices and independent ID; stock quantities are not copied.
- Fixed the static asset allowlist so new CSS/JavaScript and bundled libraries actually load. Asset URLs are versioned.
