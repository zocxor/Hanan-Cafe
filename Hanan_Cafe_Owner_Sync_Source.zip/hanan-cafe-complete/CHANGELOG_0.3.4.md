# Hanan Cafe v0.3.4 — Simplified Order Stages

- New orders start at PREPARING; order placement is treated as confirmation.
- Simplified staff flow: PREPARING → READY → COMPLETED for counter/parcel, or DELIVERED for delivery.
- Kitchen tickets use compact horizontal rows with responsive mobile layout.
- Print queue history now includes an Open / Print receipt action that opens the selected job in Receipt Studio with its saved template and paper width.
- Dashboard metrics explicitly show Orders today, Today's turnover, and All-time turnover (excluding cancelled orders), with date scope clarified.
- Legacy RECEIVED and CONFIRMED orders remain manageable and are presented as PREPARING in the interface.
