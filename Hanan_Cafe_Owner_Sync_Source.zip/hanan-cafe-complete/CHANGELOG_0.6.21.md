# Changelog 0.6.21 — receipts, expenses, finance PDF, chart values

## Receipts: concise preview slip

- The preview slip is more compact (smaller type, tighter spacing) so it
  uses the page space better. Screen-only CSS — the printed receipt is
  unchanged.

## Expense history: clearer action icons

- Edit/delete icons are bolder, properly centered and clearly visible.

## Finance: Download PDF with custom dates

- New "Download PDF" button next to "Apply custom dates" — downloads the
  financial PDF for the From/To dates shown (validates the range).

## Dashboard: sales values on chart bars

- Each of the 7 bars in Sales overview now shows its value above the bar.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=0621`; hard-refresh once (Cmd+Shift+R).
