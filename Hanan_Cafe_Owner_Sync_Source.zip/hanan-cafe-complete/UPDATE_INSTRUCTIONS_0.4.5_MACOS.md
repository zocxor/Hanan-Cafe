# Update to 0.4.5 on macOS

Generate a backup under Settings first. Stop the running server with Control+C. Extract this ZIP over the existing application folder; keep its existing data location and virtual environment.

```bash
unzip -o "$HOME/Downloads/Hanan_Cafe_v0.4.5_Dashboard_Compact_POS_Update.zip" -d "$HOME/Downloads/Hanan_Cafe_v040"
cd "$HOME/Downloads/Hanan_Cafe_v040/hanan-cafe-complete"
source .venv/bin/activate
python -m uvicorn app:app --host 127.0.0.1 --port 8765
```

Open http://127.0.0.1:8765 and press Command+Shift+R. Do not run setup.py again. If your existing application is in a different folder, extract over that folder instead. Schema changes are additive. Existing prices, images and edits are preserved.

Use the top colour selector. Settings can save the default palette. In POS select Customer bill, Kitchen slip or Both before confirming. Both slips flow together with a cut separator in one system print dialog; use your printer's proper 58mm/80mm paper settings. Hardware printing cannot be verified remotely.

Use Orders to mark ready, mark delivered or cancel with a reason. Cancellation records a refund review; it does not refund a payment automatically. Customers stores contacts and opt-in choices without sending messages. Finance accepts From and To dates for the screen and PDF.

Select White / Sky Blue in the top colour selector. Both slips now print together with a cut separator. Receipt Studio has its own explicit print selection. For long orders select All pages in the printer dialog.

The dashboard has been redesigned. The completed, pending and cancelled cards describe orders created today, using Pakistan time. Ready for handoff includes all open dates. Desktop products scroll in their own panel; checkout settings stay visible. For duplicates, click the copy icon and then edit the newly added dish.
