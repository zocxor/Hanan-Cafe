# Changelog 0.5.9 — critical fix: missing stylesheets were never served

## Root cause (found by reproducing the app in a real browser)

- The `/static/{file}` route in `app.py` serves files through a hard-coded
  allowlist. `dashboard-3d.css`, `dashboard-3d.js` and `float-ui.css` were
  never added to it, so the server answered **404** for all three.
- Consequence: the 5-column metric grid, clay/3D dashboard styling and the
  floating UI never loaded — the dashboard silently fell back to the older
  4-column stylesheet, which is exactly why the 5th card wrapped to a second
  row (4+1) in every version since v0.5.4.
- Fixed by adding the three files to the allowlist. Verified in headless
  Chromium: 5 columns, 5 cards, 1 row.

## Regression test

- `tests/test_smoke.py` now fetches every `/static/*` URL referenced by
  `index.html` and asserts HTTP 200 (15 assets). This would have caught the
  bug immediately.

## Upgrade notes

- Replace `app.py` AND the `static/` folder; keep your data directory.
- Static asset versions bumped to `?v=059`; hard-refresh once (Cmd+Shift+R).
