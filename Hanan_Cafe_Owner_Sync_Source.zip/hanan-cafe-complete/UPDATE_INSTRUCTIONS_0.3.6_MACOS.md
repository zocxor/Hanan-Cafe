# Install Hanan Cafe v0.3.6 on macOS

1. Back up the database from the Backup page.
2. Stop the server with Ctrl+C.
3. Extract the ZIP.
4. Copy `app.py`, `static/app.js`, and `static/style.css` into your original `~/Downloads/Hanan_Cafe/hanan-cafe-complete` folder.
5. Restart using `.venv315` and Uvicorn.

At POS, choose Customer bill, Kitchen slip, Both, or Do not print now before confirming. Allow pop-ups for localhost. Chrome will still show its print dialog; select the actual thermal printer and paper size.
