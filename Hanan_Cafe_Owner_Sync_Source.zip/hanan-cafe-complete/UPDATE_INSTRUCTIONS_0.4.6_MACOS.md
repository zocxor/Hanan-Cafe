# Update to 0.4.6 on macOS

Generate a backup first. Stop the server with Control+C and extract over your existing application folder. Do not delete the data folder or run setup again.

```bash
unzip -o "$HOME/Downloads/Hanan_Cafe_v0.4.6_Green_Print_Update.zip" -d "$HOME/Downloads/Hanan_Cafe_v040"
cd "$HOME/Downloads/Hanan_Cafe_v040/hanan-cafe-complete"
source .venv/bin/activate
python -m uvicorn app:app --host 127.0.0.1 --port 8765
```

Open http://127.0.0.1:8765 and press Command+Shift+R. If your current application is in another folder, update that folder instead.

Select Navy / AI Green to see the new green navigation and cards. All other themes remain.

Settings → Customer & kitchen separation → Separate slips is the new default. Select Both slips when printing. Both tickets start on their own pages, using one print dialog. Select All pages. On a cutter-equipped printer, configure cut after each page in its driver. Actual cutter controls depend on the printer model; this application does not issue cutter commands or confirm paper output. A printer without a cutter cannot cut automatically.

Continuous roll is still available in Settings if you prefer a single length with a dashed manual cut line. Long tickets can span more pages in either mode; choose a suitable paper size in the driver. Exact print/cut configuration requires your printer model.

Owners and managers can remove individual contacts with the trash icon in Customers. Confirm the selected contact; historical orders remain. Cafe settings and My profile are compact, side-by-side desktop cards.
