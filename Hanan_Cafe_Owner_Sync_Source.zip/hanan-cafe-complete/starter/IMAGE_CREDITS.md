# Transparent starter assets — v0.4.2

24 distinct AI-generated illustrative food cutouts made with the built-in imagegen tool and optimized to local alpha WebP. These are not photographs of actual Hanan Cafe servings.

The Classic Zinger cutout uses the previously bundled Pexels image as a reference: https://www.pexels.com/photo/19737927/ — Pexels License https://www.pexels.com/license/. All other cutouts were generated from the named dish and its description.

Original stock-photo source/licence records remain in catalogue-v040-source-records.json; original source files remain in source-photos. New product assets live in images. No third-party image host is needed at runtime.

Prompt set: one individual, realistic food product photo for each catalogue name and description; transparent alpha background, entire food visible, natural texture, no text, labels, scene or hands. Drinks use a single unbranded glass; pizzas show a complete round pizza; sides may include a plain serving dish. The Zinger prompt requested background extraction preserving the referenced burger.
