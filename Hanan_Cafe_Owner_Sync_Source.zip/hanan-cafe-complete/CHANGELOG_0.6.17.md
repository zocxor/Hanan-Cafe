# Changelog 0.6.17 — futuristic order-status card

## Dashboard: Order status goes neon

- Glowing segmented ring with a slow rotating radar sheen.
- Gradient center number, glowing orbit around the core.
- Pulsing LIVE indicator in the card header.
- Legend rebuilt as telemetry bars showing each status share.

Same data, same donut proportions — pure visual upgrade, both schemes.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=0617`; hard-refresh once (Cmd+Shift+R).
