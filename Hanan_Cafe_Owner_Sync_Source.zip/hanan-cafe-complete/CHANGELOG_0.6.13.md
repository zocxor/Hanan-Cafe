# Changelog 0.6.13 — income statement on Finance page

## Finance page: two parts

- Part 1 (unchanged): the four summary cards with short details.
- Part 2 (new): a complete Income Statement section right below the cards —
  Revenue (recorded sales + order count), Total revenue, Less: expenses
  (recorded expenses + entry count), Total expenses, and Net income
  (sales less expenses, shown red when negative). Normal table typography,
  no oversized numbers.

All figures come from the same period data as the cards. Payment-method
tables, PDF export and the disclaimer below are untouched.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=0613`; hard-refresh once (Cmd+Shift+R).
