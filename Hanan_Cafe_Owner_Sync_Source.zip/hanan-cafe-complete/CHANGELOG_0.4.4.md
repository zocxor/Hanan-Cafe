# 0.4.4 — White / Sky Blue and combined slips

Adds a third selectable White / Sky Blue theme with dark navy text and visible input/table borders. Owner/manager default theme persists in settings; each browser retains its selection.

Both slips now flow together with a dashed cut separator rather than a forced page break. A short order fits both on one printer page; long orders can naturally span pages. One system print action, no new browser tab. Receipt Studio also has an explicit Customer bill + kitchen slip / customer only / kitchen only selector, defaulting to both. Template remains separate from print selection.

Browser checks cover all three themes at five screen sizes, both slip contents, one print invocation and zero popups. Reprint checks cover 58mm and 80mm. Hardware paper output remains unverified. Use All pages in the system print dialog for long orders.
