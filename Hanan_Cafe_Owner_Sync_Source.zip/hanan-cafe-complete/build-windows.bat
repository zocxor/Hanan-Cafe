@echo off
cd /d "%~dp0"
py -m venv .build-env
call .build-env\Scripts\activate
python -m pip install -r requirements.txt pyinstaller
if errorlevel 1 exit /b 1
python -m PyInstaller --noconfirm --onedir --name HananCafe --add-data "static;static" --add-data "starter;starter" --hidden-import app --hidden-import services --hidden-import enhancements --hidden-import remote_sync desktop_launcher.py
if errorlevel 1 exit /b 1
echo Build ready: dist\HananCafe\HananCafe.exe
