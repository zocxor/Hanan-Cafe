# Changelog 0.6.1 — glass + motion verified on every page

## Audit

- Probed Dashboard, POS, Orders, Kitchen, Menu, Reports, Expenses, Settings
  and Backup in headless Chromium. Glass panels, table glass, button physics
  and card lift were already live everywhere via the theme-agnostic
  `float-ui.css` (v0.6.0).

## Fix

- The entrance animation only targeted `#page > .clay/.tablewrap/.grid2`,
  so pages with custom wrappers (POS `.pos-layout`, Menu `.studio-hero`,
  etc.) got no entrance motion. It now applies to `#page > *` with a
  gentle stagger on every page, verified: `float-in` fires on all 7 probed
  sections. Still honours `prefers-reduced-motion`.

## Upgrade notes

- Replace the `static/` folder only; keep your data directory.
- Static asset versions bumped to `?v=061`; hard-refresh once (Cmd+Shift+R).
