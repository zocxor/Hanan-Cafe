"""Single-cafe relay. Run behind an HTTPS reverse proxy; bind localhost only."""
import os,json,secrets,sqlite3,threading
from pathlib import Path
from datetime import datetime,timezone
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
DB=Path(os.environ.get('RELAY_DB','relay.sqlite3'))
WRITE=os.environ.get('HANAN_SYNC_WRITE_TOKEN','')
READ=os.environ.get('HANAN_OWNER_READ_TOKEN','')
LOCK=threading.Lock()
def initialize():
    if min(len(WRITE),len(READ))<32 or WRITE==READ:raise RuntimeError('Set two different random tokens of at least 32 characters')
    with sqlite3.connect(DB) as c:c.execute('CREATE TABLE IF NOT EXISTS snapshot(id INTEGER PRIMARY KEY CHECK(id=1),body TEXT NOT NULL)')
class Handler(BaseHTTPRequestHandler):
    def reply(self,status,body,kind='application/json'):
        self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(body)
    def authorized(self,token):return secrets.compare_digest(self.headers.get('Authorization',''),'Bearer '+token)
    def do_GET(self):
        if self.path=='/':return self.reply(200,Path(__file__).with_name('owner.html').read_bytes(),'text/html; charset=utf-8')
        if self.path!='/api/snapshot':return self.reply(404,b'{}')
        if not self.authorized(READ):return self.reply(401,b'{"error":"Unauthorized"}')
        with sqlite3.connect(DB) as c:row=c.execute('SELECT body FROM snapshot WHERE id=1').fetchone()
        return self.reply(200,row[0].encode() if row else b'{"records":{},"received_at":null}')
    def do_PUT(self):
        if self.path!='/api/snapshot':return self.reply(404,b'{}')
        if not self.authorized(WRITE):return self.reply(401,b'{}')
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=50*1024*1024:return self.reply(413,b'{}')
            data=json.loads(self.rfile.read(size))
            if not isinstance(data.get('records'),dict) or not isinstance(data.get('captured_at'),str):raise ValueError()
            allowed={'settings','categories','products','product_variants','customers','orders','order_items','order_events','inventory_movements','expenses','audit','order_cancellations','kitchen_tasks'}
            if set(data['records'])-allowed or any(not isinstance(v,list) for v in data['records'].values()):raise ValueError()
            data['received_at']=datetime.now(timezone.utc).isoformat()
            with LOCK,sqlite3.connect(DB) as c:c.execute('INSERT OR REPLACE INTO snapshot VALUES(1,?)',(json.dumps(data),))
            return self.reply(200,b'{"ok":true}')
        except (ValueError,TypeError,KeyError):return self.reply(400,b'{}')
    def log_message(self,*args):pass
if __name__=='__main__':
    initialize();ThreadingHTTPServer(('127.0.0.1',8780),Handler).serve_forever()
