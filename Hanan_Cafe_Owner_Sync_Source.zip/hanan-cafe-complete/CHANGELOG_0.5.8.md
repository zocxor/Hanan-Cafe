# Changelog 0.5.8 — brand fit + full cache-bust

## Brand

- Sidebar brand reduced further (26px / 4px spacing) so "HANAN" always fits
  fully inside the sidebar on every screen width.

## Notes

- All dashboard card layouts were already single-row 5-column since v0.5.4;
  if cards still wrap 4+1 the browser or the app folder is serving a stale
  stylesheet. This build bumps every asset to `?v=058` to force fresh loads.
- After updating: replace the whole `static/` folder in the SAME directory
  you run uvicorn from, restart uvicorn, then hard-refresh (Cmd+Shift+R).
- To verify what the running server actually serves:
  curl -s http://127.0.0.1:8000/static/dashboard-3d.css | grep -o "repeat([0-9]" | head -1
  It must print `repeat(5`. If it prints `repeat(4`, the app is running from
  an old folder — check `pwd` before starting uvicorn.

## Upgrade notes

- Replace the `static/` folder; keep your data directory.
- Static asset versions bumped to `?v=058`; hard-refresh once (Cmd+Shift+R).
