@echo off
REM Builds dist\HananCafe\HananCafe.exe (+ dist\HananCafe-Windows.zip). Run on Windows with Python 3.12.
cd /d "%~dp0"
where py >nul 2>nul && (set PYCMD=py -3.12) || (set PYCMD=python)
if not exist .buildvenv (%PYCMD% -m venv .buildvenv || goto :fail)
call .buildvenv\Scripts\activate || goto :fail
python -m pip install --upgrade pip || goto :fail
pip install -r requirements.txt pyinstaller || goto :fail
pyinstaller --noconfirm --clean --windowed --name HananCafe ^
  --collect-submodules uvicorn --collect-submodules anyio --collect-data reportlab ^
  --add-data "static;static" --add-data "starter;starter" launcher.py || goto :fail
powershell -NoProfile -Command "Compress-Archive -Path dist\HananCafe -DestinationPath dist\HananCafe-Windows.zip -Force" || goto :fail
echo.
echo DONE: dist\HananCafe\HananCafe.exe   and   dist\HananCafe-Windows.zip
exit /b 0
:fail
echo BUILD FAILED
exit /b 1
