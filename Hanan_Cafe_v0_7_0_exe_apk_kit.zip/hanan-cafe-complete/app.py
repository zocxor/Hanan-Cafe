"""Hanan Cafe local-first operating system. Run behind trusted localhost/LAN only."""
import os, sqlite3, json, hmac, hashlib, secrets, uuid, shutil, zipfile, io, base64, re
from datetime import datetime, timezone, timedelta
from pathlib import Path
from contextlib import contextmanager
from fastapi import FastAPI, Request, HTTPException, Response
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel

BASE = Path(__file__).resolve().parent
# Keep legacy installations in place; new installations use durable user data.
_default_data = BASE/'data' if (BASE/'data'/'hanan.sqlite3').exists() else Path.home()/'.hanan-cafe'
DATA = Path(os.environ.get('HANAN_DATA_DIR', str(_default_data))).expanduser().resolve()
DATA.mkdir(parents=True,exist_ok=True)
MEDIA = DATA/'media'
MEDIA.mkdir(parents=True,exist_ok=True)
DB = DATA/'hanan.sqlite3'
NEW_DATABASE = not DB.exists()
COOKIE = 'hanan_session'
app=FastAPI(title='Hanan Cafe Local POS',docs_url=None,redoc_url=None)

def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def connect():
    c=sqlite3.connect(DB,timeout=20)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA busy_timeout=20000')
    return c

@contextmanager
def tx():
    c=connect()
    try:
        c.execute('BEGIN IMMEDIATE')
        yield c
        c.commit()
    except:
        c.rollback();raise
    finally:c.close()

def init():
    with tx() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, salt TEXT NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('owner','manager','cashier','kitchen')), active INTEGER NOT NULL DEFAULT 1, image_path TEXT, permissions TEXT NOT NULL DEFAULT '[]');
        CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),expires_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS categories(id TEXT PRIMARY KEY,name TEXT NOT NULL UNIQUE,active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,name TEXT NOT NULL,category_id TEXT REFERENCES categories(id),price_paisa INTEGER NOT NULL CHECK(price_paisa>=0),active INTEGER NOT NULL DEFAULT 1,stock_tracking INTEGER NOT NULL DEFAULT 0,stock_qty INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,image_path TEXT);
        CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,order_no INTEGER UNIQUE NOT NULL,order_type TEXT NOT NULL CHECK(order_type IN ('COUNTER','PARCEL','DELIVERY')),status TEXT NOT NULL,payment_status TEXT NOT NULL,payment_method TEXT,customer TEXT,phone TEXT,address TEXT,notes TEXT,cashier_id TEXT REFERENCES users(id),subtotal INTEGER NOT NULL,discount INTEGER NOT NULL,tax INTEGER NOT NULL,delivery_fee INTEGER NOT NULL,grand_total INTEGER NOT NULL,amount_paid INTEGER NOT NULL,created_at TEXT NOT NULL,service_charge INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS order_items(id TEXT PRIMARY KEY,order_id TEXT NOT NULL REFERENCES orders(id),product_id TEXT REFERENCES products(id),name TEXT NOT NULL,qty INTEGER NOT NULL CHECK(qty>0),unit_price INTEGER NOT NULL,line_total INTEGER NOT NULL,notes TEXT);
        CREATE TABLE IF NOT EXISTS order_events(id TEXT PRIMARY KEY,order_id TEXT NOT NULL REFERENCES orders(id),status TEXT NOT NULL,actor TEXT,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS inventory_movements(id TEXT PRIMARY KEY,product_id TEXT NOT NULL REFERENCES products(id),delta INTEGER NOT NULL,reason TEXT NOT NULL,order_id TEXT REFERENCES orders(id),actor TEXT,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS expenses(id TEXT PRIMARY KEY,category TEXT NOT NULL,description TEXT,amount INTEGER NOT NULL CHECK(amount>0),created_at TEXT NOT NULL,actor TEXT,payment_method TEXT NOT NULL DEFAULT 'CASH');
        CREATE TABLE IF NOT EXISTS print_jobs(id TEXT PRIMARY KEY,order_id TEXT NOT NULL REFERENCES orders(id),template TEXT NOT NULL,width INTEGER NOT NULL,status TEXT NOT NULL,copies INTEGER NOT NULL DEFAULT 1,requested_by TEXT NOT NULL,created_at TEXT NOT NULL,last_error TEXT);
        CREATE TABLE IF NOT EXISTS audit(id TEXT PRIMARY KEY,actor TEXT,event TEXT NOT NULL,details TEXT NOT NULL,created_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at);
        CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
        CREATE INDEX IF NOT EXISTS idx_print_jobs_status ON print_jobs(status);
        ''')
        defaults={'cafe_name':'HANAN CAFE','address':'','phone':'','tax_registration':'','footer':'Thank you for visiting!','return_policy':'','powered_by':'false','ui_theme':'orange','receipt_separation':'pages','paper_width':'80','receipt_template':'standard','tax_rate_bp':'0','currency':'PKR','cloud_project_id':'hanans-cafe','cloud_project_number':'271178654673'}
        for k,v in defaults.items(): c.execute('INSERT OR IGNORE INTO settings(key,value) VALUES (?,?)',(k,v))
        # Safe additive migrations preserve existing cafe records.
        user_cols={r['name'] for r in c.execute('PRAGMA table_info(users)')}
        if 'image_path' not in user_cols: c.execute('ALTER TABLE users ADD COLUMN image_path TEXT')
        if 'permissions' not in user_cols: c.execute("ALTER TABLE users ADD COLUMN permissions TEXT NOT NULL DEFAULT '[]'")
        order_cols={r['name'] for r in c.execute('PRAGMA table_info(orders)')}
        if 'service_charge' not in order_cols: c.execute('ALTER TABLE orders ADD COLUMN service_charge INTEGER NOT NULL DEFAULT 0')
        product_cols={r['name'] for r in c.execute('PRAGMA table_info(products)')}
        if 'image_path' not in product_cols: c.execute('ALTER TABLE products ADD COLUMN image_path TEXT')
        for field, definition in [('description', "TEXT NOT NULL DEFAULT ''"), ('starter_key', 'TEXT')]:
            if field not in product_cols: c.execute('ALTER TABLE products ADD COLUMN '+field+' '+definition)
        c.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_starter_key ON products(starter_key) WHERE starter_key IS NOT NULL')
        c.execute('CREATE TABLE IF NOT EXISTS product_variants(id TEXT PRIMARY KEY,product_id TEXT NOT NULL REFERENCES products(id),label TEXT NOT NULL,price_paisa INTEGER NOT NULL CHECK(price_paisa>=0),active INTEGER NOT NULL DEFAULT 1,UNIQUE(product_id,label))')
        c.execute("CREATE TABLE IF NOT EXISTS customers(id TEXT PRIMARY KEY,name TEXT NOT NULL,phone TEXT NOT NULL,phone_key TEXT NOT NULL UNIQUE,email TEXT NOT NULL DEFAULT '',address TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '',marketing_opt_in INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,last_order_at TEXT)")
        c.execute('CREATE TABLE IF NOT EXISTS order_cancellations(order_id TEXT PRIMARY KEY REFERENCES orders(id),reason TEXT NOT NULL,actor TEXT NOT NULL,created_at TEXT NOT NULL,stock_returned INTEGER NOT NULL DEFAULT 0,refund_review_paisa INTEGER NOT NULL DEFAULT 0)')
        if 'is_deleted' not in {col['name'] for col in c.execute('PRAGMA table_info(products)')}:c.execute('ALTER TABLE products ADD COLUMN is_deleted INTEGER NOT NULL DEFAULT 0')
        c.execute('CREATE TABLE IF NOT EXISTS product_images(id TEXT PRIMARY KEY,product_id TEXT NOT NULL REFERENCES products(id),image_path TEXT NOT NULL,created_at TEXT NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS starter_registry(key TEXT PRIMARY KEY,product_id TEXT)')
        c.execute('CREATE TABLE IF NOT EXISTS kitchen_tasks(item_id TEXT PRIMARY KEY REFERENCES order_items(id),done INTEGER NOT NULL DEFAULT 0,actor TEXT,updated_at TEXT)')
        if 'sort_order' not in {r['name'] for r in c.execute('PRAGMA table_info(categories)')}:c.execute('ALTER TABLE categories ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0')
        expense_cols={r['name'] for r in c.execute('PRAGMA table_info(expenses)')}
        if 'payment_method' not in expense_cols: c.execute("ALTER TABLE expenses ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'CASH'")
init()

# Local recovery snapshot on startup. This never contacts the internet and does not
# replace the user's normal backup/export. Keep a rolling set of 14 snapshots.
def startup_snapshot():
    try:
        folder=DATA/'recovery_snapshots';folder.mkdir(parents=True,exist_ok=True)
        stamp=datetime.now().strftime('%Y%m%d-%H%M%S')
        target=folder/f'hanan-{stamp}.sqlite3'
        src=connect();dst=sqlite3.connect(target)
        try:src.backup(dst)
        finally:dst.close();src.close()
        files=sorted(folder.glob('hanan-*.sqlite3'),key=lambda x:x.stat().st_mtime,reverse=True)
        for old in files[14:]:old.unlink(missing_ok=True)
    except Exception:
        # Startup must remain available even if snapshot storage is unavailable.
        pass
startup_snapshot()

def audit(c,user,event,details):c.execute('INSERT INTO audit VALUES (?,?,?,?,?)',(str(uuid.uuid4()),user,event,json.dumps(details,ensure_ascii=False),now()))
def getsettings(c):return {r['key']:r['value'] for r in c.execute('SELECT * FROM settings')}
def rows(q,params=()):
    with connect() as c:return [dict(r) for r in c.execute(q,params)]
def password_hash(password,salt):return hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=16384,r=8,p=1).hex()
def create_owner(username,password):
    if len(password)<12:raise ValueError('Owner password must have at least 12 characters')
    with tx() as c:
        if c.execute('SELECT COUNT(*) FROM users').fetchone()[0]:raise ValueError('Users already initialized')
        salt=secrets.token_hex(16)
        c.execute("INSERT INTO users(id,username,salt,password_hash,role,active,image_path,permissions) VALUES(?,?,?,?,?,1,NULL,'[]')",(str(uuid.uuid4()),username,salt,password_hash(password,salt),'owner'))

async def payload(request):
    try:return await request.json()
    except:raise HTTPException(400,'Invalid JSON')
def auth(request,roles=None):
    token=request.cookies.get(COOKIE,'')
    if not token:raise HTTPException(401,'Login required')
    digest=hashlib.sha256(token.encode()).hexdigest()
    with connect() as c:
        user=c.execute('SELECT u.id,u.username,u.role,u.image_path,u.permissions FROM sessions s JOIN users u ON s.user_id=u.id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1',(digest,now())).fetchone()
    if not user:raise HTTPException(401,'Session expired')
    user=dict(user)
    try: user['permissions']=json.loads(user.get('permissions') or '[]')
    except Exception: user['permissions']=[]
    if roles and user['role'] not in roles:raise HTTPException(403,'Insufficient permission')
    if user['role']!='owner':
        route=request.url.path
        section=None
        if route.startswith('/api/orders') or route.startswith('/api/print-jobs'): section=('POS' if request.method=='POST' and route=='/api/orders' else ('Receipts' if route.startswith('/api/print-jobs') else 'Orders'))
        elif route.startswith('/api/products') or route.startswith('/api/categories') or route.startswith('/api/stock'): section=('POS' if request.method=='GET' else 'Menu')
        elif route.startswith('/api/dashboard'): section='Dashboard'
        elif route.startswith('/api/customers'): section='Customers'
        elif route.startswith('/api/expenses'): section='Expenses'
        elif route.startswith('/api/finance'): section='Finance'
        elif route.startswith('/api/report'): section='Reports'
        elif route.startswith('/api/settings') and request.method not in ('GET','HEAD'): section='Settings'
        elif route.startswith('/api/backup'): section='Backup'
        if section:
            perms=user.get('permissions') or []
            defaults={'manager':['Dashboard','POS','Orders','Kitchen','Menu','Reports','Receipts','Expenses','Settings','Backup','Customers'],'cashier':['Dashboard','POS','Orders','Receipts','Customers'],'kitchen':['Dashboard','Kitchen','Orders']}
            effective=perms if perms else defaults.get(user['role'],[])
            if section not in effective and not (request.method=='GET' and ((section=='Orders' and 'POS' in effective) or (section=='POS' and 'Menu' in effective))): raise HTTPException(403,'This account does not have permission for '+section)
    # localhost-only and SameSite cookies guard against common CSRF routes in this local edition
    if request.method not in ('GET','HEAD'):
        origin=request.headers.get('origin')
        if origin and __import__('urllib.parse',fromlist=['urlparse']).urlparse(origin).netloc!=request.url.netloc:raise HTTPException(403,'Origin rejected')
    return user

@app.get('/')
def home():return FileResponse(BASE/'static/index.html')
@app.get('/static/{file:path}')
def static(file:str):
    if file not in {'app.js','upgrade.js','style.css','refinement.js','refinement.css','premium.js','premium.css','pizza.js','vendor/lucide.js','vendor/motion.js','service.js','themes.css','dashboard-3d.css','dashboard-3d.js','float-ui.css','assets/ztechx-logo.png'}:raise HTTPException(404)
    return FileResponse(BASE/'static'/file)
@app.get('/api/ready')
def ready():
    with connect() as c:return {'initialized':bool(c.execute('SELECT COUNT(*) FROM users').fetchone()[0]),'version':'0.4.7'}
@app.post('/api/login')
async def login(request:Request,response:Response):
    p=await payload(request)
    with tx() as c:
        r=c.execute('SELECT * FROM users WHERE username=? AND active=1',(str(p.get('username','')),)).fetchone()
        if not r or not hmac.compare_digest(password_hash(str(p.get('password','')),r['salt']),r['password_hash']):raise HTTPException(401,'Invalid login')
        token=secrets.token_urlsafe(40)
        c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),r['id'],(datetime.now(timezone.utc)+timedelta(hours=12)).isoformat()))
        audit(c,r['id'],'login',{})
    response.set_cookie(COOKIE,token,httponly=True,samesite='strict',secure=os.environ.get('HANAN_SECURE_COOKIE')=='1',max_age=43200,path='/')
    return {'username':r['username'],'role':r['role']}
@app.post('/api/logout')
def logout(request:Request,response:Response):
    token=request.cookies.get(COOKIE,'')
    with tx() as c:c.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),))
    response.delete_cookie(COOKIE)
    return {'ok':True}
@app.get('/api/me')
def me(request:Request):return auth(request)
@app.get('/api/users')
def list_users(request:Request):
    auth(request,['owner'])
    out=rows("SELECT id,username,role,active,image_path,permissions FROM users ORDER BY CASE role WHEN 'owner' THEN 0 ELSE 1 END,username")
    for x in out:
        try:x['permissions']=json.loads(x.get('permissions') or '[]')
        except Exception:x['permissions']=[]
    return out

@app.post('/api/users')
async def create_user(request:Request):
    u=auth(request,['owner']); p=await payload(request)
    username=str(p.get('username','')).strip()[:60]; password=str(p.get('password','')); role=p.get('role','cashier')
    allowed_roles={'manager','cashier','kitchen'}
    if not re.fullmatch(r'[A-Za-z0-9_.-]{3,60}',username): raise HTTPException(400,'Username must be 3–60 characters using letters, numbers, dot, dash or underscore')
    if len(password)<8: raise HTTPException(400,'Password must contain at least 8 characters')
    if role not in allowed_roles: raise HTTPException(400,'Choose manager, cashier or kitchen')
    perms=p.get('permissions') or []
    valid={'Dashboard','POS','Orders','Kitchen','Menu','Reports','Receipts','Expenses','Finance','Settings','Backup','Customers'}
    if not isinstance(perms,list) or any(x not in valid for x in perms): raise HTTPException(400,'Invalid permissions')
    with tx() as c:
        if c.execute("SELECT COUNT(*) FROM users WHERE role!='owner'").fetchone()[0]>=15: raise HTTPException(400,'Maximum of 15 staff accounts reached')
        salt=secrets.token_hex(16)
        try:c.execute('INSERT INTO users(id,username,salt,password_hash,role,active,image_path,permissions) VALUES(?,?,?,?,?,1,NULL,?)',(str(uuid.uuid4()),username,salt,password_hash(password,salt),role,json.dumps(perms)))
        except sqlite3.IntegrityError: raise HTTPException(409,'Username already exists')
        audit(c,u['id'],'user_created',{'username':username,'role':role,'permissions':perms})
    return {'ok':True}

@app.patch('/api/users/{uid}')
async def update_user(uid:str,request:Request):
    u=auth(request,['owner']); p=await payload(request)
    with tx() as c:
        target=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
        if not target: raise HTTPException(404,'User not found')
        if target['role']=='owner': raise HTTPException(400,'Use My Profile to change owner credentials')
        fields=[]; values=[]
        if 'username' in p:
            username=str(p['username']).strip()[:60]
            if not re.fullmatch(r'[A-Za-z0-9_.-]{3,60}',username): raise HTTPException(400,'Invalid username')
            fields.append('username=?');values.append(username)
        if 'role' in p:
            if p['role'] not in {'manager','cashier','kitchen'}: raise HTTPException(400,'Invalid role')
            fields.append('role=?');values.append(p['role'])
        if 'active' in p: fields.append('active=?');values.append(int(bool(p['active'])))
        if 'permissions' in p:
            valid={'Dashboard','POS','Orders','Kitchen','Menu','Reports','Receipts','Expenses','Finance','Settings','Backup','Customers'}
            if not isinstance(p['permissions'],list) or any(x not in valid for x in p['permissions']): raise HTTPException(400,'Invalid permissions')
            fields.append('permissions=?');values.append(json.dumps(p['permissions']))
        if p.get('password'):
            if len(str(p['password']))<8: raise HTTPException(400,'Password must contain at least 8 characters')
            salt=secrets.token_hex(16);fields.extend(['salt=?','password_hash=?']);values.extend([salt,password_hash(str(p['password']),salt)])
        if fields:
            values.append(uid)
            try:c.execute('UPDATE users SET '+','.join(fields)+' WHERE id=?',values)
            except sqlite3.IntegrityError: raise HTTPException(409,'Username already exists')
            audit(c,u['id'],'user_updated',{'user_id':uid,'fields':list(p.keys())})
    return {'ok':True}

@app.patch('/api/profile')
async def update_profile(request:Request):
    u=auth(request,['owner']);p=await payload(request)
    with tx() as c:
        target=c.execute('SELECT * FROM users WHERE id=?',(u['id'],)).fetchone()
        fields=[];values=[]
        if 'username' in p:
            username=str(p['username']).strip()[:60]
            if not re.fullmatch(r'[A-Za-z0-9_.-]{3,60}',username): raise HTTPException(400,'Invalid username')
            fields.append('username=?');values.append(username)
        if p.get('password'):
            if len(str(p['password']))<12: raise HTTPException(400,'Owner password must contain at least 12 characters')
            salt=secrets.token_hex(16);fields.extend(['salt=?','password_hash=?']);values.extend([salt,password_hash(str(p['password']),salt)])
        if fields:
            values.append(u['id'])
            try:c.execute('UPDATE users SET '+','.join(fields)+' WHERE id=?',values)
            except sqlite3.IntegrityError: raise HTTPException(409,'Username already exists')
            audit(c,u['id'],'owner_profile_updated',{'fields':list(p.keys())})
    return {'ok':True}

@app.post('/api/profile/photo')
async def profile_photo(request:Request):
    u=auth(request,['owner']);p=await payload(request);data=str(p.get('data_url',''))
    m=re.fullmatch(r'data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)',data)
    if not m: raise HTTPException(400,'Use a PNG, JPG or WebP image')
    raw=base64.b64decode(m.group(2),validate=True)
    if len(raw)>3*1024*1024: raise HTTPException(400,'Image must be under 3 MB')
    ext={'jpeg':'jpg','png':'png','webp':'webp'}[m.group(1)];name=uuid.uuid4().hex+'.'+ext;(MEDIA/name).write_bytes(raw)
    with tx() as c:c.execute('UPDATE users SET image_path=? WHERE id=?',(name,u['id']))
    return {'ok':True,'image_path':name}

@app.post('/api/users/{uid}/photo')
async def user_photo(uid:str,request:Request):
    u=auth(request,['owner']);p=await payload(request);data=str(p.get('data_url',''))
    m=re.fullmatch(r'data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)',data)
    if not m: raise HTTPException(400,'Use a PNG, JPG or WebP image')
    raw=base64.b64decode(m.group(2),validate=True)
    if len(raw)>3*1024*1024: raise HTTPException(400,'Image must be under 3 MB')
    ext={'jpeg':'jpg','png':'png','webp':'webp'}[m.group(1)];name=uuid.uuid4().hex+'.'+ext;(MEDIA/name).write_bytes(raw)
    with tx() as c:
        if not c.execute('SELECT 1 FROM users WHERE id=?',(uid,)).fetchone(): raise HTTPException(404,'User not found')
        c.execute('UPDATE users SET image_path=? WHERE id=?',(name,uid))
    return {'ok':True}

@app.get('/api/settings')
def settings(request:Request):
    auth(request)
    with connect() as c:return getsettings(c)
@app.patch('/api/settings')
async def update_settings(request:Request):
    user=auth(request,['owner','manager']);p=await payload(request)
    allowed={'cafe_name','address','phone','tax_registration','footer','return_policy','powered_by','paper_width','receipt_template','tax_rate_bp','ui_theme','receipt_separation'}
    if not isinstance(p,dict) or any(k not in allowed for k in p):raise HTTPException(400,'Unknown setting')
    if 'receipt_separation' in p and p['receipt_separation'] not in ('pages','continuous'):raise HTTPException(400,'Invalid receipt separation')
    if 'ui_theme' in p and p['ui_theme'] not in ('orange','sky'):raise HTTPException(400,'Invalid colour scheme')
    if 'tax_rate_bp' in p and not 0<=int(p['tax_rate_bp'])<=10000:raise HTTPException(400,'Invalid tax basis points')
    if 'paper_width' in p and str(p['paper_width']) not in ('58','80'):raise HTTPException(400,'Invalid paper width')
    with tx() as c:
        for k,v in p.items():c.execute('INSERT INTO settings VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(k,str(v)[:500]))
        audit(c,user['id'],'settings_changed',{'keys':list(p)})
    return {'ok':True}
@app.get('/api/categories')
def categories(request:Request):auth(request);return rows('SELECT * FROM categories WHERE active=1 ORDER BY sort_order,name')
@app.post('/api/categories')
async def add_category(request:Request):
    u=auth(request,['owner','manager']);p=await payload(request)
    name=str(p.get('name','')).strip()[:80]
    if not name:raise HTTPException(400,'Name required')
    with tx() as c:
        c.execute('INSERT INTO categories(id,name) VALUES (?,?)',(str(uuid.uuid4()),name));audit(c,u['id'],'category_created',{'name':name})
    return {'ok':True}
@app.patch('/api/categories/{cid}')
async def edit_category(cid:str,request:Request):
    u=auth(request,['owner','manager']);p=await payload(request)
    name=str(p.get('name','')).strip()[:80]
    if not name:raise HTTPException(400,'Category name required')
    with tx() as c:
        if not c.execute('SELECT 1 FROM categories WHERE id=? AND active=1',(cid,)).fetchone():raise HTTPException(404,'Category not found')
        try:c.execute('UPDATE categories SET name=? WHERE id=?',(name,cid))
        except sqlite3.IntegrityError:raise HTTPException(409,'A category with this name already exists')
        audit(c,u['id'],'category_renamed',{'category_id':cid,'name':name})
    return {'ok':True}
@app.delete('/api/categories/{cid}')
def archive_category(cid:str,request:Request):
    u=auth(request,['owner','manager'])
    with tx() as c:
        r=c.execute('SELECT name FROM categories WHERE id=? AND active=1',(cid,)).fetchone()
        if not r:raise HTTPException(404,'Category not found')
        # Preserve historical product/category references; archive instead of hard-delete.
        c.execute('UPDATE categories SET active=0 WHERE id=?',(cid,))
        audit(c,u['id'],'category_archived',{'category_id':cid,'name':r['name']})
    return {'ok':True}
def ensure_pizza_sizes(c):
    c.execute('CREATE TABLE IF NOT EXISTS product_variants(id TEXT PRIMARY KEY,product_id TEXT NOT NULL REFERENCES products(id),label TEXT NOT NULL,price_paisa INTEGER NOT NULL CHECK(price_paisa>=0),active INTEGER NOT NULL DEFAULT 1,UNIQUE(product_id,label))')
    pizzas=c.execute("SELECT p.id,p.price_paisa FROM products p JOIN categories cat ON cat.id=p.category_id WHERE lower(trim(cat.name)) IN ('pizza','pizzas')").fetchall()
    for pizza in pizzas:
        for label in ('Small','Medium','Large','XL'):
            vid=uuid.uuid5(uuid.NAMESPACE_URL,'hanan-size:'+pizza['id']+':'+label).hex
            c.execute('INSERT OR IGNORE INTO product_variants VALUES(?,?,?,?,1)',(vid,pizza['id'],label,pizza['price_paisa']))

@app.post('/api/products/{pid}/duplicate')
async def duplicate_product(pid:str,request:Request):
    u=auth(request,['owner','manager']);body=await payload(request);name=str(body.get('name','')).strip()
    if body.get('auto_name') is not True and (not name or len(name)>120):raise HTTPException(400,'Enter a different name, up to 120 characters')
    with tx() as c:
        ensure_pizza_sizes(c)
        product=c.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
        if not product:raise HTTPException(404,'Dish not found')
        if body.get('auto_name') is True:
            base=product['name'][:100];name=base+' — copy';suffix=2
            while c.execute('SELECT 1 FROM products WHERE lower(trim(name))=lower(?)',(name,)).fetchone():
                name=base+' — copy '+str(suffix);suffix+=1
        if c.execute('SELECT 1 FROM products WHERE lower(trim(name))=lower(?)',(name,)).fetchone():raise HTTPException(400,'Choose a different, unused dish name')
        new_id=uuid.uuid4().hex
        c.execute('INSERT INTO products(id,name,category_id,price_paisa,active,stock_tracking,stock_qty,created_at,image_path,description) VALUES(?,?,?,?,?,0,0,?,?,?)',(new_id,name,product['category_id'],product['price_paisa'],product['active'],now(),product['image_path'],product['description']))
        for variant in c.execute('SELECT * FROM product_variants WHERE product_id=?',(pid,)).fetchall():
            c.execute('INSERT INTO product_variants VALUES(?,?,?,?,?)',(uuid.uuid5(uuid.NAMESPACE_URL,'hanan-size:'+new_id+':'+variant['label']).hex,new_id,variant['label'],variant['price_paisa'],variant['active']))
        audit(c,u['id'],'product_duplicated',{'source_id':pid,'new_id':new_id,'name':name,'stock_copied':False})
    return {'id':new_id}

@app.get('/api/products/{pid}/variants')
def product_sizes(pid:str,request:Request):
    auth(request)
    with tx() as c:
        ensure_pizza_sizes(c)
        return [dict(v) for v in c.execute("SELECT * FROM product_variants WHERE product_id=? ORDER BY CASE label WHEN 'Small' THEN 1 WHEN 'Medium' THEN 2 WHEN 'Large' THEN 3 ELSE 4 END",(pid,))]

@app.patch('/api/products/{pid}/variants')
async def update_sizes(pid:str,request:Request):
    u=auth(request,['owner','manager']);p=await payload(request);sizes=p.get('sizes')
    if not isinstance(sizes,list) or len(sizes)!=4 or {v.get('label') for v in sizes if isinstance(v,dict)}!={'Small','Medium','Large','XL'}:raise HTTPException(400,'Provide Small, Medium, Large and XL')
    if any(type(v.get('price_paisa'))!=int or v['price_paisa']<0 or v.get('active',1) not in (0,1) for v in sizes):raise HTTPException(400,'Invalid size prices or availability')
    with tx() as c:
        ensure_pizza_sizes(c)
        if c.execute('SELECT count(*) FROM product_variants WHERE product_id=?',(pid,)).fetchone()[0]!=4:raise HTTPException(400,'This item is not a pizza')
        for v in sizes:c.execute('UPDATE product_variants SET price_paisa=?,active=? WHERE product_id=? AND label=?',(v['price_paisa'],int(v.get('active',1)),pid,v['label']))
        audit(c,u['id'],'pizza_sizes_updated',{'product_id':pid,'sizes':sizes})
    return {'ok':True}

@app.get('/api/products')
def products(request:Request):
    auth(request)
    with tx() as c:
        ensure_pizza_sizes(c)
        result=[dict(p) for p in c.execute('SELECT p.*,cat.name category FROM products p LEFT JOIN categories cat ON p.category_id=cat.id WHERE p.is_deleted=0 ORDER BY p.active DESC,p.name')]
        for product in result:product['variants']=[dict(v) for v in c.execute("SELECT * FROM product_variants WHERE product_id=? ORDER BY CASE label WHEN 'Small' THEN 1 WHEN 'Medium' THEN 2 WHEN 'Large' THEN 3 ELSE 4 END",(product['id'],))]
        return result
@app.post('/api/products')
async def add_product(request:Request):
    u=auth(request,['owner','manager']);p=await payload(request)
    name=str(p.get('name','')).strip()[:120]
    price=p.get('price_paisa')
    if not name or type(price)!=int or price<0:raise HTTPException(400,'Valid name and price required')
    if type(p.get('stock_qty',0))!=int or p.get('stock_qty',0)<0:raise HTTPException(400,'Opening stock must be nonnegative')
    pid=str(uuid.uuid4());cat=p.get('category_id') or None
    with tx() as c:
        c.execute('INSERT INTO products(id,name,category_id,price_paisa,active,stock_tracking,stock_qty,created_at,image_path,description) VALUES(?,?,?,?,?,?,?,?,NULL,?)',(pid,name,cat,price,int(bool(p.get('active',True))),int(bool(p.get('stock_tracking'))),int(p.get('stock_qty',0)),now(),str(p.get('description',''))[:1000]))
        audit(c,u['id'],'product_created',{'product_id':pid})
    return {'id':pid}
@app.patch('/api/products/{pid}')
async def edit_product(pid:str,request:Request):
    u=auth(request,['owner','manager']);p=await payload(request)
    allowed={'name','price_paisa','active','category_id','stock_tracking','description'}
    if not isinstance(p,dict) or not p or not set(p)<=allowed:raise HTTPException(400,'Invalid update')
    if 'price_paisa' in p and (type(p['price_paisa'])!=int or p['price_paisa']<0):raise HTTPException(400,'Invalid price')
    if 'name' in p and not str(p['name']).strip():raise HTTPException(400,'Name required')
    if 'active' in p and p['active'] not in (0,1,False,True):raise HTTPException(400,'Invalid availability')
    if 'category_id' in p and p['category_id'] is not None and not isinstance(p['category_id'],str):raise HTTPException(400,'Invalid category')
    with tx() as c:
        r=c.execute('SELECT id FROM products WHERE id=?',(pid,)).fetchone()
        if not r:raise HTTPException(404)
        if 'description' in p: p['description']=str(p['description'])[:1000]
        c.execute('UPDATE products SET '+','.join(f'{k}=?' for k in p)+' WHERE id=?',(*p.values(),pid));audit(c,u['id'],'product_updated',{'id':pid,'fields':list(p)})
    return {'ok':True}
@app.get('/media/{filename}')
def media_file(filename:str):
    # Only serve generated image filenames from the managed media directory.
    if not re.fullmatch(r'[a-f0-9]{32}\.(?:jpg|png|webp)',filename): raise HTTPException(404)
    path=(MEDIA/filename).resolve()
    if path.parent!=MEDIA.resolve() or not path.is_file(): raise HTTPException(404)
    return FileResponse(path)

@app.post('/api/products/{pid}/image')
async def upload_product_image(pid:str,request:Request):
    u=auth(request,['owner','manager']);p=await payload(request)
    data=str(p.get('data_url',''))
    match=re.fullmatch(r'data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)',data)
    if not match: raise HTTPException(400,'Choose a JPG, PNG or WebP image')
    raw=base64.b64decode(match.group(2),validate=True)
    if not raw or len(raw)>3*1024*1024: raise HTTPException(413,'Image must be under 3 MB')
    kind=match.group(1); valid=(kind=='jpeg' and raw.startswith(b'\xff\xd8\xff')) or (kind=='png' and raw.startswith(b'\x89PNG\r\n\x1a\n')) or (kind=='webp' and raw.startswith(b'RIFF') and raw[8:12]==b'WEBP')
    if not valid: raise HTTPException(400,'Image content does not match its file type')
    try:
        from PIL import Image
        with Image.open(io.BytesIO(raw)) as image:
            if image.width*image.height>24000000:raise ValueError('Image exceeds 24 megapixels')
            image.verify()
    except Exception:raise HTTPException(400,'Image is corrupt or too large to decode')
    ext={'jpeg':'jpg','png':'png','webp':'webp'}[kind];name=secrets.token_hex(16)+'.'+ext;dest=MEDIA/name
    with connect() as c:
        old=c.execute('SELECT image_path FROM products WHERE id=?',(pid,)).fetchone()
    if not old: raise HTTPException(404,'Menu item not found')
    dest.write_bytes(raw)
    try:
        with tx() as c:
            c.execute('UPDATE products SET image_path=? WHERE id=?',(name,pid))
            if old['image_path']: c.execute('INSERT INTO product_images VALUES(?,?,?,?)',(uuid.uuid4().hex,pid,old['image_path'],now()))
            audit(c,u['id'],'product_image_changed',{'product_id':pid})
    except Exception:
        dest.unlink(missing_ok=True);raise
    return {'ok':True,'image_path':'/media/'+name}

@app.delete('/api/products/{pid}/image')
def remove_product_image(pid:str,request:Request):
    u=auth(request,['owner','manager'])
    with tx() as c:
        r=c.execute('SELECT image_path FROM products WHERE id=?',(pid,)).fetchone()
        if not r: raise HTTPException(404,'Menu item not found')
        if r['image_path']:c.execute('INSERT INTO product_images VALUES(?,?,?,?)',(uuid.uuid4().hex,pid,r['image_path'],now()))
        c.execute('UPDATE products SET image_path=NULL WHERE id=?',(pid,));audit(c,u['id'],'product_image_removed',{'product_id':pid})
    return {'ok':True}

@app.delete('/api/products/{pid}')
def archive_product(pid:str,request:Request):
    u=auth(request,['owner','manager'])
    with tx() as c:
        r=c.execute('SELECT id,name,active FROM products WHERE id=?',(pid,)).fetchone()
        if not r: raise HTTPException(404,'Menu item not found')
        c.execute('UPDATE products SET active=0,is_deleted=1 WHERE id=?',(pid,))
        audit(c,u['id'],'product_archived',{'product_id':pid,'name':r['name']})
    return {'ok':True,'archived':True}

@app.post('/api/stock')
async def stock(request:Request):
    u=auth(request,['owner','manager']);p=await payload(request)
    pid=p.get('product_id');delta=p.get('delta');reason=str(p.get('reason','')).strip()[:120]
    if type(delta)!=int or not delta or not reason:raise HTTPException(400,'Valid adjustment and reason required')
    with tx() as c:
        result=c.execute('UPDATE products SET stock_qty=stock_qty+? WHERE id=? AND stock_qty+?>=0',(delta,pid,delta))
        if not result.rowcount:raise HTTPException(400,'Product missing or insufficient stock')
        c.execute('INSERT INTO inventory_movements VALUES (?,?,?,?,?,?,?)',(str(uuid.uuid4()),pid,delta,reason,None,u['id'],now()))
        audit(c,u['id'],'stock_adjusted',{'product_id':pid,'delta':delta})
    return {'ok':True}

def money(v):return isinstance(v,int) and not isinstance(v,bool) and v>=0
@app.post('/api/orders')
async def add_order(request:Request):
    u=auth(request,['owner','manager','cashier']);p=await payload(request)
    typ=p.get('order_type','COUNTER');method=p.get('payment_method','UNPAID')
    if typ not in ('COUNTER','PARCEL','DELIVERY') or method not in ('CASH','BANK_TRANSFER','WALLET','OTHER','UNPAID'):raise HTTPException(400,'Invalid order/payment type')
    items=p.get('items',[])
    if not isinstance(items,list) or not 1<=len(items)<=100:raise HTTPException(400,'Add order items')
    if not isinstance(p.get('idempotency_key'),str) or len(p['idempotency_key'])<10:raise HTTPException(400,'Idempotency key required')
    oid=p['idempotency_key'][:80]
    discount=p.get('discount_paisa',0);delivery=p.get('delivery_fee_paisa',0);service=p.get('service_charge_paisa',0);paid=p.get('amount_paid_paisa',0)
    if not all(money(x) for x in (discount,delivery,service,paid)):raise HTTPException(400,'Invalid monetary value')
    with tx() as c:
        exists=c.execute('SELECT id,order_no FROM orders WHERE id=?',(oid,)).fetchone()
        if exists:return dict(exists)|{'duplicate':True}
        ensure_pizza_sizes(c)
        subtotal=0;calculated=[]
        seen_products=set();stock_required={}
        for item in items:
            if not isinstance(item,dict):raise HTTPException(400,'Invalid order item')
            line_key=(item.get('product_id'),item.get('variant_id'))
            if line_key in seen_products:raise HTTPException(400,'Combine duplicate product sizes into one quantity')
            seen_products.add(line_key)
            qty=item.get('qty');pid=item.get('product_id')
            if type(qty)!=int or not 1<=qty<=99:raise HTTPException(400,'Invalid quantity')
            prod=c.execute('SELECT * FROM products WHERE id=? AND active=1',(pid,)).fetchone()
            if not prod:raise HTTPException(400,'Product unavailable')
            stock_required[pid]=stock_required.get(pid,0)+qty
            if prod['stock_tracking'] and prod['stock_qty']<stock_required[pid]:raise HTTPException(400,f'Insufficient stock: {prod["name"]}')
            prod=dict(prod)
            sizes=c.execute('SELECT * FROM product_variants WHERE product_id=?',(pid,)).fetchall()
            if sizes:
                variant=next((v for v in sizes if v['id']==item.get('variant_id') and v['active']),None)
                if not variant:raise HTTPException(400,'Select an available pizza size')
                prod['price_paisa']=variant['price_paisa'];prod['name']+=' · '+variant['label']
            elif item.get('variant_id'):raise HTTPException(400,'Invalid product size')
            total=qty*prod['price_paisa'];subtotal+=total
            calculated.append((prod,qty,total,str(item.get('notes',''))[:200]))
        if discount>subtotal:raise HTTPException(400,'Discount exceeds subtotal')
        s=getsettings(c)
        tax=(subtotal-discount)*int(s.get('tax_rate_bp','0'))//10000
        grand=subtotal-discount+tax+delivery+service
        if paid>grand and method!='CASH':raise HTTPException(400,'Overpayment only allowed for cash')
        if paid and method=='UNPAID':raise HTTPException(400,'Payment method required')
        status='PREPARING';payment_status='PAID' if method=='CASH' and paid>=grand else ('PARTIAL' if paid else 'UNPAID')
        # Non-cash payments require external verification and remain unverified.
        if method in ('BANK_TRANSFER','WALLET','OTHER'):payment_status='UNVERIFIED'
        no=c.execute('SELECT COALESCE(MAX(order_no),0)+1 FROM orders').fetchone()[0]
        c.execute('INSERT INTO orders(id,order_no,order_type,status,payment_status,payment_method,customer,phone,address,notes,cashier_id,subtotal,discount,tax,delivery_fee,grand_total,amount_paid,created_at,service_charge) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(oid,no,typ,status,payment_status,method,p.get('customer','')[:120],p.get('phone','')[:40],p.get('address','')[:300],p.get('notes','')[:300],u['id'],subtotal,discount,tax,delivery,grand,paid,now(),service))
        for prod,qty,total,notes in calculated:
            c.execute('INSERT INTO order_items VALUES(?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),oid,prod['id'],prod['name'],qty,prod['price_paisa'],total,notes))
            if prod['stock_tracking']:
                c.execute('UPDATE products SET stock_qty=stock_qty-? WHERE id=?',(qty,prod['id']))
                c.execute('INSERT INTO inventory_movements VALUES(?,?,?,?,?,?,?)',(str(uuid.uuid4()),prod['id'],-qty,'Sale',oid,u['id'],now()))
        c.execute('INSERT INTO order_events VALUES(?,?,?,?,?)',(str(uuid.uuid4()),oid,status,u['id'],now()))
        save_order_contact(c,p)
        audit(c,u['id'],'order_created',{'id':oid,'order_no':no,'total':grand})
    return {'id':oid,'order_no':no,'grand_total':grand,'payment_status':payment_status,'duplicate':False}
@app.get('/api/dashboard')
def dashboard_overview(request:Request):
    auth(request)
    today=datetime.now(timezone(timedelta(hours=5))).date()
    with connect() as c:
        day=str(today)
        daily=c.execute("SELECT COUNT(*) orders_today,COALESCE(SUM(status IN ('COMPLETED','DELIVERED')),0) completed,COALESCE(SUM(status NOT IN ('COMPLETED','DELIVERED','CANCELLED')),0) pending,COALESCE(SUM(status='CANCELLED'),0) cancelled,COALESCE(SUM(CASE WHEN status!='CANCELLED' THEN grand_total ELSE 0 END),0) order_value FROM orders WHERE date(created_at,'+5 hours')=?",(day,)).fetchone()
        ready=c.execute("SELECT COUNT(*) FROM orders WHERE status='READY'").fetchone()[0]
        counts={x['day']:x['n'] for x in c.execute("SELECT date(created_at,'+5 hours') day,COUNT(*) n FROM orders WHERE date(created_at,'+5 hours') BETWEEN ? AND ? GROUP BY day",(str(today-timedelta(days=6)),day))}
        sales={x['day']:x['v'] for x in c.execute("SELECT date(created_at,'+5 hours') day,COALESCE(SUM(CASE WHEN status!='CANCELLED' THEN grand_total ELSE 0 END),0) v FROM orders WHERE date(created_at,'+5 hours') BETWEEN ? AND ? GROUP BY day",(str(today-timedelta(days=6)),day))}
    days=[]
    for offset in range(6,-1,-1):
        d=today-timedelta(days=offset);days.append({'date':str(d),'label':d.strftime('%a'),'orders':counts.get(str(d),0),'sales':sales.get(str(d),0)})
    return dict(daily)|{'date':day,'date_label':today.strftime('%A, %d %B %Y'),'ready':ready,'days':days}
@app.get('/api/orders')
def orders(request:Request):
    auth(request)
    with connect() as c:
        result=[dict(o) for o in c.execute('SELECT id,order_no,order_type,status,payment_status,grand_total,created_at,customer,phone FROM orders ORDER BY order_no DESC LIMIT 300')]
        items={}
        if result:
            ids=[o['id'] for o in result]
            for item in c.execute('SELECT order_id,name,SUM(qty) qty FROM order_items WHERE order_id IN ('+','.join('?' for _ in ids)+') GROUP BY order_id,name',ids):items.setdefault(item['order_id'],[]).append({'name':item['name'],'qty':item['qty']})
        for o in result:
            o['items_summary']=items.get(o['id'],[]);o['summary']=', '.join(str(i['qty'])+' × '+i['name'] for i in o['items_summary'])
        return result
@app.get('/api/orders/{oid}')
def order(oid:str,request:Request):
    auth(request)
    with connect() as c:
        r=c.execute('SELECT o.*,u.username cashier FROM orders o LEFT JOIN users u ON o.cashier_id=u.id WHERE o.id=?',(oid,)).fetchone()
        if not r:raise HTTPException(404)
        return {'order':dict(r),'items':[dict(x) for x in c.execute('SELECT i.*,COALESCE(t.done,0) kitchen_done FROM order_items i LEFT JOIN kitchen_tasks t ON t.item_id=i.id WHERE i.order_id=?',(oid,))],'settings':getsettings(c)}
@app.post('/api/orders/{oid}/status')
async def change_status(oid:str,request:Request):
    u=auth(request,['owner','manager','cashier','kitchen']);p=await payload(request)
    edges={'RECEIVED':['READY','PREPARING','CANCELLED'],'CONFIRMED':['READY','PREPARING','CANCELLED'],'PREPARING':['READY','CANCELLED'],'READY':['COMPLETED','DELIVERED','CANCELLED'],'COMPLETED':[],'DELIVERED':[],'CANCELLED':[]}
    with tx() as c:
        r=c.execute('SELECT status FROM orders WHERE id=?',(oid,)).fetchone()
        if not r:raise HTTPException(404)
        target=p.get('status')
        if target not in edges.get(r['status'],[]):raise HTTPException(400,'Invalid status transition')
        if target=='READY' and p.get('complete_all') is True:
            for item in c.execute('SELECT id FROM order_items WHERE order_id=?',(oid,)).fetchall():
                c.execute('INSERT INTO kitchen_tasks VALUES(?,?,?,?) ON CONFLICT(item_id) DO UPDATE SET done=1,actor=excluded.actor,updated_at=excluded.updated_at',(item['id'],1,u['id'],now()))
            audit(c,u['id'],'all_items_prepared',{'order_id':oid,'source':'mark_ready'})
        if target=='READY':
            remaining=c.execute('SELECT COUNT(*) FROM order_items i LEFT JOIN kitchen_tasks t ON t.item_id=i.id WHERE i.order_id=? AND COALESCE(t.done,0)=0',(oid,)).fetchone()[0]
            if remaining:
                reason=str(p.get('override_reason','')).strip()
                if u['role'] not in ('owner','manager') or len(reason)<5:raise HTTPException(409,'Complete each kitchen item first, or provide an authorized override reason')
                audit(c,u['id'],'kitchen_ready_override',{'order_id':oid,'reason':reason,'incomplete_items':remaining})
        if target=='CANCELLED':record_cancellation(c,oid,u,str(p.get('reason','Cancelled by authorized staff'))[:500],False)
        if target=='DELIVERED':
            typ=c.execute('SELECT order_type FROM orders WHERE id=?',(oid,)).fetchone()['order_type']
            if typ!='DELIVERY':raise HTTPException(400,'Only delivery orders can be marked Delivered')
        if target=='COMPLETED':
            typ=c.execute('SELECT order_type FROM orders WHERE id=?',(oid,)).fetchone()['order_type']
            if typ=='DELIVERY':raise HTTPException(400,'Delivery orders should be marked Delivered')
        c.execute('UPDATE orders SET status=? WHERE id=?',(target,oid))
        c.execute('INSERT INTO order_events VALUES(?,?,?,?,?)',(str(uuid.uuid4()),oid,p['status'],u['id'],now()))
        audit(c,u['id'],'order_status_changed',{'id':oid,'status':p['status']})
    return {'ok':True}
@app.post('/api/expenses')
async def expense(request:Request):
    u=auth(request,['owner','manager']);p=await payload(request)
    amount=p.get('amount_paisa');category=str(p.get('category','')).strip()[:80]
    method=str(p.get('payment_method','CASH')).upper()
    if method not in ('CASH','BANK_TRANSFER','WALLET','OTHER','UNPAID'): raise HTTPException(400,'Invalid recorded payment method')
    if not money(amount) or not amount or not category:raise HTTPException(400,'Valid expense required')
    with tx() as c:
        c.execute('INSERT INTO expenses(id,category,description,amount,created_at,actor,payment_method) VALUES (?,?,?,?,?,?,?)',(str(uuid.uuid4()),category,str(p.get('description',''))[:300],amount,now(),u['id'],method))
        audit(c,u['id'],'expense_created',{'amount':amount,'category':category,'payment_method':method,'record_only':True})
    return {'ok':True,'payment_recorded_only':True}
@app.delete('/api/expenses/{eid}')
def delete_expense(eid:str,request:Request):
    u=auth(request,['owner','manager'])
    with tx() as c:
        r=c.execute('SELECT id,category,amount FROM expenses WHERE id=?',(eid,)).fetchone()
        if not r: raise HTTPException(404,'Expense not found')
        c.execute('DELETE FROM expenses WHERE id=?',(eid,))
        audit(c,u['id'],'expense_deleted',{'expense_id':eid,'category':r['category'],'amount':r['amount']})
    return {'ok':True}
@app.patch('/api/expenses/{eid}')
async def edit_expense(eid:str,request:Request):
    u=auth(request,['owner','manager']);p=await payload(request)
    with tx() as c:
        r=c.execute('SELECT id FROM expenses WHERE id=?',(eid,)).fetchone()
        if not r: raise HTTPException(404,'Expense not found')
        updates={};category=p.get('category')
        if category is not None:
            category=str(category).strip()[:80]
            if not category:raise HTTPException(400,'Category is required')
            updates['category']=category
        if p.get('amount_paisa') is not None:
            amount=p.get('amount_paisa')
            if not money(amount) or not amount:raise HTTPException(400,'Valid amount required')
            updates['amount']=amount
        if p.get('payment_method') is not None:
            method=str(p.get('payment_method','CASH')).upper()
            if method not in ('CASH','BANK_TRANSFER','WALLET','OTHER','UNPAID'):raise HTTPException(400,'Invalid recorded payment method')
            updates['payment_method']=method
        if p.get('description') is not None:updates['description']=str(p.get('description',''))[:300]
        if not updates:raise HTTPException(400,'Nothing to update')
        c.execute('UPDATE expenses SET '+', '.join(k+'=?' for k in updates)+' WHERE id=?',(*updates.values(),eid))
        audit(c,u['id'],'expense_edited',{'expense_id':eid,**updates})
    return {'ok':True}
@app.get('/api/expenses')
def expenses(request:Request):auth(request,['owner','manager']);return rows('SELECT * FROM expenses ORDER BY created_at DESC LIMIT 200')
@app.get('/api/report')
def report(request:Request,period:str='today'):
    auth(request,['owner','manager'])
    allowed={'today','yesterday','last7','last30','month','lastmonth','year','all','custom'}
    if period not in allowed: raise HTTPException(400,'Invalid reporting period')
    start_date,end_date=finance_period_dates(period)
    where="status!='CANCELLED'"; exp_where='1=1'; params=[]
    if start_date:
        where += " AND date(created_at,'+5 hours') BETWEEN ? AND ?"; exp_where += " AND date(created_at,'+5 hours') BETWEEN ? AND ?"; params=[start_date,end_date]
    with connect() as c:
        r=c.execute(f"SELECT COUNT(*) n,COALESCE(SUM(grand_total),0) sales,COALESCE(SUM(discount),0) discounts FROM orders WHERE {where}",params).fetchone()
        exp=c.execute(f'SELECT COALESCE(SUM(amount),0) FROM expenses WHERE {exp_where}',params).fetchone()[0]
        return dict(r)|{'recorded_expenses':exp,'currency':'PKR','period':period,'start_date':start_date,'end_date':end_date,'note':'Sales totals include unpaid orders. Not a profit statement.'}

def finance_period_dates(period='today'):
    today=datetime.now(timezone(timedelta(hours=5))).date()
    if period=='today': return today.isoformat(),today.isoformat()
    if period=='yesterday':
        d=today-timedelta(days=1); return d.isoformat(),d.isoformat()
    if period=='last7': return (today-timedelta(days=6)).isoformat(),today.isoformat()
    if period=='last30': return (today-timedelta(days=29)).isoformat(),today.isoformat()
    if period=='month': return today.replace(day=1).isoformat(),today.isoformat()
    if period=='lastmonth':
        first=today.replace(day=1); last=first-timedelta(days=1); return last.replace(day=1).isoformat(),last.isoformat()
    if period=='year': return today.replace(month=1,day=1).isoformat(),today.isoformat()
    if period=='all': return None,None
    return today.isoformat(),today.isoformat()

def finance_snapshot(period='today',start_date=None,end_date=None):
    if period=='custom':
        try:
            start=datetime.fromisoformat(str(start_date)).date();end=datetime.fromisoformat(str(end_date)).date()
            if start.isoformat()!=start_date or end.isoformat()!=end_date or start>end:raise ValueError()
        except (ValueError,TypeError):raise HTTPException(400,'Choose valid start and end dates, with start not after end')
    else:start_date,end_date=finance_period_dates(period)
    order_where="status!='CANCELLED'"; exp_where='1=1'; params=[]
    if start_date:
        order_where += " AND date(created_at,'+5 hours') BETWEEN ? AND ?"; exp_where += " AND date(created_at,'+5 hours') BETWEEN ? AND ?"; params=[start_date,end_date]
    with connect() as c:
        sales=c.execute(f"SELECT COUNT(*) orders_count,COALESCE(SUM(grand_total),0) sales,COALESCE(SUM(discount),0) discounts,COALESCE(SUM(tax),0) tax,COALESCE(SUM(delivery_fee),0) delivery FROM orders WHERE {order_where}",params).fetchone()
        cash=c.execute(f"SELECT COUNT(*) n,COALESCE(SUM(amount_paid),0) tendered,COALESCE(SUM(MIN(amount_paid,grand_total)),0) amount,COALESCE(SUM(MAX(amount_paid-grand_total,0)),0) change_given FROM orders WHERE {order_where} AND payment_method='CASH'",params).fetchone()
        other=c.execute(f"SELECT payment_method,COUNT(*) count,COALESCE(SUM(grand_total),0) order_value,COALESCE(SUM(CASE WHEN payment_method='CASH' THEN MIN(amount_paid,grand_total) ELSE amount_paid END),0) amount_recorded,COALESCE(SUM(CASE WHEN payment_method='CASH' THEN MAX(amount_paid-grand_total,0) ELSE 0 END),0) change_given FROM orders WHERE {order_where} GROUP BY payment_method ORDER BY payment_method",params).fetchall()
        exp=c.execute(f'SELECT COALESCE(SUM(amount),0) amount FROM expenses WHERE {exp_where}',params).fetchone()['amount']
        exp_methods=c.execute(f'SELECT payment_method,COALESCE(SUM(amount),0) amount,COUNT(*) count FROM expenses WHERE {exp_where} GROUP BY payment_method ORDER BY payment_method',params).fetchall()
        return {'period':period,'start_date':start_date,'end_date':end_date,'orders':dict(sales),'cash_recorded':dict(cash),'payment_methods':[dict(r) for r in other],'expenses_total':exp,'expense_methods':[dict(r) for r in exp_methods], 'recorded_difference':int(sales['sales'])-int(exp), 'note':'Recordkeeping summary only. Sales include unpaid/unverified orders; non-cash methods are labels only. Cash retained excludes change returned. No bank, wallet, or payment-provider transaction is initiated or verified.'}

@app.get('/api/finance')
def finance(request:Request,period:str='today',start_date:str=None,end_date:str=None):
    auth(request,['owner'])
    allowed={'today','yesterday','last7','last30','month','lastmonth','year','all','custom'}
    if period not in allowed: raise HTTPException(400,'Invalid reporting period')
    return finance_snapshot(period,start_date,end_date)

@app.get('/api/finance.pdf')
def finance_pdf(request:Request,period:str='today',start_date:str=None,end_date:str=None):
    u=auth(request,['owner'])
    if period not in {'today','yesterday','last7','last30','month','lastmonth','year','all','custom'}: raise HTTPException(400,'Invalid reporting period')
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.lib.enums import TA_LEFT,TA_RIGHT,TA_CENTER
        from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle
    except ImportError: raise HTTPException(503,'PDF export dependency missing. Run: python -m pip install reportlab')
    v=finance_snapshot(period,start_date,end_date)
    # Orange / Porcelain palette (matches the app)
    ACCENT=colors.HexColor('#FF6115');DARK=colors.HexColor('#3C241C');TEXT=colors.HexColor('#30231D')
    MUTED=colors.HexColor('#795947');CREAM=colors.HexColor('#FFFCF4');CARD=colors.HexColor('#FFFDF7')
    SOFT=colors.HexColor('#FFF2DF');EDGE=colors.HexColor('#E5CDB6');NEG=colors.HexColor('#B42318')
    period_names={'today':'Today','yesterday':'Yesterday','last7':'Last 7 days','last30':'Last 30 days','month':'This month','lastmonth':'Last month','year':'This year','all':'All time','custom':'Custom dates'}
    plabel=period_names.get(period,period)
    drange=f"{v['start_date']} — {v['end_date']}" if v['start_date'] else 'All recorded dates'
    moneyfmt=lambda n:'Rs. {:,.2f}'.format((n or 0)/100)
    exp_count=sum(int(r.get('count') or 0) for r in v['expense_methods'])
    net=v['recorded_difference'];net_color=NEG if net<0 else TEXT
    buf=io.BytesIO()
    doc=SimpleDocTemplate(buf,pagesize=A4,rightMargin=15*mm,leftMargin=15*mm,topMargin=14*mm,bottomMargin=16*mm,
                          title=f'Hanan Cafe — Financial management ({plabel})',author='Hanan Cafe')
    ss=getSampleStyleSheet()
    eyebrow=ParagraphStyle('eyebrow',parent=ss['Normal'],fontName='Helvetica-Bold',fontSize=8,textColor=MUTED,spaceAfter=3,leading=10)
    story=[]
    # ---- header band ----
    head=Table([
        [Paragraph('<font color="#FF6115" size="18"><b>HANAN CAFE</b></font><br/><font color="#FFFCF4" size="9"><i>A legacy of taste</i></font>',ss['Normal']),
         Paragraph(f'<font color="#FFFCF4" size="12"><b>Financial management</b></font><br/><font color="#FFFCF4" size="8">{plabel} · {drange}</font><br/><font color="#FFFCF4" size="7">Generated {datetime.now().strftime("%d %b %Y · %H:%M")} · Owner-only recordkeeping report</font>',ParagraphStyle('hr',parent=ss['Normal'],alignment=TA_RIGHT,leading=12))]
    ],colWidths=[80*mm,100*mm])
    head.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),DARK),('VALIGN',(0,0),(-1,-1),'MIDDLE'),
                              ('LEFTPADDING',(0,0),(-1,-1),12),('RIGHTPADDING',(0,0),(-1,-1),12),
                              ('TOPPADDING',(0,0),(-1,-1),10),('BOTTOMPADDING',(0,0),(-1,-1),10),
                              ('ROUNDEDCORNERS',[6,6,6,6])]))
    story.extend([head,Spacer(1,7*mm)])
    # ---- part 1: summary cards (2x2) ----
    def card(label,value,detail):
        return Paragraph(f'<font color="#795947" size="8">{label}</font><br/><font color="#30231D" size="15"><b>{value}</b></font><br/><font color="#795947" size="7.5">{detail}</font>',ss['Normal'])
    cards=Table([
        [card(f'{plabel} sales',moneyfmt(v['orders']['sales']),f"{v['orders']['orders_count']} non-cancelled orders"),
         card('Cash retained after change',moneyfmt(v['cash_recorded']['amount']),f"Tender {moneyfmt(v['cash_recorded']['tendered'])} · change {moneyfmt(v['cash_recorded']['change_given'])}")],
        [card(f'{plabel} expenses',moneyfmt(v['expenses_total']),'Saved expense entries'),
         card('Sales less expenses',moneyfmt(v['recorded_difference']),'Not a profit calculation')],
    ],colWidths=[90*mm,90*mm])
    cards.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),CARD),('BOX',(0,0),(-1,-1),0.6,EDGE),
                               ('INNERGRID',(0,0),(-1,-1),0.6,EDGE),('VALIGN',(0,0),(-1,-1),'TOP'),
                               ('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),
                               ('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9),
                               ('ROUNDEDCORNERS',[6,6,6,6])]))
    story.extend([Paragraph('SUMMARY',eyebrow),cards,Spacer(1,6*mm)])
    # ---- part 2: income statement ----
    lab=ParagraphStyle('lab',parent=ss['Normal'],fontSize=9.5,textColor=TEXT,leading=13)
    amt=ParagraphStyle('amt',parent=ss['Normal'],fontSize=9.5,textColor=TEXT,leading=13,alignment=TA_RIGHT)
    sec=ParagraphStyle('sec',parent=ss['Normal'],fontName='Helvetica-Bold',fontSize=8,textColor=MUTED,leading=11)
    def L(t):return Paragraph(t,lab)
    def A(n,c=TEXT):return Paragraph(f'<font color="{'#'+c.hexval()[2:]}">{moneyfmt(n)}</font>',amt)
    def B(t):return Paragraph(f'<b>{t}</b>',ParagraphStyle('b',parent=lab,fontName='Helvetica-Bold'))
    def BA(n,c=TEXT):return Paragraph(f'<b><font color="{'#'+c.hexval()[2:]}">{moneyfmt(n)}</font></b>',ParagraphStyle('ba',parent=amt,fontName='Helvetica-Bold'))
    srows=[
        [Paragraph('<b>REVENUE</b>',sec),''],
        [L(f"Recorded sales <font color=\"#795947\">· {v['orders']['orders_count']} non-cancelled orders</font>"),A(v['orders']['sales'])],
        [B('Total revenue'),BA(v['orders']['sales'])],
        [Paragraph('<b>LESS: EXPENSES</b>',sec),''],
        [L(f'Recorded expenses <font color=\"#795947\">· {exp_count} entries</font>'),A(v['expenses_total'])],
        [B('Total expenses'),BA(v['expenses_total'])],
        [Paragraph('<b><font size="10.5">Net income</font></b> <font color=\"#795947\">· sales less expenses</font>',lab),
         Paragraph(f'<b><font size="10.5" color="{'#'+net_color.hexval()[2:]}">{moneyfmt(net)}</font></b>',amt)],
    ]
    st=Table(srows,colWidths=[125*mm,55*mm])
    st.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),SOFT),('BACKGROUND',(0,3),(-1,3),SOFT),
        ('SPAN',(0,0),(1,0)),('SPAN',(0,3),(1,3)),
        ('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),
        ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('LINEBELOW',(0,1),(-1,1),0.4,EDGE),('LINEABOVE',(0,2),(-1,2),0.6,TEXT),
        ('LINEBELOW',(0,4),(-1,4),0.4,EDGE),('LINEABOVE',(0,5),(-1,5),0.6,TEXT),
        ('LINEABOVE',(0,6),(-1,6),1.6,TEXT),('LINEBELOW',(0,6),(-1,6),1.6,TEXT),
        ('BOX',(0,0),(-1,-1),0.6,EDGE),('ROUNDEDCORNERS',[6,6,6,6]),
    ]))
    story.extend([Paragraph('INCOME STATEMENT',eyebrow),st,
                  Spacer(1,2*mm),
                  Paragraph('<font color="#795947" size="7.5">Recorded figures only — not a profit calculation. Cost of goods sold is not tracked in this app.</font>',ss['Normal']),
                  Spacer(1,6*mm)])
    # ---- payment method tables ----
    def pmtable(title,cols,rows,widths):
        t=Table([cols]+rows,colWidths=widths,repeatRows=1)
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),ACCENT),('TEXTCOLOR',(0,0),(-1,0),colors.HexColor('#21140E')),
                               ('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),8.5),
                               ('TEXTCOLOR',(0,1),(-1,-1),TEXT),('GRID',(0,0),(-1,-1),0.4,EDGE),
                               ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,CREAM]),
                               ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
                               ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),
                               ('VALIGN',(0,0),(-1,-1),'MIDDLE')]))
        return [Paragraph(title,eyebrow),t,Spacer(1,5*mm)]
    pm=[[r['payment_method'] or 'Unspecified',str(r['count']),moneyfmt(r['order_value']),moneyfmt(r['amount_recorded']),moneyfmt(r['change_given'])] for r in v['payment_methods']]
    story.extend(pmtable('RECORDED ORDER PAYMENT METHODS',['Method','Orders','Order value','Net amount recorded','Change'],
                         pm or [['—','—','—','—','—']],[32*mm,20*mm,42*mm,46*mm,40*mm]))
    em=[[r['payment_method'],str(r['count']),moneyfmt(r['amount'])] for r in v['expense_methods']]
    story.extend(pmtable('RECORDED EXPENSE PAYMENT METHODS',['Method','Entries','Amount recorded'],
                         em or [['—','—','—']],[60*mm,40*mm,80*mm]))
    story.extend([Paragraph(f'<font color="#795947" size="8">{v["note"]}</font>',ss['Normal']),Spacer(1,3*mm),
                  Paragraph('<font color="#795947" size="8"><i>Prepared for authorized owner review. This is not a statutory financial statement, bank reconciliation, or profit-and-loss statement.</i></font>',ss['Normal']),
                  Spacer(1,6*mm),
                  Paragraph('<font color="#795947" size="8">© 2026 Zocxorian Technology · HANAN CAFE</font>',ParagraphStyle('ft',parent=ss['Normal'],alignment=TA_CENTER))])
    def footer(cv,d):
        cv.saveState();cv.setFont('Helvetica',7);cv.setFillColor(MUTED)
        cv.drawCentredString(A4[0]/2,12*mm,f'Page {d.page} · © 2026 Zocxorian Technology')
        cv.restoreState()
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    with tx() as c:audit(c,u['id'],'finance_pdf_export',{'owner_only':True,'period':period,'start_date':v['start_date'],'end_date':v['end_date']})
    return StreamingResponse(io.BytesIO(buf.getvalue()),media_type='application/pdf',headers={'Content-Disposition':f'attachment; filename="hanan-cafe-finance-{period}.pdf"'})

@app.post('/api/print-jobs')
async def print_job(request:Request):
    u=auth(request,['owner','manager','cashier']);p=await payload(request)
    template=p.get('template','standard');width=p.get('width',80)
    if template not in ('compact','standard','tax','parcel','delivery','kitchen') or width not in (58,80):raise HTTPException(400,'Invalid template/width')
    with tx() as c:
        oid=p.get('order_id')
        if not c.execute('SELECT 1 FROM orders WHERE id=?',(oid,)).fetchone():raise HTTPException(404,'Order not found')
        previous=c.execute('SELECT COUNT(*) FROM print_jobs WHERE order_id=?',(oid,)).fetchone()[0]
        if previous and u['role'] not in ('owner','manager'):raise HTTPException(403,'Manager permission required for reprint')
        if previous and not p.get('reprint_confirmed'):raise HTTPException(409,'Reprint confirmation required')
        jid=str(uuid.uuid4())
        c.execute('INSERT INTO print_jobs VALUES(?,?,?,?,?,?,?,?,?)',(jid,oid,template,width,'QUEUED',1,u['id'],now(),None))
        audit(c,u['id'],'print_queued',{'job':jid,'reprint':bool(previous)})
    return {'id':jid,'status':'QUEUED'}
@app.get('/api/print-jobs')
def print_jobs(request:Request):auth(request);return rows('SELECT j.*,o.order_no FROM print_jobs j JOIN orders o ON j.order_id=o.id ORDER BY j.created_at DESC LIMIT 200')
@app.post('/api/print-jobs/{jid}/submitted')
def submitted(jid:str,request:Request):
    u=auth(request,['owner','manager','cashier'])
    with tx() as c:
        r=c.execute('UPDATE print_jobs SET status=? WHERE id=? AND status=?',('OUTCOME_UNKNOWN',jid,'QUEUED'))
        if not r.rowcount:raise HTTPException(409,'Print job not queued')
        audit(c,u['id'],'print_dialog_opened',{'id':jid})
    return {'status':'OUTCOME_UNKNOWN','note':'Browser dialog opened; paper output not confirmed'}
@app.get('/api/audit')
def audit_history(request:Request):auth(request,['owner']);return rows('SELECT * FROM audit ORDER BY created_at DESC LIMIT 100')
@app.get('/api/backup')
def backup(request:Request):
    u=auth(request,['owner'])
    snap=sqlite3.connect(':memory:')
    with connect() as c:c.backup(snap)
    with io.BytesIO() as out:
        temp=DATA/('.snapshot-'+secrets.token_hex(8)+'.db')
        disk=sqlite3.connect(temp);snap.backup(disk);disk.close();snap.close()
        try:
            with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED) as z:
                z.write(temp,'hanan.sqlite3')
                media_files=[]
                for mf in MEDIA.iterdir():
                    if mf.is_file() and re.fullmatch(r'[a-f0-9]{32}\.(?:jpg|png|webp)',mf.name):
                        z.write(mf,'media/'+mf.name);media_files.append({'file':'media/'+mf.name,'sha256':hashlib.sha256(mf.read_bytes()).hexdigest()})
                z.writestr('manifest.json',json.dumps({'created_at':now(),'version':'0.4.7','database_sha256':hashlib.sha256(temp.read_bytes()).hexdigest(),'media':media_files,'note':'Backup includes database and managed menu images; it includes password hashes and customer data; keep it private.'}))
            content=out.getvalue()
        finally:temp.unlink(missing_ok=True)
    with tx() as c:audit(c,u['id'],'backup_export',{})
    return StreamingResponse(io.BytesIO(content),media_type='application/zip',headers={'Content-Disposition':'attachment; filename="hanan-cafe-backup.zip"'})

from services import install_services, save_order_contact, record_cancellation
install_services(globals())

# Additive catalogue and recovery services.
from enhancements import install
install(globals())
