"""Hanan Cafe desktop launcher (used for the Windows .exe).

Starts the existing FastAPI app in-process, creates the owner account on first
run (replaces `python setup.py`), opens the browser and shows the address the
Android app should connect to.

    HananCafe.exe              -> window + server (default)
    HananCafe.exe --no-gui     -> console only (headless / testing)
    HananCafe.exe --remote     -> listen on all interfaces (phone access)
    HananCafe.exe --port 9000

Settings are stored in <data dir>/launcher.json. Data lives in ~/.hanan-cafe
unless HANAN_DATA_DIR is set (same rule as the app itself).
"""
import argparse, ipaddress, json, os, socket, sys, threading, time, urllib.request, webbrowser
from pathlib import Path

# A windowed PyInstaller build has no stdout/stderr; uvicorn and print() need something.
if sys.stdout is None or sys.stderr is None:
    _log = Path(os.environ.get('HANAN_DATA_DIR') or Path.home() / '.hanan-cafe')
    _log.mkdir(parents=True, exist_ok=True)
    sys.stdout = sys.stderr = open(_log / 'launcher.log', 'a', encoding='utf-8', buffering=1)

import uvicorn
import app as hanan  # importing creates/migrates the database in the data dir

DEFAULT_PORT = 8765
CONFIG = hanan.DATA / 'launcher.json'


def load_config():
    try:
        return json.loads(CONFIG.read_text(encoding='utf-8'))
    except Exception:
        return {}


def save_config(cfg):
    try:
        CONFIG.write_text(json.dumps(cfg, indent=2), encoding='utf-8')
    except Exception as exc:
        print('Could not save launcher settings:', exc)


def local_addresses():
    """Return [(label, ip)] for this machine's IPv4 addresses."""
    found = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            found.add(info[4][0])
    except OSError:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('10.255.255.255', 1))
        found.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    out = []
    tailnet = ipaddress.ip_network('100.64.0.0/10')
    for ip in sorted(found):
        addr = ipaddress.ip_address(ip)
        if addr.is_loopback or addr.is_link_local:
            continue
        out.append(('Tailscale' if addr in tailnet else 'Wi-Fi/LAN', ip))
    return out


def already_running(port):
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/ready', timeout=2) as r:
            return b'initialized' in r.read()
    except Exception:
        return False


def owner_exists():
    with hanan.connect() as c:
        return bool(c.execute('SELECT COUNT(*) FROM users').fetchone()[0])


class Server:
    def __init__(self, port, remote):
        self.port, self.remote = port, remote
        self.server = None
        self.thread = None
        self.error = None

    def start(self):
        host = '0.0.0.0' if self.remote else '127.0.0.1'
        cfg = uvicorn.Config(hanan.app, host=host, port=self.port, log_level='warning',
                             log_config=None, proxy_headers=True, forwarded_allow_ips='*')
        self.server = uvicorn.Server(cfg)
        self.server.install_signal_handlers = lambda: None  # not the main thread
        self.error = None

        def run():
            try:
                self.server.run()
            except BaseException as exc:  # e.g. port already in use
                self.error = exc
        self.thread = threading.Thread(target=run, daemon=True)
        self.thread.start()
        for _ in range(100):  # wait up to ~10 s
            if self.server.started or self.error or not self.thread.is_alive():
                break
            time.sleep(0.1)
        if not self.server.started and not self.error:
            self.error = RuntimeError('Server did not start')
        return self.error is None

    def stop(self):
        if self.server:
            self.server.should_exit = True
        if self.thread:
            self.thread.join(timeout=5)


# ---------- first-run owner creation ----------
def create_owner_console():
    from getpass import getpass
    print('First run: create the owner account.')
    username = input('Owner username: ').strip()
    pw = getpass('Owner password (at least 12 characters): ')
    if not username or pw != getpass('Confirm password: '):
        raise SystemExit('Username missing or passwords do not match.')
    hanan.create_owner(username, pw)


def create_owner_gui(tk, messagebox):
    """Modal dialog. Returns True when an owner was created."""
    win = tk.Tk()
    win.title('Hanan Cafe — first-run setup')
    win.resizable(False, False)
    tk.Label(win, text='Create the owner account', font=('Segoe UI', 13, 'bold')).grid(
        row=0, column=0, columnspan=2, padx=16, pady=(14, 2))
    tk.Label(win, text='Choose your own login. No default password exists.\nThe password needs at least 12 characters.',
             justify='left').grid(row=1, column=0, columnspan=2, padx=16, pady=(0, 10))
    fields = {}
    for i, (key, label, secret) in enumerate([('u', 'Username', False), ('p', 'Password', True), ('c', 'Confirm password', True)]):
        tk.Label(win, text=label).grid(row=2 + i, column=0, sticky='e', padx=(16, 6), pady=3)
        e = tk.Entry(win, width=30, show='•' if secret else '')
        e.grid(row=2 + i, column=1, padx=(0, 16), pady=3)
        fields[key] = e
    result = {'ok': False}

    def submit():
        u, p, c = fields['u'].get().strip(), fields['p'].get(), fields['c'].get()
        if not u:
            return messagebox.showerror('Hanan Cafe', 'Enter a username.', parent=win)
        if len(p) < 12:
            return messagebox.showerror('Hanan Cafe', 'Password must have at least 12 characters.', parent=win)
        if p != c:
            return messagebox.showerror('Hanan Cafe', 'Passwords do not match.', parent=win)
        try:
            hanan.create_owner(u, p)
        except Exception as exc:
            return messagebox.showerror('Hanan Cafe', str(exc), parent=win)
        result['ok'] = True
        win.destroy()

    tk.Button(win, text='Create owner', command=submit, width=16).grid(row=5, column=0, columnspan=2, pady=14)
    fields['u'].focus_set()
    win.bind('<Return>', lambda _e: submit())
    win.mainloop()
    return result['ok']


# ---------- run modes ----------
def run_headless(port, remote):
    if not owner_exists():
        create_owner_console()
    srv = Server(port, remote)
    if not srv.start():
        raise SystemExit(f'Cannot start on port {port}: {srv.error}')
    print(f'Hanan Cafe running at http://127.0.0.1:{port}  (Ctrl+C to stop)')
    if remote:
        for label, ip in local_addresses():
            print(f'  Phone address ({label}): http://{ip}:{port}')
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        srv.stop()


def run_gui(port, remote):
    import tkinter as tk
    from tkinter import messagebox

    if not owner_exists() and not create_owner_gui(tk, messagebox):
        return
    srv = Server(port, remote)
    if not srv.start():
        messagebox.showerror('Hanan Cafe', f'Could not start the server on port {port}.\n\n{srv.error}')
        return

    root = tk.Tk()
    root.title('Hanan Cafe — server')
    root.geometry('460x330')
    root.resizable(False, False)
    tk.Label(root, text='Hanan Cafe is running', font=('Segoe UI', 14, 'bold')).pack(pady=(14, 2))
    tk.Label(root, text='Keep this window open (minimize it) while the cafe is open.\n'
                        'Closing it stops the app and the phone connection.',
             justify='center', fg='#444').pack()
    local_url = f'http://127.0.0.1:{port}'
    tk.Button(root, text='Open Hanan Cafe in browser', width=30,
              command=lambda: webbrowser.open(local_url)).pack(pady=10)

    remote_var = tk.BooleanVar(value=remote)
    phone_box = tk.Text(root, height=6, width=56, relief='flat', bg=root.cget('bg'), wrap='word')
    phone_box.pack(padx=14)

    def refresh_phone():
        phone_box.config(state='normal')
        phone_box.delete('1.0', 'end')
        if remote_var.get():
            addrs = local_addresses()
            phone_box.insert('end', 'Address for the Android app:\n')
            if addrs:
                for label, ip in addrs:
                    phone_box.insert('end', f'  http://{ip}:{port}   ({label})\n')
            else:
                phone_box.insert('end', '  No network address found — connect to Wi-Fi or Tailscale.\n')
            phone_box.insert('end', '\nFor use away from the cafe, use the Tailscale address.')
        else:
            phone_box.insert('end', 'Phone access is OFF. Tick the box below to let the Android app connect.')
        phone_box.config(state='disabled')

    def toggle_remote():
        nonlocal srv
        srv.stop()
        srv = Server(port, remote_var.get())
        if not srv.start():
            messagebox.showerror('Hanan Cafe', f'Could not restart the server.\n\n{srv.error}')
        cfg = load_config()
        cfg['allow_remote'] = remote_var.get()
        save_config(cfg)
        refresh_phone()

    tk.Checkbutton(root, text='Allow phone access (Android app)', variable=remote_var,
                   command=toggle_remote).pack(pady=8)
    refresh_phone()

    def on_close():
        if messagebox.askyesno('Hanan Cafe', 'Stop Hanan Cafe?\n\nThe POS and the phone app will stop working until you start it again.'):
            srv.stop()
            root.destroy()
    root.protocol('WM_DELETE_WINDOW', on_close)
    webbrowser.open(local_url)
    root.mainloop()


def main():
    ap = argparse.ArgumentParser(description='Hanan Cafe launcher')
    ap.add_argument('--no-gui', action='store_true', help='console mode')
    ap.add_argument('--remote', action='store_true', help='listen on all interfaces for phone access')
    ap.add_argument('--port', type=int, default=None)
    args = ap.parse_args()
    cfg = load_config()
    port = args.port or int(cfg.get('port', DEFAULT_PORT))
    remote = args.remote or bool(cfg.get('allow_remote', False))

    if already_running(port):  # second double-click: just open the existing instance
        webbrowser.open(f'http://127.0.0.1:{port}')
        return
    if args.no_gui:
        run_headless(port, remote)
    else:
        try:
            run_gui(port, remote)
        except ImportError:  # tkinter missing
            run_headless(port, remote)


if __name__ == '__main__':
    main()
