# Hanan Cafe — Windows .exe + Android .apk

## How it works

Hanan Cafe keeps all records in a database on **one computer** (the cafe PC). Nothing is stored in the cloud.

- **Windows .exe** = the whole app packaged so it runs without installing Python.
- **Android .apk** = a viewer. It opens the cafe PC's address inside the app, so the owner sees the **live records from anywhere**. It does not hold its own copy of the data.

Consequence: the cafe PC must be **on, connected to the internet, and running HananCafe.exe** for the phone to show records. If you later want records available while the PC is off, the app needs a cloud database (a separate, larger piece of work — the project notes say sync is not implemented).

---

## 1. Build the files

Neither file can be built on Mac/Linux. Choose one route.

### Route A — GitHub (no software to install; builds both files)
1. Create a free account at github.com and a **private** repository.
2. Upload the contents of this folder (the folder itself should not be one level deeper: `launcher.py`, `android/`, `.github/` must be at the top).
3. Open the repo → **Actions** → **Build Hanan Cafe** → **Run workflow**.
4. After ~10 minutes, open the finished run and download:
   - `HananCafe-Windows` → zip containing `HananCafe\HananCafe.exe`
   - `HananCafe-Android-APK` → `app-release.apk`

### Route B — Locally
- **exe:** on any Windows PC with Python 3.12 installed, double-click `build_windows_exe.bat`. Result: `dist\HananCafe\HananCafe.exe`.
- **apk:** install Android Studio, choose **Open** → the `android` folder, then **Build → Build APK(s)**.

---

## 2. Install on the cafe PC

1. Unzip `HananCafe-Windows.zip` somewhere permanent (e.g. `C:\HananCafe`). Keep the whole folder together.
2. Run `HananCafe.exe`. Windows SmartScreen may warn because the exe is not code-signed: **More info → Run anyway**.
3. First run asks you to create the **owner username and password** (min. 12 characters). This replaces `python setup.py`.
4. The browser opens the app. A small window stays open — **minimize it, don't close it**.
5. Tick **Allow phone access** and allow it through Windows Firewall when asked (Private networks).

Data location: `C:\Users\<name>\.hanan-cafe` (survives updating the exe). To move existing data from another computer: in the old app use **Backup → Generate & download ZIP**, then in the new app use **Import backup**.

To start automatically: press `Win+R`, type `shell:startup`, and put a shortcut to `HananCafe.exe` there.

---

## 3. Reach it from anywhere (recommended: Tailscale)

Tailscale creates a private connection between the owner's phone and the cafe PC. Nothing is exposed to the public internet.

1. Create a free Tailscale account (tailscale.com) and install Tailscale on the **cafe PC** and on the **owner's phone**, signing in with the same account.
2. In the Hanan Cafe window, with **Allow phone access** ticked, note the address marked *(Tailscale)* — like `http://100.101.102.103:8765`.
3. Install the APK on the phone (allow "install unknown apps" for your browser/file manager; Play Protect may show a warning for sideloaded apps).
4. Open **Hanan Cafe** on the phone, enter that address, tap **Connect**, and log in with the owner account (or a manager account).
5. To change the address later: long-press the app icon → **Change server address**.

Keep Tailscale running on the phone. Set the cafe PC not to sleep (Power settings → Sleep: Never).

### Security notes
- **Do not port-forward** the app on the router or publish it with a public tunnel as-is. The login has no lockout on repeated wrong passwords and the project notes say public hosting needs hardening. Tailscale avoids this.
- Use a strong owner password. Staff passwords can be shorter (8+), so give the phone only owner/manager access if staff accounts are weak.
- The Android app allows plain `http://` because Tailscale already encrypts the traffic. On ordinary Wi-Fi without Tailscale, traffic is not encrypted.

---

## 4. APK updates and signing

Without a signing key, the APK is signed with a temporary key, and a later rebuild may refuse to install over the old one (uninstall first — your data is on the PC, so nothing is lost). To avoid that, create a key once and reuse it:

```
keytool -genkeypair -v -keystore hanan.jks -alias hanan -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 hanan.jks      # on Windows PowerShell: [Convert]::ToBase64String([IO.File]::ReadAllBytes("hanan.jks"))
```
Add GitHub repository secrets: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`. Keep `hanan.jks` and its passwords backed up.

---

## 5. What was and was not verified

Verified in testing: the app packaged with PyInstaller starts, logs in, serves the pages, exports PDF and backup ZIP; first-run and re-launch behaviour of the launcher in console mode; the Android Java syntax and XML files parse.

**Not verified** (no Windows machine or Android SDK was available): the actual `.exe` and `.apk` builds, the launcher window and first-run dialog, and the app running on a phone. Expect to run the build once and report any error text — it is usually a one-line fix. Receipt printing from the exe uses the same browser print dialog as before and needs checking with your printer.
