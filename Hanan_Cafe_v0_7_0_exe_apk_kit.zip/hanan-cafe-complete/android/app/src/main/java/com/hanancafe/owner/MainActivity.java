package com.hanancafe.owner;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Thin shell around the Hanan Cafe web app. The records stay on the cafe PC;
 * this app only opens that PC's address (best reached through Tailscale).
 */
public class MainActivity extends Activity {
    private static final String PREFS = "hanan";
    private static final String KEY_URL = "server_url";
    private static final String ACTION_SETTINGS = "com.hanancafe.owner.SETTINGS";
    private static final int REQ_FILE = 1001;
    private static final int GREEN = 0xFF163C2B;

    private FrameLayout root;
    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(GREEN);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);
        start(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        start(intent);
    }

    private void start(Intent intent) {
        String saved = prefs().getString(KEY_URL, "");
        if (intent != null && ACTION_SETTINGS.equals(intent.getAction())) {
            showSetup(saved, null);
        } else if (TextUtils.isEmpty(saved)) {
            showSetup("", null);
        } else if (web == null) {
            openWeb(saved);
        }
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ---------- server address screen ----------
    private void showSetup(String prefill, String error) {
        destroyWeb();
        root.removeAllViews();

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(24), dp(48), dp(24), dp(24));

        TextView title = new TextView(this);
        title.setText("Hanan Cafe");
        title.setTextSize(28);
        title.setTextColor(GREEN);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        col.addView(title);

        TextView help = new TextView(this);
        help.setText("Enter the address of the Hanan Cafe computer.\n\n"
                + "Example (Tailscale):  http://100.101.102.103:8765\n"
                + "Example (cafe Wi-Fi):  http://192.168.1.20:8765\n\n"
                + "The address is shown in the Hanan Cafe window on the cafe PC. "
                + "Your records stay on that PC; this app only shows them.");
        help.setTextSize(15);
        help.setPadding(0, dp(12), 0, dp(16));
        col.addView(help);

        final EditText input = new EditText(this);
        input.setHint("http://100.x.x.x:8765");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setText(prefill == null ? "" : prefill);
        col.addView(input, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final TextView err = new TextView(this);
        err.setTextColor(0xFFB00020);
        err.setPadding(0, dp(8), 0, 0);
        if (error != null) err.setText(error);
        col.addView(err);

        Button go = new Button(this);
        go.setText("Connect");
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = normalize(input.getText().toString());
                if (url == null) {
                    err.setText("Enter a valid address, e.g. http://100.101.102.103:8765");
                    return;
                }
                prefs().edit().putString(KEY_URL, url).apply();
                openWeb(url);
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(16);
        col.addView(go, lp);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(col);
        root.addView(sv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** Returns a clean http(s) URL without trailing slash, or null if invalid. */
    private static String normalize(String raw) {
        String s = raw == null ? "" : raw.trim();
        if (s.isEmpty()) return null;
        if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://" + s;
        Uri u = Uri.parse(s);
        if (u.getHost() == null || u.getHost().isEmpty()) return null;
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    // ---------- web view ----------
    private void destroyWeb() {
        if (web != null) {
            root.removeView(web);
            web.destroy();
            web = null;
        }
    }

    @SuppressWarnings("deprecation")
    private void openWeb(final String serverUrl) {
        destroyWeb();
        root.removeAllViews();

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(true);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, false);

        final String serverHost = Uri.parse(serverUrl).getHost();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("hanan".equals(u.getScheme())) {
                    if ("settings".equals(u.getHost())) {
                        showSetup(serverUrl, null);
                    } else {
                        view.loadUrl(serverUrl);
                    }
                    return true;
                }
                if (u.getHost() != null && !u.getHost().equalsIgnoreCase(serverHost)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception ignored) { }
                    return true;
                }
                return false;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    view.loadDataWithBaseURL(null, errorPage(serverUrl, String.valueOf(error.getDescription())),
                            "text/html", "utf-8", null);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, length) -> {
            try {
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                String cookie = CookieManager.getInstance().getCookie(url);
                if (cookie != null) r.addRequestHeader("Cookie", cookie);
                r.addRequestHeader("User-Agent", userAgent);
                if (mimeType != null) r.setMimeType(mimeType);
                String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
                r.setTitle(name);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "Downloading " + name, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Download failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        web.loadUrl(serverUrl);
    }

    private static String errorPage(String serverUrl, String detail) {
        String u = TextUtils.htmlEncode(serverUrl);
        String d = TextUtils.htmlEncode(detail);
        return "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                + "<body style='font-family:sans-serif;padding:24px;color:#222'>"
                + "<h2 style='color:#163C2B'>Cannot reach Hanan Cafe</h2>"
                + "<p>Tried: <b>" + u + "</b></p><p style='color:#777'>" + d + "</p>"
                + "<ul><li>Is the cafe PC on, with Hanan Cafe running?</li>"
                + "<li>Is &ldquo;Allow phone access&rdquo; ticked in the Hanan Cafe window?</li>"
                + "<li>Is Tailscale connected on this phone?</li></ul>"
                + "<p><a href='hanan://retry' style='display:inline-block;padding:12px 20px;"
                + "background:#163C2B;color:#fff;border-radius:8px;text-decoration:none'>Retry</a> "
                + "<a href='hanan://settings' style='display:inline-block;padding:12px 20px;"
                + "border:1px solid #163C2B;color:#163C2B;border-radius:8px;text-decoration:none'>Change address</a></p>"
                + "</body></html>";
    }

    // ---------- lifecycle ----------
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE && filePathCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                result = android.webkit.WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onDestroy() {
        destroyWeb();
        super.onDestroy();
    }
}
